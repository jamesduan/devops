#!/bin/bash -ex
#sh /opt/mtprovision/daas/initdbdata/initdbdata-v1.0/main/initdbdata.sh
shpath=$(cd $(dirname $0); pwd)
source $shpath/properties.ini
initdbdatatmp=$shpath/$initdbdatatmp
initdbdatabundles=$shpath/$initdbdatabundles
initdbdatatoolkit=$shpath/$initdbdatatoolkit
echo $initdbdatatmp
echo $initdbdatabundles
echo $initdbdatatoolkit

source $initdbdatatoolkit/initdbdata_mysql_bakbusiness.sh

