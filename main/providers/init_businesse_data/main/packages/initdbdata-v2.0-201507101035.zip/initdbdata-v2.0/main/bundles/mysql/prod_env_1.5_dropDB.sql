use mysql
drop database  IF EXISTS activitystreamdb;
drop database  IF EXISTS addb;
drop database  IF EXISTS assetdb;
drop database  IF EXISTS docdb;
drop database  IF EXISTS maintaindb;
drop database  IF EXISTS partydb;
drop database  IF EXISTS sessiondb;
drop database  IF EXISTS spacedb;
drop database  IF EXISTS sysadmin;
drop database  IF EXISTS tfs_name_db;
drop database  IF EXISTS togressa;
drop database  IF EXISTS topicdb;
drop database  IF EXISTS appdb;
