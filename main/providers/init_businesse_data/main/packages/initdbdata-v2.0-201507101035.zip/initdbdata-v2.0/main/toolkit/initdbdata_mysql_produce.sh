#!/bin/bash -ex  
source $initdbdatatoolkit/bundle.ini
echo `pwd`
echo  '-------------dropDB produce:----------------'$bundle_produce_dropDB
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_produce_dropDB
echo  '-------------source schema produce:----------------'$bundle_produce_initschema
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_produce_initschema
echo  '-------------source data produce:----------------'$bundle_produce_initdata
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_produce_initdata
echo  '-------------source data grant:----------------'$bundle_produce_grant
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_produce_grant


echo  '-------------source schema produce diff:----------------'$bundle_produce_diff_schema
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_produce_diff_schema
echo  '-------------source data produce diff:----------------'$bundle_produce_diff_data
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_produce_diff_data
