#!/bin/bash -ex
echo  '-------------'$initdbdatatoolkit'bundle.ini'
source $initdbdatatoolkit/bundle.ini

echo  '-------------dropDB boc:----------------'$bundle_boc_dropDB
echo ${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_dropDB
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_dropDB
echo  '-------------source schema boc:----------------'$bundle_boc_initschema
echo ${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_initschema
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_initschema
echo  '-------------source data boc:----------------'$bundle_boc_initdata
echo ${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_initdata
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_initdata


echo  '-------------source schema boc diff:----------------'$bundle_boc_diff_schema
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_diff_schema
echo  '-------------source data boc diff:----------------'$bundle_boc_diff_data
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword mysql  -e "source "$bundle_boc_diff_data
