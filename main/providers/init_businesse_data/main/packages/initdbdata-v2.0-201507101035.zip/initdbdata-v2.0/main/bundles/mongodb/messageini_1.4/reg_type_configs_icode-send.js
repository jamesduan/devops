var mailalert = {
    "channel" : "mailalert",
    "content" : "<div class='preview_div'\n\tstyle='width: 700px; background-color: rgba(47, 150, 220, 0.5); font-size: 14px; line-height: 30px;'>\n<div class='preview_content' style='padding: 60px 40px; margin: 0 auto;'>\n<div class='middle_div'\n\tstyle='min-height: 500px; background-color: white; padding: 20px 30px;'>\n<div class='content_div'>\n<div style='color: #0088CC; font-weight: bold;'>尊敬的先生/小姐:</div>\n<div style=''>\n<p style='margin-left: 30px;'>您好！“第一时间”诚邀您参与封测。</p>\n<p>1.直接点击：<a href='{{{httpsite}}}/?itoken={{{itoken}}}'>{{{httpsite}}}/?itoken={{{itoken}}}</a>\n或扫描下方二维码下载。</p>\n<p>2.邀请函有效期：一周。</p>\n<p>3.您有任何意见或建议，可直接在应用内发送消息给“小秘书”，或发送至邮箱：<a\n\thref='mailto:IDC@magima.com.cn'>IDC@magima.com.cn</a>，期待您的反馈。<br>\n</p>\n<p style='text-align: right;'>谢谢！</p>\n<p style=''><img\n\tsrc='{{{httpsite}}}/download_qrcode/?itoken={{{itoken}}}'\n\theight=\"132px;\" width=\"132px;\" /></p>\n</div>\n<div class='info_div' style='text-align: right;'>bibo 第一时间</div>\n</div>\n</div>\n</div>\n</div>",
    "format" : "html",
    "subject" : "封测邀请",
    "subtype" : "icode-send"

}
var phonealert = {
    "channel" : "phonealert",
    "content" : "{{{invitee_name}}}，您好！\r\n“第一时间”诚邀您参与封测。\r\n点击：{{{httpsite}}}/?t={{{itoken}}} 下载\r\n邀请函有效期：一周。\r\n期待您的宝贵意见和建议。",
    "subtype" : "icode-send"
}
reg_subtype(mailalert);
reg_subtype(phonealert);
