#!/bin/bash -ex
#恢复当前服务器上已安装组件信息
source $initdbdatatoolkit/bundle.ini

echo  '-------------create schema (pvo_clients):----------------'$initdbdatatmp/pvo_clients.sql
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword sysadmin -e "source "$initdbdatatmp/pvo_clients.sql
echo  '-------------create data(tfs_name_db):----------------'$initdbdatatmp/tfs_name_db.sql
${mysqlcmd}mysql -h$mysqlhost -u$mysqluser -p$mysqlpassword tfs_name_db -e "source "$initdbdatatmp/tfs_name_db.sql
