use bocdb;
update admin_entry set deleted=1 where entry_id=11;

/*mysql> select * from admin_entry where  entry_id=10;
+----------+-----------+--------+--------------+--------------+---------+-----------+---------+------+------------+---------+
| entry_id | parent_id | name   | gbk_name     | zh_hant_name | en_name | privilege | reserve | sort | doc_profix | deleted |
+----------+-----------+--------+--------------+--------------+---------+-----------+---------+------+------------+---------+
|       10 |         1 | notice | 通知设置     | 通知設置     | notice  |           |         |    5 |            |       0 |
+----------+-----------+--------+--------------+--------------+---------+-----------+---------+------+------------+---------+
1 row in set (0.00 sec)

select * from admin_entry where name='channel';
|       11 |        10 | channel     | 通道设置           | 通道設置           | channel     | SiteSettings:messageChannel    |         |    1 |            |       1 |
delete from admin_entry where  entry_id in (196,197,198);
select * from  boc_logs_type where second_entry='notice';
*/
INSERT INTO `admin_entry` VALUES (196,10,'sms','手机短信设置','手機短信設置','sms','SiteSettings:messageChannel','',15,'',0),(197,10,'mail','邮件设置','郵件設置','mail','SiteSettings:messageChannel','',20,'',0),(198,10,'chat','即时聊天设置','即時聊天設置','chat','SiteSettings:messageChannel','',25,'',0);
insert into boc_logs_type(type_id,first_entry,second_entry,third_entry,verb,object,entry_name) values(122,'setting','notice','sms','add','','{"en":{"first_entry":"setting","second_entry":"notice","third_entry":"sms"},
"gbk":{"first_entry":"全局","second_entry":"通知设置","third_entry":"手机短信设置"},
"zh_hant":{"first_entry":"全局","second_entry":"通知設置","third_entry":"手機短信設置"}}') ;

insert into boc_logs_type(type_id,first_entry,second_entry,third_entry,verb,object,entry_name) values(123,'setting','notice','sms','update','','{"en":{"first_entry":"setting","second_entry":"notice","third_entry":"sms"},
"gbk":{"first_entry":"全局","second_entry":"通知设置","third_entry":"手机短信设置"},
"zh_hant":{"first_entry":"全局","second_entry":"通知設置","third_entry":"手機短信設置"}}') ;

insert into boc_logs_type(type_id,first_entry,second_entry,third_entry,verb,object,entry_name) values(124,'setting','notice','sms','delete','','{"en":{"first_entry":"setting","second_entry":"notice","third_entry":"sms"},
"gbk":{"first_entry":"全局","second_entry":"通知设置","third_entry":"手机短信设置"},
"zh_hant":{"first_entry":"全局","second_entry":"通知設置","third_entry":"手機短信設置"}}') ;

insert into boc_logs_type(type_id,first_entry,second_entry,third_entry,verb,object,entry_name) values(125,'setting','notice','mail','update','','{"en":{"first_entry":"setting","second_entry":"notice","third_entry":"mail"},
"gbk":{"first_entry":"全局","second_entry":"通知设置","third_entry":"邮件设置"},
"zh_hant":{"first_entry":"全局","second_entry":"通知設置","third_entry":"郵件設置"}}') ;

insert into boc_logs_type(type_id,first_entry,second_entry,third_entry,verb,object,entry_name) values(126,'setting','notice','chat','update','','{"en":{"first_entry":"setting","second_entry":"notice","third_entry":"chat"},
"gbk":{"first_entry":"全局","second_entry":"通知设置","third_entry":"即时聊天设置"},
"zh_hant":{"first_entry":"全局","second_entry":"通知設置","third_entry":"即時聊天設置"}}') ;


