var db = connect(db.hostInfo().system.hostname+"/sio-nebula");
function reg_subtye(subtype_obj){
    var subtype = subtype_obj.subtype;
    print("reg subtype", subtype);
    db.message_types.update({"subtype": subtype}, {"$set": subtype_obj}, true, true);
};
function reg_simple_notification(subtype){
    var subtype_obj = {
        "subtype": subtype,
        "name": subtype,
        "desc": subtype,
        "enable": true,
        "support_mail_channel": false,
        "support_sms_channel": false
    };
    reg_subtye(subtype_obj);
};
