var mailalert = {
    "channel" : "mailalert",
    "content" : "<div class='preview_div'\n        style='width: 700px; background-color: rgba(47, 150, 220, 0.5); font-size: 14px; line-height: 30px;'>\n<div class='preview_content' style='padding: 60px 40px; margin: 0 auto;'>\n<div class='middle_div'\n        style='min-height: 500px; background-color: white; padding: 20px 30px;'>\n<div class='content_div'>\n<div\n        style='color: #0088CC; text-align: center; font-size: 20px; font-weight: bold;'>邀\n请 函</div>\n<div style='color: #0088CC; font-weight: bold;'>尊敬的{{{invitee.name}}}先生/小姐:</div>\n<div style=''>您好！“第一时间”运营团队邀请您成为本网站的封测用户。\n<p>1、直接点击“邀请链接”地址：<a href='{{{httpsite}}}/?itoken={{{itoken}}}'>{{{httpsite}}}/?itoken={{{itoken}}}</a><br />\n或者用手机扫描下面的二维码进行下载</p>\n<p>2、邀请函有效期：一周。</p>\n<p>3、您的使用结果或反馈意见可发至邮箱：<a href='mailto:IDC@magima.com.cn'>IDC@magima.com.cn</a>。\n期待您的宝贵建议和意见。<br>\n</p>\n<p style='text-align: right;'>谢谢！</p>\n<p style=''><img\n        src='{{{httpsite}}}/download_qrcode/?itoken={{{itoken}}}' height=\"132px;\"\n        width=\"132px;\" /></p>\n</div>\n<div class='info_div' style='margin-top: 20px;'>\n此信由“第一时间”系统发出，因此请勿直接回复。</div>\n<div class='info_div' style='text-align: right;'>“第一时间”运营团队</div>\n</div>\n</div>\n</div>\n</div>",
    "format" : "html",
    "subject" : "封测邀请0",
    "subtype" : "icode-send"
}
var phonealert = {
    "channel" : "phonealert",
    "content" : "{{{invitee.name}}}:您好！\n“第一时间”运营团队邀请您成为本网站的封测用户。\n直接点击“邀请链接”地址：{{{httpsite}}}/?t={{{itoken}}}\n邀请函有效期：一周。\n您的使用结果或反馈意见可发至邮箱：IDC@magima.com.cn\n期待您的宝贵建议和意见。",
    "subtype" : "icode-send"
}
reg_subtype(mailalert);
reg_subtype(phonealert);
