var db = connect(db.hostInfo().system.hostname+"/checklist");
db.issuetag.remove({});
db.issuetag.insert({"tag_id":1,"tag_code":"diary","tag_name":"日记备忘"});
db.issuetag.insert({"tag_id":2,"tag_code":"meeting","tag_name":"聚餐聚会"});
db.issuetag.insert({"tag_id":3,"tag_code":"work","tag_name":"同事协作"});
db.issuetag.insert({"tag_id":-1,"tag_code":"handle","tag_name":"处理"});
db.issuetag.insert({"tag_id":-2,"tag_code":"check","tag_name":"验收"});
db.issuetag.insert({"tag_id":-3,"tag_code":"join","tag_name":"参加"});

