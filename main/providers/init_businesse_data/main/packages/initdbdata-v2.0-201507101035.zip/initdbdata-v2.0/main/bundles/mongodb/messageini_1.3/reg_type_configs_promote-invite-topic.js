var mailalert = {
     "channel" : "mailalert",
     "format" : "html",
     "content" : "<div class='preview_div'\n        style='width: 700px; background-color: rgba(47, 150, 220, 0.5); font-size: 14px; line-height: 30px;'>\n<div class='preview_content' style='padding: 60px 40px; margin: 0 auto;'>\n<div class='middle_div'\n        style='min-height: 500px; background-color: white; padding: 20px 30px;'>\n<div class='content_div'>\n<p>嗨：</p>\n<p>我的项目 群组：“{{{target.name}}}”，需要你参与。</p>\n<p>来和我一起参与“第一时间”吧，点击下面的链接或扫描二维码下载客户端： <a\n        href='{{{httpsite}}}/?itoken={{{itoken}}}'>{{{httpsite}}}/?itoken={{{itoken}}}</a>\n<br />\n<img src='{{{httpsite}}}/download_qrcode/?itoken={{{itoken}}}'\n        height=\"132px;\" width=\"132px;\" /></p>\n<p>邀请凭证：{{{itoken}}}，可手动接受邀请。</p>\n{{#icode}}\n<p>邀请码：{{{icode}}}，邀请码仅可使用一次，七天内有效。</p>\n{{/icode}}\n<p>记得安装后加我好友：{{{senderName}}}</p>\n<div class='info_div' style='margin-top: 50px;'>\n此信由“第一时间”系统发出，因此请勿直接回复。</div>\n<div class='info_div' style='text-align: right;'>“第一时间”运营团队</div>\n</div>\n</div>\n</div>\n</div>",
    "subtype" : "promote-invite-topic"

}
var phonealert = {
    "channel" : "phonealert",
    "content" : "我的项目 群组：“{{{target.name}}}”需要你，来和我一起参与“第一时间”吧，点击 {{{httpsite}}}/?t={{{itoken}}} 下载客户端，邀请凭证:{{{itoken}}}{{#icode}}，邀请码:{{{icode}}}{{/icode}}。\n记得安装后加我好友：{{{senderName}}}。",
    "subtype" : "promote-invite-topic"

}
reg_subtype(mailalert);
reg_subtype(phonealert);
