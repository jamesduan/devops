use bocdb;

alter table user_feedback_suggest add mobile varchar(20) DEFAULT NULL;
