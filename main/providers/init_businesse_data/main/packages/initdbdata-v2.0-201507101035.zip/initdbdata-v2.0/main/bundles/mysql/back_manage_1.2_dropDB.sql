use mysql
drop database  IF EXISTS bocdb;
drop database  IF EXISTS boc123;
drop database  IF EXISTS bochome;
drop database  IF EXISTS bocyun;
