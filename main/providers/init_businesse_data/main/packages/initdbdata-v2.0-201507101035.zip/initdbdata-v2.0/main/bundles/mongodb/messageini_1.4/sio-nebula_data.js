
db.messagetypes.remove({});
db.messagetypes.insert({  "type" : "sysnotice", "type_info" : { "zh-cn" : {  }, "zh-tw" : {  }, "en-us" : {  } }, "type_name" : { "zh-cn" : "系统通知", "zh-tw" : "", "en-us" : "System Notice" } });
db.messagetypes.insert({  "type" : "transremind", "type_info" : { "zh-cn" : {  }, "zh-tw" : {  }, "en-us" : {  } }, "type_name" : { "zh-cn" : "事务提醒", "zh-tw" : "", "en-us" : "Transcation Notice" } });
db.messagetypes.insert({ "type" : "findme", "type_info" : { "zh-cn" : {  }, "zh-tw" : {  }, "en-us" : {  } }, "type_name" : { "zh-cn" : "有人找我", "zh-tw" : "", "en-us" : "Findme Notice" } });
db.messagetypes.insert({ "type" : "sysmessage", "type_info" : { "zh-cn" : {  }, "zh-tw" : {  }, "en-us" : {  } }, "type_name" : { "zh-cn" : "系统消息", "zh-tw" : "", "en-us" : "Trade Notice" } });
 
db.messagesubtypes.remove({});
db.messagesubtypes.insert({
    "mtype": "sysmessage",
    "type": "cast-share",
    "type_name": {
        "zh-cn": "发送消息到手机或邮箱",
        "zh-tw":"",
        "en-us":"Send Message To Phone or Mail"
    },
    "type_info":{
        "zh-cn":"发送消息到手机或邮箱",
        "zh-tw":{},
        "en-us":{}
    },
    "version": "1.0",
    "data_vars":{
        "text":{
            "templateVar": "{{{text}}}",
            "example": "我分享了活动",
            "varName":"分享内容",
            "force": true
        }
    },
    "template_channels": ["mailalert", "phonealert"],
    "support_channels": ["mailalert", "phonealert"],
    "default_user_configs": {},
    "user_configable": false
});
db.messagesubtypes.insert({
    "mtype": "sysmessage",
    "type": "external-invite",
    "type_name": {
        "zh-cn": "活动场外邀请(通过手机邮箱邀请)",
        "zh-tw":"",
        "en-us":"external invite"
    },
    "type_info":{
        "zh-cn":"活动场外邀请(通过手机邮箱邀请)",
        "zh-tw":{},
        "en-us":{}
    },
    "version": "1.0",
    "template_channels": ["mailalert", "phonealert"],
    "support_channels": ["mailalert", "phonealert"],
    "default_user_configs": {},
    "user_configable": false
});
db.messagesubtypes.insert({
    "mtype": "sysmessage",
    "type": "download-app",
    "type_name": {
        "zh-cn": "手机短信下载app",
        "zh-tw":"",
        "en-us":"download app via sms"
    },
    "type_info":{
        "zh-cn":"手机短信下载app(通过手机)",
        "zh-tw":{},
        "en-us":{}
    },
    "version": "1.0",
    "template_channels": ["phonealert"],
    "support_channels": ["phonealert"],
    "default_user_configs": {},
    "user_configable": false
});
db.messagesubtypes.insert({
    "mtype": "sysmessage",
    "type": "icode-send",
    "type_name": {
        "zh-cn": "注册邀请函(通过手机邮箱邀请)",
        "zh-tw":"",
        "en-us":"register invite send"
    },
    "type_info":{
        "zh-cn":"注册邀请函(通过手机邮箱邀请)",
        "zh-tw":{},
        "en-us":{}
    },
    "version": "1.0",
    "template_channels": ["mailalert", "phonealert"],
    "support_channels": ["mailalert", "phonealert"],
    "default_user_configs": {},
    "user_configable": false
});
db.messagesubtypes.insert({
    "mtype": "sysmessage",
    "type": "icode-reinvite",
    "type_name": {
        "zh-cn": "再次封测邀请函(通过手机邮箱邀请)",
        "zh-tw":"",
        "en-us":"register invite send"
    },
    "type_info":{
        "zh-cn":"再次封测注册邀请函(通过手机邮箱邀请)",
        "zh-tw":{},
        "en-us":{}
    },
    "version": "1.0",
    "template_channels": ["mailalert", "phonealert"],
    "support_channels": ["mailalert", "phonealert"],
    "default_user_configs": {},
    "user_configable": false
});
db.messagesubtypes.insert({
    "mtype": "sysmessage",
    "type": "sec-verify",
    "type_name": {
        "zh-cn": "验证码校验",
        "zh-tw":"",
        "en-us":"secruity verify"
    },
    "type_info":{
        "zh-cn":"验证码校验",
        "zh-tw":{},
        "en-us":{}
    },
    "version": "1.0",
    "template_channels": ["phonealert"],
    "support_channels": ["phonealert"],
    "default_user_configs": {},
    "user_configable": false
});


var count = db.configs.count();
if(count > 3){
    db.configs.remove({});
    //print("remove", count, "configs");
}


var default_mobile_actions = {
    "android-app-download": "88"
}

var filter = {
    "type": "mobile-actions"
};
if(!db.configs.findOne(filter))
    db.configs.update(filter, {"$set": filter}, true);
var filter = {
    "type": "mobile-req-limits"
};
if(!db.configs.findOne(filter))
    db.configs.update(filter, {"$set": filter}, true);
var filter = {
    "type": "robot-auto-replies"
};
if(!db.configs.findOne(filter))
    db.configs.update(filter, {"$set": filter}, true);



for(var action_name in default_mobile_actions){
    var action_code = default_mobile_actions[action_name];
    var filter = {
        "type": "mobile-actions"
    };
    filter[action_name] = {
        "$exists": false
    }
    var update ={};
    update[action_name] = action_code;
    db.configs.update(filter, {"$set": update}, false);
}

var default_mobile_req_limits = {
    "ip-app-download-rate-limit": 60,
    "sms-app-download-rate-limit": 60
}

for(var limit_name in default_mobile_req_limits){
    var limit_val = default_mobile_req_limits[limit_name];
    var filter = {
        "type": "mobile-req-limits"
    };
    filter[limit_name] = {
        "$exists": false
    }
    var update ={};
    update[limit_name] = limit_val;
    db.configs.update(filter, {"$set": update}, false);
}

var default_robot_auto_replies = {
    "suggest-auto-reply": "您的建议我们已经收到，谢谢。",
    "complain-auto-reply": "您的投诉我们已经收到，谢谢。我们会尽快处理您的投诉。",
    "report-auto-reply": "收到，谢谢。我们会尽快处理。",
    "robot-welcome-msg": "欢迎来到必播家园。必播家园，我要必播。",
    "robot-topic-remind-msg": "快和你的小伙伴一起互动吧，点\“我的关系\”可以添加好友哦。",
    "robot-im-remind-msg": "欢迎来到必播家园。如果你在使用过程中有任何问题和建议，记得给我发信反馈哦。",
    "dispute-auto-reply": "收到，谢谢。我们会尽快处理。",
    "suggest-auto-reply-im": "您的建议我们已经收到，谢谢。",
    "complain-auto-reply-im": "您的投诉我们已经收到，谢谢。我们会尽快处理您的投诉。",
    "report-auto-reply-im": "收到，谢谢。我们会尽快处理。",
    "dispute-auto-reply-im": "收到，谢谢。我们会尽快处理。",
    "suggest-auto-welcome": "您的建议我们已经收到，谢谢。",
    "complain-auto-welcome": "您的投诉我们已经收到，谢谢。我们会尽快处理您的投诉。",
    "report-auto-welcome": "收到，谢谢。我们会尽快处理。",
    "dispute-auto-welcome": "收到，谢谢。我们会尽快处理。"
}

for(var limit_name in default_robot_auto_replies){
    var limit_val = default_robot_auto_replies[limit_name];
    var filter = {
        "type": "robot-auto-replies"
    };
    filter[limit_name] = {
        "$exists": false
    }
    var update ={};
    update[limit_name] = limit_val;
    db.configs.update(filter, {"$set": update}, false);
}





﻿//
var db = connect(db.hostInfo().system.hostname+"/sio-nebula");

var go_browsing = false;
var reads_info_count = 0;

function basic_message_ajust(basic_message){
    delete basic_message._id;
	var msg_id = basic_message.msg_id;
	basic_message.create_time = basic_message.date.getTime();
	basic_message.last_update_time = basic_message.create_time;
	basic_message.comments_count = 0;
	basic_message.share_count = 0;
	basic_message.recast_count = 0;
    basic_message.version = "1.0";
	var read_dates = basic_message.read_dates;
	if(read_dates && read_dates.length > 0){
		for(var k = 0; k < read_dates.length; k++){
			var read_date = read_dates[k];
			var user_id = Number(read_date.split("_")[0]);
			var date = Number(read_date.split("_")[1]);
			if(!go_browsing){
				var message_record = {
					"msg_id": msg_id,
					"create_time": date,
					"user_id": user_id,
					"action": "read"
				};
				db.message_records.update(message_record, {"$set": message_record}, true, true);
			}
          reads_info_count ++;
		}
	}
}


//////////////////////////////////////
//print("1.==>>开始修复私聊消息");
priv_chat_messages_count = 0;
priv_chat_recovered_messages_count = 0;
var query = {
    "version": null,
	"subtype": "cast-share",
    "destination.type": "cast",
	"destination.info.profile": "individual-sharedtome"
};
var priv_chat_messages = db.messages.find(query);
priv_chat_messages.forEach(function(priv_chat_message){
	priv_chat_messages_count++;
	var msg_id = priv_chat_message.msg_id;
    var backed = db.messages_backup.findOne({"msg_id": msg_id}); if(!backed) db.messages_backup.save(priv_chat_message);
	try{
		var user_id = priv_chat_message.source.info[0];
		var peer_user_id = priv_chat_message.destination.info[0].host_id;
		basic_message_ajust(priv_chat_message);
		priv_chat_message.type = "chat";
		priv_chat_message.subtype = "priv-chat";
		priv_chat_message.refer_user_ids = [user_id, peer_user_id];
		if(!go_browsing){
			db.messages.update({"msg_id": msg_id}, {"$set": priv_chat_message}, true, true);
		}
		if(priv_chat_messages_count % 100 == 0){
			//print("正在扫描",priv_chat_messages_count,"条消息");
		}
		priv_chat_recovered_messages_count ++;
	}catch(e){
		//print("priv_chat_messages recover error", e, "msg_id = ", msg_id);
	}
});
priv_chat_messages = null;
//print//print("1.<<==修复私聊消息完成：共", priv_chat_messages_count, "条消息，成功修复",priv_chat_recovered_messages_count, "条消息。");


//////////////////////////////////////
//print//print("2.==>>开始修复用户私聊信息");
//print//print("2.<<==完成修复用户私聊信息");


//////////////////////////////////////
//print//print("3.==>>开始修复主题聊天消息");
topic_chat_messages_count = 0;
topic_chat_recovered_messages_count = 0;
topic_chat_recovered_suggestions_count = 0;
var query = {
    "version": null,
	"subtype": "cast-share",
    "destination.type": "cast",
	"destination.info.profile": "topic-msg"
};
var topic_chat_messages = db.messages.find(query);
topic_chat_messages.forEach(function(topic_chat_message){
	topic_chat_messages_count++;
	var msg_id = topic_chat_message.msg_id;
    var backed = db.messages_backup.findOne({"msg_id": msg_id}); if(!backed) db.messages_backup.save(topic_chat_message);
	try{
		var user_id = topic_chat_message.source.info[0];
		var topic_id = topic_chat_message.destination.info[0].host_id;
		basic_message_ajust(topic_chat_message);
		topic_chat_message.type = "cast";
        if(!((typeof topic_id) == "number")){
            true_topic_id = Number(topic_id.split("_")[0]);
            true_user_id = Number(topic_id.split("_")[1]);
            topic_chat_message.destination.info[0].host_id = true_topic_id;
            topic_chat_message.message_permissions = { 
                "read" : {
                    "owner" : "limit", 
                    "user_ids" : [true_user_id] 
                }
            }
            topic_chat_recovered_suggestions_count ++;
        }
		if(!go_browsing){
			db.messages.update({"msg_id": msg_id}, {"$set": topic_chat_message}, true, true);
		}
		if(topic_chat_messages_count % 100 == 0){
			//print("正在扫描",topic_chat_messages_count,"条消息");
		}
		topic_chat_recovered_messages_count ++;
	}catch(e){
		//print("topic_chat_messages recover error", e, "msg_id = ", msg_id);
	}
});
topic_chat_messages = null;
//print("3.<<==修复主题聊天消息完成：共", topic_chat_messages_count, "条消息，成功修复",topic_chat_recovered_messages_count, "条消息。");

//////////////////////////////////////
//print("4.==>>开始修复主题动态消息");
topic_as_messages_count = 0;
topic_as_recovered_messages_count = 0;
var query = {
    "version": null,
	"subtype": "activity-stream",
    "destination.type": "cast",
	"destination.info.profile": "topic-as"
};
var topic_as_messages = db.messages.find(query);
topic_as_messages.forEach(function(topic_as_message){
	topic_as_messages_count++;
	var msg_id = topic_as_message.msg_id;
    var backed = db.messages_backup.findOne({"msg_id": msg_id}); if(!backed) db.messages_backup.save(topic_as_message);
	try{
		var user_id = topic_as_message.source.info[0];
		var topic_id = topic_as_message.destination.info[0].host_id;
		basic_message_ajust(topic_as_message);
		topic_as_message.type = "cast";
		topic_as_message.data.as_obj = topic_as_message.data.as_ori;
		delete topic_as_message.data.as_ori;
		if(!go_browsing){
			db.messages.update({"msg_id": msg_id}, {"$set": topic_as_message}, true, true);
		}
		if(topic_as_messages_count % 100 == 0){
			//print("正在扫描",topic_as_messages_count,"条消息");
		}
		topic_as_recovered_messages_count ++;
	}catch(e){
		//print("topic_as_messages recover error", e, "msg_id = ", msg_id);
	}
});
topic_as_messages = null;
//print("4.<<==修复主题动态消息完成：共", topic_as_messages_count, "条消息，成功修复",topic_as_recovered_messages_count, "条消息。");


//////////////////////////////////////
//print("5.==>>开始修复用户主题信息");
user_topicchat_items_count = 0;
user_topicchat_items = db.userstreamactions.find({"first_action_date":{"$ne":null}, "action_type": "topics"});
//db.user_topicchat_items.find
user_topicchat_items.forEach(function(user_topicchat_item){
    var create_time = user_topicchat_item.first_action_date.getTime();
    var user_id = user_topicchat_item.user_id;
    var last_update_time = new Date().getTime();
    var parent_id = 0;
    var topic_id = -9;
    var topic_type = "task";
    var unread = 0;
    var unreadtotal = 0;
    var user_topicchat_item = {
        "create_time": create_time,
        "user_id": user_id,
        "last_update_time": last_update_time,
        "parent_id": parent_id,
        "topic_id": topic_id,
        "topic_type": topic_type,
        "unread": unread,
        "unreadtotal": unreadtotal
    };
    if(!go_browsing){
        db.user_topicchat_items.update({"user_id": user_id, "topic_id": topic_id}, {"$set": user_topicchat_item}, true, true);
    }
    if(user_topicchat_items_count % 10 == 0){
        //print("正在扫描",user_topicchat_items_count,"条主题信息");
    }
    user_topicchat_items_count ++;
});
user_topicchat_items = null
//print("5.<<==完成修复用户主题信息,-9主题用户个数：", user_topicchat_items_count);


//////////////////////////////////////
//print("6.==>>开始修复评论消息");
topic_comment_messages_count = 0;
topic_comment_recovered_messages_count = 0;
var query = {
    "version": null,
	"subtype": "cast-comment",
    "destination.type": "msg"
};
var topic_comment_messages = db.messages.find(query);
topic_comment_messages.forEach(function(topic_comment_message){
	topic_comment_messages_count++;
	var msg_id = topic_comment_message.msg_id;
    var backed = db.messages_backup.findOne({"msg_id": msg_id}); if(!backed) db.messages_backup.save(topic_comment_message);
	try{
		var user_id = topic_comment_message.source.info[0];
		var target_msg_id = topic_comment_message.destination.info[0];
		basic_message_ajust(topic_comment_message);
		topic_comment_message.type = "cast";
		topic_comment_message.data.as_obj = topic_comment_message.data.as_ori;
		delete topic_comment_message.data.as_ori;
		topic_comment_message.target_msg_id = target_msg_id;
		if(!go_browsing){
			db.messages.update({"msg_id": msg_id}, {"$set": topic_comment_message}, true, true);
		}
		var target_message = db.messages.findOne({"msg_id": target_msg_id});
		if(target_message && !go_browsing){
			target_message.comments_count ++;
            delete target_message._id;
			db.messages.update({"msg_id": target_msg_id}, {"$set": target_message}, true, true);
		}
		if(topic_comment_messages_count % 100 == 0){
			//print("正在扫描",topic_comment_messages_count,"条消息");
		}
		topic_comment_recovered_messages_count ++;
	}catch(e){
		//print("topic_comment_messages recover error", e, "msg_id = ", msg_id);
	}
});
topic_comment_messages = null;
//print("6.<<==修复评论消息完成：共", topic_comment_messages_count, "条消息，成功修复",topic_comment_recovered_messages_count, "条消息。");




//print("修复完成, 成功修复:");
//print(priv_chat_recovered_messages_count, "条私聊消息");
//print(topic_chat_recovered_messages_count, "条主题聊天消息");
//print(topic_chat_recovered_suggestions_count, "条建议消息"); 
//print(user_topicchat_items_count, "条用户主题信息");
//print(topic_as_recovered_messages_count, "条主题动态消息");
//print(topic_comment_recovered_messages_count, "条主题评论消息");
//print(reads_info_count, "条已读信息");















