var mailalert = {
     "channel" : "mailalert",
     "format" : "html",
     "content" : "<div class='preview_div'\r\n\tstyle='width: 700px; background-color: rgba(47, 150, 220, 0.5); font-size: 14px; line-height: 30px;'>\r\n<div class='preview_content' style='padding: 60px 40px; margin: 0 auto;'>\r\n<div class='middle_div'\r\n\tstyle='min-height: 500px; background-color: white; padding: 20px 30px;'>\r\n<div class='content_div'>\r\n<p>嗨：</p>\r\n<p style='margin-left: 30px;'>请第一时间来和我一起加入“{{{target.name}}}”吧！</p>\r\n<p>1.直接点击： <a href='{{{httpsite}}}/?itoken={{{itoken}}}'>{{{httpsite}}}/?itoken={{{itoken}}}</a>或扫描下方二维码下载。\r\n</p>\r\n<p>2.{{#icode}}封测邀请码：{{{icode}}}，{{/icode}}邀请凭证：{{{itoken}}}。</p>\r\n<p>3.搜索“{{{senderName}}}”可以找到我。</p>\r\n<p style='text-align: right;'>谢谢！</p>\r\n<p><img src='{{{httpsite}}}/download_qrcode/?itoken={{{itoken}}}'\r\n\theight=\"132px;\" width=\"132px;\" /></p>\r\n<div class='info_div' style='text-align: right;'>bibo 第一时间</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>",

    "subtype" : "promote-invite-topic"

}
var phonealert = {
    "channel" : "phonealert",
    "content" : "请第一时间来和我一起加入“{{{target.name}}}”吧，\n点击{{{httpsite}}}/?t={{{itoken}}} 下载\n{{#icode}}封测邀请码：{{{icode}}}{{/icode}}\n搜索“{{{senderName}}}”来找我。",

    "subtype" : "promote-invite-topic"

}
reg_subtype(mailalert);
reg_subtype(phonealert);
