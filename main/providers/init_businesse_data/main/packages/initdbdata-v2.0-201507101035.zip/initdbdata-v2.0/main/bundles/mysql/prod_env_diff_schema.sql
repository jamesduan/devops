use topicdb
alter table topic_entity modify column `time_started` bigint(13) DEFAULT NULL;

alter table topic_entity modify column `remark` text DEFAULT NULL;



use sysadmin;
alter table org add column org_uid              varchar(32) default '',
drop table if exists pvo_client_ext_info;
create table pvo_client_ext_info
(
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(32) NOT NULL,
  `AuthType`        enum('UseWhitelist','UseBlacklist','UserRuleExpr')  DEFAULT 'UseWhitelist',
  `RuleExpress`      varchar(512) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

drop table if exists user_app_mapping_auth;
create table user_app_mapping_auth
(
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(32) NOT NULL,
  `RegisterUerID`        bigint(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

drop table if exists individual;
create table individual
(
   indiv_id             bigint(40) not null,
   real_name            varchar(20) default NULL,
   gender               enum('male','female') default NULL,
   birthdate_year       varchar(5) default NULL,
   birthdate_month      varchar(2) default NULL,
   birthdate_day        varchar(2) default NULL,
   phone                varchar(20) default NULL,
   deleted              tinyint(1) default 0,
   deleted_by           varchar(256) default NULL,
   deleted_at           timestamp not null default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
   blog_url             varchar(100) default NULL,
   qq                   varchar(30) default NULL,
   industry             varchar(100) default NULL,
   zodiac_sign          enum('aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces') default NULL,
   safety_info          varchar(500) default NULL,
   register_user_id     bigint(40) DEFAULT NULL,
   primary key (indiv_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*20150518*/
use sysadmin;
drop table if exists OrgMember;
create table OrgMember
(
   OrgMemberID          bigint(40) NOT NULL ,
   OrgID                bigint(40) DEFAULT NULL,
   HolderID             bigint(40) DEFAULT NULL,
   CreatorID            bigint(40) DEFAULT NULL,
   CreatedDatetime      bigint(40) DEFAULT NULL,
   isFrozen             bool DEFAULT NULL,
   FrozenDatetime       bigint(40) DEFAULT NULL,
   isDeleted            bool DEFAULT NULL,
   DeletedDatetime      bigint(40) DEFAULT NULL,
   FromSourceTypeID     bigint(40) DEFAULT NULL,
   PersonalUserID       bigint(40) DEFAULT NULL,
   MemberMobile         varchar(64) DEFAULT NULL,
   MemberEmail          varchar(128) DEFAULT NULL,
   WorkNO               int(20) DEFAULT NULL,
   DepartmentInfo       varchar(512) DEFAULT NULL,
   OrgMemberSetting     varchar(1024) DEFAULT NULL,
   PRIMARY KEY (`OrgMemberID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



drop table if exists OrgMemberActionType;

create table OrgMemberActionType
(
   OrgMemberActionTypeID bigint(40) NOT NULL AUTO_INCREMENT,
   Name                 varchar(128) DEFAULT NULL,
   primary key (`OrgMemberActionTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;

drop table if exists OrgMemberFromSourceType;
create table OrgMemberFromSourceType
(
   OrgMemberFromSourceTypeID bigint(40) NOT NULL AUTO_INCREMENT,
   Name                 varchar(128) DEFAULT NULL,
   primary key (`OrgMemberFromSourceTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;

drop table if exists OrgMemberOperation;
create table OrgMemberOperation
(
   OrgMemberOperationID bigint(40) not null auto_increment,
   TargetOrgMemberID    bigint(40) DEFAULT NULL,
   OrgMemberActionTypeID bigint(40) DEFAULT NULL,
   ActionInfo           varchar(1024) DEFAULT NULL,
   OperatorID           bigint(40) DEFAULT NULL,
   ActionChannelID      bigint(40) DEFAULT NULL,/*20150609*/
   OperationDatetime    bigint(40) DEFAULT NULL,
   isSuccessful         bool DEFAULT NULL,
   primary key (`OrgMemberOperationID`)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;


drop table if exists OrgMemberRole;
create table OrgMemberRole
(
   OrgMemberRoleID      bigint(40) not null auto_increment,
   OrgID                bigint(40) DEFAULT NULL,
   RoleType             enum('SysDefault','UserDefined') DEFAULT NULL,
   RoleTitle            varchar(128) DEFAULT NULL,
   PrivilegeLevel       int(11) DEFAULT NULL,
   Permission           varchar(1024) DEFAULT NULL,
   primary key (OrgMemberRoleID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;



drop table if exists OrgMemberRoleMapping;
create table OrgMemberRoleMapping
(
   OrgMemberRoleMappingID bigint(40) not null auto_increment,
   OrgMemberID          bigint(40) DEFAULT NULL,
   OrgMemberRoleID      bigint(40) DEFAULT NULL,
   CreatedDatetime      bigint(40) DEFAULT NULL,
   CreatorID            bigint(40) DEFAULT NULL,
   primary key (OrgMemberRoleMappingID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;


alter table register_user add column individual_id        bigint(40) DEFAULT NULL;
alter table register_user add column RegisterType         enum('Original','FromOrgMember') DEFAULT NULL;
alter table register_user add column RegisterDatetime     bigint(40) DEFAULT NULL;
alter table register_user add column AgentOfOrgID         bigint(40) DEFAULT NULL;

--alter table register_user add constraint `fk_user_district` foreign key (`district_id`) references `common_district` (`id`);



/*20150609*/
use sysadmin;
drop table if exists InfraActionChannel;
create table InfraActionChannel
(
   InfraActionChannelID bigint(40) not null auto_increment,
   Name                 varchar(128) default NULL,
   primary key (InfraActionChannelID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

drop table if exists SecurityActionType;
create table SecurityActionType
(
   SecurityActionTypeID bigint(40) not null auto_increment,
   Name                 varchar(128) DEFAULT NULL,
   primary key (SecurityActionTypeID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;

drop table if exists OrgSecurityLog;
create table OrgSecurityLog
(
   OrgSecurityLogID     bigint(40) not null auto_increment,
   OrgID                bigint(40) DEFAULT NULL,
   SecurityActionTypeID bigint(40) DEFAULT NULL,
   ActorID              bigint(40) DEFAULT NULL,
   ActionInfo           varchar(1024) DEFAULT NULL,
   ActionDatetime       bigint(40) DEFAULT NULL,
   primary key (OrgSecurityLogID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;


use topicdb

drop table if exists SecurityActionType;
create table SecurityActionType
(
   SecurityActionTypeID bigint(40) not null auto_increment,
   Name                 varchar(128) DEFAULT NULL,
   primary key (SecurityActionTypeID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;


drop table if exists IssueSecurityLog;
create table IssueSecurityLog
(
   IssueSecurityLogID   bigint(40) not null auto_increment,
   IssueID              bigint(40) DEFAULT NULL,
   SecurityActionTypeID bigint(40) DEFAULT NULL,
   ActorID              bigint(40) DEFAULT NULL,
   ActionInfo           varchar(1024) DEFAULT NULL,
   ActionDatetime       bigint(40) DEFAULT NULL,
   primary key (IssueSecurityLogID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;


drop table if exists TopicSecurityLog;
create table TopicSecurityLog
(
   TopicSecurityLogID   bigint(40) not null auto_increment,
   SecurityActionTypeID bigint(40) not null,
   TopicEntityID        bigint(40) DEFAULT NULL,
   ActorID              bigint(40) DEFAULT NULL,
   ActionInfo           varchar(1024) DEFAULT NULL,
   ActionDatetime       bigint(40) DEFAULT NULL,
   primary key (TopicSecurityLogID, SecurityActionTypeID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;

alter table issue_security_setting add column allow_capture_screen bool DEFAULT NULL;

alter table org_security_setting add column allow_capture_screen bool DEFAULT NULL;

alter table topic_security_setting add column allow_capture_screen bool DEFAULT NULL;


/*20150611*/
use topicdb
alter table check_point modify column `content` text DEFAULT NULL;


/*20150615*/
use sysadmin;

drop table if exists OrgSecuritySetting;
create table OrgSecuritySetting
(
   OrgSecuritySettingID bigint(40) not null auto_increment,
   OrgID                bigint(40) DEFAULT NULL,
   AllowMemberShareOutFromOrg bool DEFAULT NULL,
   AllowMemberCaptureScreen bool DEFAULT NULL,
   Setting              varchar(2048) DEFAULT NULL,
   primary key (OrgSecuritySettingID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*20150703*/
use topicdb
drop table if exists OrgHotTopicBoard;
create table OrgHotTopicBoard
(
   OrgHotTopicBoardID   bigint(40) not null auto_increment,
   OrgID                bigint(40) DEFAULT NULL,
   Setting              varchar(2048) DEFAULT NULL,
   MaxHotTopicNum       int(20) DEFAULT NULL,
   FirstActiveDatetime  bigint(40) DEFAULT NULL,
   primary key (OrgHotTopicBoardID)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

drop table if exists OrgTopicHotMapping;
create table OrgTopicHotMapping
(
   OrgTopicHotMappingID bigint(40) not null auto_increment,
   TopicBoardID         bigint(40) DEFAULT NULL,
   OrgID                bigint(40) DEFAULT NULL,
   TopicID              bigint(40) DEFAULT NULL,
   DisplayOrderNO       int(20) DEFAULT NULL,
   CreatorID            bigint(40) DEFAULT NULL,
   CreatedDatetime      timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
   primary key (OrgTopicHotMappingID)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


/*20150707*/
use sysadmin;

drop table if exists OrgUserSetting;
create table OrgUserSetting
(
   OrgUserSettingID     bigint not null auto_increment,
   OrgID                bigint(40) DEFAULT NULL,
   UserType             enum('RegisterUser','OrgMember','Org','Misc') DEFAULT NULL,
   UserID               bigint(40) DEFAULT NULL,
   Setting              varchar(2048) DEFAULT NULL,
   isTop                bool DEFAULT NULL,
   SetTopDatetime       timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
   primary key (OrgUserSettingID)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


alter table org add column RegisterType         enum('Original','FromOrgMember')  DEFAULT NULL;
alter table org add column ParentOrgID          bigint(40) DEFAULT NULL;
alter table org add column TotalMemberCount     int(20) DEFAULT NULL;
alter table org add column ActivedMemberCount   int(20) DEFAULT NULL;
alter table org add column FrozenMemberCount    int(20) DEFAULT NULL;
alter table org add column FacadeVisitedCount   int(20) DEFAULT NULL;
alter table org add column OwnedMerchantID      bigint(40) DEFAULT NULL;
alter table org add column LastUpdateTime       timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
alter table OrgMember add column LastUpdatetime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
