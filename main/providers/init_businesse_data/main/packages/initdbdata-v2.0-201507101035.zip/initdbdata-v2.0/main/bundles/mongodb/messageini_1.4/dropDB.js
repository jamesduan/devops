
db.dropDatabase();
