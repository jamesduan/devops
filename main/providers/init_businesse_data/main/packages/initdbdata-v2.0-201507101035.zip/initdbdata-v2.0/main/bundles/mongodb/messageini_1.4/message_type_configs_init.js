var db = connect(db.hostInfo().system.hostname+"/sio-nebula");
function reg_subtype(subtype_obj){
    var subtype = subtype_obj.subtype;
    var channel = subtype_obj.channel;
    print("reg subtype", subtype);
    db.message_type_configs.update({"subtype": subtype,"channel":channel}, {"$set": subtype_obj}, true, true);
};
load("./reg_type_configs_icode-send.js")
load("./reg_type_configs_promote-invite-site.js")
load("./reg_type_configs_promote-invite-org.js")
load("./reg_type_configs_promote-invite-topic.js")
load("./reg_type_configs_promote-invite-issue.js")
