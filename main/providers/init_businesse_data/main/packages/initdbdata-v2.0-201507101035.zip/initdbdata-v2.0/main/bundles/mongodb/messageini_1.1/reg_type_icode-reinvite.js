var subtype = {
    "subtype": "icode-reinvite",
    "name": "封测再次邀请",
    "desc": "通过手机或邮箱再次发送封测邀请",
    "enable": true,
    "support_mail_channel": true,
    "support_sms_channel": true,
    "data_vars":[
        {
            "name": "被邀请称谓",
            "label": "invitee_name",
            "example": "张三",
            "force": "all"
        },
        {
            "name": "被邀请人的用户名",
            "label": "register_user.username",
            "example": "tom",
            "force": "all"
        },
        {
            "name": "封测开始时间",
            "label": "iRegStartTime",
            "example": "1402922598057",
            "force": "all"
        },
        {
            "name": "封测结束时间",
            "label": "iRegEndTime",
            "example": "1405514598057",
            "force": "all"
        },
        {
            "name": "封测时间",
            "label": "iRegTime",
            "example": "2592000000",
            "force": "all"
        }
    ],
    "mail_config": {
        "subject": "封测再次邀请",
        "content": "“第一时间”再次诚邀您参与封测，客户端下载地址:[{{{httpsite}}}/mobile/download/mybibo]。直接使用用户名{{{register_user.username}}}登录进行测试.期待您多提些宝贵建议和意见，以便我们更好的完善及改进。谢谢。",
        "format": "html"
    },
    "sms_config":{
        "content": "“第一时间”再次诚邀您参与封测，客户端下载地址:[{{{httpsite}}}/mobile/download/mybibo]。直接使用用户名{{{register_user.username}}}登录进行测试.期待您多提些宝贵建议和意见，以便我们更好的完善及改进。谢谢。",
    }
}
reg_subtype(subtype);










