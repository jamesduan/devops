var subtype = {
    "subtype": "activate-verify",
    "name": "激活验证",
    "desc": "手机或邮箱绑定时发送验证码",
    "enable": true,
    "support_mail_channel": true,
    "support_sms_channel": true,
    "data_vars":[
        {
            "name":"激活用户名字",
            "label": "receiverName",
            "example": "李四",
            "force": "all"
        },
        {
            "name": "验证码",
            "label": "activateCode",
            "example": "201407",
            "force": "all"
        },
        {
            "name":"验证有效秒数",
            "label": "expireSeconds",
            "example": "60",
            "force": "all"
        }
    ],
    "mail_config": {
        "subject": "【第一时间】邮箱绑定确认",
        "content": "亲爱的用户{{{receiverName}}}：\n感谢您使用第一时间，您正尝试绑定该邮箱。如果您确认绑定，请点\n{{{httpsite}}}/verifyemail/?verify_code={{{activateCode}}}\n本邮件有效期为{{{expireHours}}}小时。\n如果这不是您的邮件，请直接忽略。",
        "format": "text"
    },
    "sms_config":{
        "content": "亲爱的用户{{{receiverName}}}，第一时间提醒您，您在第一时间尝试绑定您的手机{{{receiverPhoneNumber}}}，验证码为{{{activateCode}}}，验证码将在{{{expireSeconds}}}秒后过期。"
    }
}
reg_subtype(subtype);










