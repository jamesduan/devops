use topicdb
update topicdb.label set label_name='满意' where label_id=1;
update topicdb.label set label_name='满意' where label_id=2;
update topicdb.label set label_name='尚可(继续努力)' where label_id=3;
update topicdb.label set label_name='还不满意' where label_id=4;
update topicdb.label set label_name='很烂' where label_id=5;




/*20150518*/
use sysadmin;

insert into OrgMemberActionType VALUES (1,'orgMember.Invite');
insert into OrgMemberActionType VALUES (2,'orgMember.AcceptInvitation');
insert into OrgMemberActionType VALUES (3,'orgMember.RefuseInvitation');
insert into OrgMemberActionType VALUES (4,'orgMember.KickOff');
insert into OrgMemberActionType VALUES (5,'orgMember.Role.Assign');
insert into OrgMemberActionType VALUES (6,'orgMember.Role.Reassign');
insert into OrgMemberActionType VALUES (7,'OrgMember.Role.Unassign');
insert into OrgMemberActionType VALUES (8,'OrgMember.Freeze');
insert into OrgMemberActionType VALUES (9,'OrgMember.Unfreeze');

insert into OrgMemberFromSourceType VALUES (1,'from.OrgCreator');
insert into OrgMemberFromSourceType VALUES (2,'from.MobileLocalContact');
insert into OrgMemberFromSourceType VALUES (3,'from.FriendsList');
insert into OrgMemberFromSourceType VALUES (4,'from.Scan.QRCode');
insert into OrgMemberFromSourceType VALUES (5,'from.Handwrite.mobile');
insert into OrgMemberFromSourceType VALUES (6,'from.Handwrite.email');
insert into OrgMemberFromSourceType VALUES (7,'from.Other');

drop table if exists OrgMemberRole;
create table OrgMemberRole
(
   OrgMemberRoleID      bigint(40) not null auto_increment,
   OrgID                bigint(40) DEFAULT NULL,
   RoleType             enum('SysDefault','UserDefined') DEFAULT NULL,
   RoleTitle            varchar(128) DEFAULT NULL,
   PrivilegeLevel       int(11) DEFAULT NULL,
   Permission           varchar(1024) DEFAULT NULL,
   primary key (OrgMemberRoleID)
) ENGINE=InnoDB AUTO_INCREMENT=1  DEFAULT CHARSET=utf8;

insert into OrgMemberRole VALUES (1,null,'SysDefault','Owner',null,null);
insert into OrgMemberRole VALUES (2,null,'SysDefault','Admin',null,null);
insert into OrgMemberRole VALUES (3,null,'SysDefault','Employee',null,null);
insert into OrgMemberRole VALUES (4,null,'SysDefault','TempMember/Incomer',null,null);


/*20150609*/
use sysadmin
insert into SecurityActionType VALUES (1,'SecurityActionType.EntitySecuritySetting');
insert into SecurityActionType VALUES (2,'SecurityActionType.RoleSetting');

use topicdb
insert into SecurityActionType VALUES (1,'SecurityActionType.EntitySecuritySetting');
insert into SecurityActionType VALUES (2,'SecurityActionType.RoleSetting');
