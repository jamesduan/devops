var subtype = {
    "subtype": "icode-send",
    "name": "封测邀请",
    "desc": "通过手机或邮箱发送封测邀请",
    "enable": true,
    "support_mail_channel": true,
    "support_sms_channel": true,
    "data_vars":[
        {
            "name": "被邀请称谓",
            "label": "invitee.name",
            "example": "张三",
            "force": "all"
        },
        {
            "name": "邀请码",
            "label": "icode",
            "example": "201400",
            "force": "all"
        },
        {
            "name": "邀请凭证",
            "label": "itoken",
            "example": "20140033333",
            "force": "all"
        },
        {
            "name": "封测开始时间",
            "label": "iRegStartTime",
            "example": "1402922598057",
            "force": "all"
        },
        {
            "name": "封测结束时间",
            "label": "iRegEndTime",
            "example": "1405514598057",
            "force": "all"
        },
        {
            "name": "封测时间",
            "label": "iRegTime",
            "example": "2592000000",
            "force": "all"
        }
    ],
    "mail_config": {
        "subject": "封测邀请",
        "content": "<div>“第一时间”诚邀您参与{{#icode}}封测{{/icode}}，点击 {{{httpsite}}}/?t={{{itoken}}} 下载客户端{{#icode}}，邀请码:{{{icode}}}{{/icode}}。</div>",
        "format": "html"
    },
    "sms_config":{
        "content": "“第一时间”诚邀您参与{{#icode}}封测{{/icode}}，点击 {{{httpsite}}}/?t={{{itoken}}} 下载客户端{{#icode}}，邀请码:{{{icode}}}{{/icode}}。"
    }
}
reg_subtype(subtype);










