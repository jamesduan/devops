var subtype = {
    "subtype": "sec-verify",
    "name": "安全验证",
    "desc": "敏感操作时需要的安全验证",
    "enable": true,
    "support_mail_channel": true,
    "support_sms_channel": true,
    "data_vars":[
        {
            "name": "验证码",
            "label": "activateCode",
            "example": "201407",
            "force": "all"
        },
        {
            "name": "验证码过期时间(秒)",
            "label": "expireSeconds",
            "example": "600",
            "force": "all"
        },
        {
            "name": "验证码过期时间(分钟)",
            "label": "expireMinutes",
            "example": "10",
            "force": "all"
        }
    ],
    "mail_config": {
        "subject": "【第一时间】邮箱验证",
        "content": "您的验证码：{{{activateCode}}}。您的验证码将在{{{expireMinutes}}}分钟后过期。",
        "format": "text"
    },
    "sms_config":{
        "content": "您的验证码：{{{activateCode}}}。您的验证码将在{{{expireMinutes}}}分钟后过期。"
    }
}
reg_subtype(subtype);










