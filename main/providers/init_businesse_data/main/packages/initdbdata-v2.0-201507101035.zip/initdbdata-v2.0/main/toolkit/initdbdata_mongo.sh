#!/bin/bash -ex
source $initdbdatatoolkit/bundle.ini

today=`date +%Y%m%d`
timestamp=`date +%s`
bakmongofile="bakmongo_"$today"_"$timestamp

${mongocmd}mongodump  -o $bakmongofile 
echo  '-------------drop mongodb checklist:----------------'$bundle_dropmongodb
${mongocmd}mongo  $bundle_dropmongodb
echo  '-------------drop mongodb sio:----------------'$bundle_dropmongodb
${mongocmd}mongo  $bundle_dropmongodb
echo  '-------------create mongodb checklist:----------------'$bundle_checklist_initdata
${mongocmd}mongo  $bundle_checklist_initdata
echo  '-------------create mongodb sio:----------------'$bundle_sio_initdata

cd $init_mongobundles
${mongocmd}mongo  $bundle_message_initdata
${mongocmd}mongo  $bundle_sio_initdata

${mongocmd}mongo  $bundle_messagedel
${mongocmd}mongo  $bundle_message_type_configs_initdata
