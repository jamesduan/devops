var mailalert = {
    "channel" : "mailalert",
    "content" : "<div class='preview_div'\n\tstyle='width: 700px; background-color: rgba(47, 150, 220, 0.5); font-size: 14px; line-height: 30px;'>\n<div class='preview_content' style='padding: 60px 40px; margin: 0 auto;'>\n<div class='middle_div'\n\tstyle='min-height: 500px; background-color: white; padding: 20px 30px;'>\n<div class='content_div'>\n<p>嗨：</p>\n<p style='margin-left: 30px;'>请第一时间来和我一起参与封测吧！</p>\n<p>1.直接点击： <a href='{{{httpsite}}}/?itoken={{{itoken}}}'>{{{httpsite}}}/?itoken={{{itoken}}}</a>或扫描下方二维码下载。\n<br />\n</p>\n<p>2.{{#icode}}邀请码：{{{icode}}}，{{/icode}}邀请凭证：{{{itoken}}}。</p>\n<p>3.搜索“{{{senderName}}}”可以找到我。</p>\n<p style='text-align: right;'>谢谢！</p>\n<p><img src='{{{httpsite}}}/download_qrcode/?itoken={{{itoken}}}'\n\theight=\"132px;\" width=\"132px;\" /></p>\n<div class='info_div' style='text-align: right;'>bibo 第一时间</div>\n</div>\n</div>\n</div>\n</div>",

    "format" : "html",
    "subtype" : "promote-invite-site"
}
var phonealert = {
    "channel" : "phonealert",
    "content" : "请第一时间来和我一起参与封测吧！点击{{{httpsite}}}/?t={{{itoken}}} 下载\n{{#icode}}邀请码：{{{icode}}}{{/icode}}\n搜索“{{{senderName}}}”来找我。",

    "subtype" : "promote-invite-site"
}
reg_subtype(mailalert);
reg_subtype(phonealert);
