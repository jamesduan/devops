var db = connect(db.hostInfo().system.hostname+"/sio-nebula");
function reg_subtype(subtype_obj){
    var subtype = subtype_obj.subtype;
    print("reg subtype", subtype);
    db.message_types.update({"subtype": subtype}, {"$set": subtype_obj}, true, true);
};
function reg_simple_notification(subtype){
    var subtype_obj = {
        "subtype": subtype,
        "name": subtype,
        "desc": subtype,
        "enable": true,
        "support_mail_channel": false,
        "support_sms_channel": false
    };
    reg_subtype(subtype_obj);
};
load("./reg_type_activate-verify.js")
load("./reg_type_passwd-reset.js")
load("./reg_type_sec-verify.js")
load("./reg_type_icode-send.js")
load("./reg_type_icode-reinvite.js")
load("./reg_type_promote-invite-site.js")
load("./reg_type_promote-invite-org.js")
load("./reg_type_promote-invite-topic.js")
load("./reg_type_promote-invite-issue.js")
load("./reg_basic_notifications.js")
