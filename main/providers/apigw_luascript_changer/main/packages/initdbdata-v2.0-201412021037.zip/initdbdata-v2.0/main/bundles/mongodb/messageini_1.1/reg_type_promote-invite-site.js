var subtype = {
    "subtype": "promote-invite-site",
    "name": "用户间邀请加入应用",
    "desc": "通过短信邮件邀请用户进入应用",
    "enable": true,
    "support_mail_channel": true,
    "support_sms_channel": true,
    "data_vars":[
        {
            "name": "邀请码",
            "label": "icode",
            "example": "201400",
            "force": "all"
        },
        {
            "name": "邀请凭证",
            "label": "itoken",
            "example": "20140033333",
            "force": "all"
        }
    ],
    "mail_config": {
        "subject": "“第一时间”邀请",
        "content": "“第一时间”诚邀您参与{{#icode}}封测{{/icode}}，点击 {{{httpsite}}}/?t={{{itoken}}} 下载客户端，邀请凭证:{{{itoken}}}{{#icode}}，邀请码:{{{icode}}}{{/icode}}。\n记得安装后加我好友：{{{senderName}}}。",
        "format": "text"
    },
    "sms_config":{
        "content": "“第一时间”诚邀您参与{{#icode}}封测{{/icode}}，点击 {{{httpsite}}}/?t={{{itoken}}} 下载客户端，邀请凭证:{{{itoken}}}{{#icode}}，邀请码:{{{icode}}}{{/icode}}。\n记得安装后加我好友：{{{senderName}}}。"
    }
}
reg_subtype(subtype);










