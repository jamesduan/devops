var db = connect(db.hostInfo().system.hostname+"/sio-nebula"); 
db.message_type_configs.remove({"subtype":"passwd-reset"})
db.message_type_configs.remove({"subtype":"activate-verify"})
db.message_type_configs.remove({"subtype":/promote/})
