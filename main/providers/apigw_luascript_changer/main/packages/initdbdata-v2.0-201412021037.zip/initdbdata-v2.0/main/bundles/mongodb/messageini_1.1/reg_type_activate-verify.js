var subtype = {
    "subtype": "activate-verify",
    "name": "激活验证",
    "desc": "手机或邮箱绑定时发送验证码",
    "enable": true,
    "support_mail_channel": true,
    "support_sms_channel": true,
    "data_vars":[
        {
            "name":"激活用户名字",
            "label": "receiverName",
            "example": "李四",
            "force": "all"
        },
        {
            "name": "验证码",
            "label": "activateCode",
            "example": "201407",
            "force": "all"
        },
        {
            "name":"验证有效秒数",
            "label": "expireSeconds",
            "example": "60",
            "force": "all"
        }
    ],
    "mail_config": {
        "subject": "邮箱验证",
        "content": "亲爱的用户{{{receiverName}}}，在线司令部提醒您，您在在线司令部正尝试绑定您的邮箱{{{receiverEmailAddress}}}，验证码为{{{activateCode}}}，验证码将在{{{expireSeconds}}}秒后过期。",
        "format": "text"
    },
    "sms_config":{
        "content": "亲爱的用户{{{receiverName}}}，在线司令部提醒您，您在在线司令部尝试绑定您的手机{{{receiverPhoneNumber}}}，验证码为{{{activateCode}}}，验证码将在{{{expireSeconds}}}秒后过期。"
    }
}
reg_subtype(subtype);










