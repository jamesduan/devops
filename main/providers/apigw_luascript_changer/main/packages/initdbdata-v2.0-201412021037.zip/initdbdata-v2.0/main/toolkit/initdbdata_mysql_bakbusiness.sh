#!/bin/bash -ex
#保存当前服务器上已安装组件信息
source $initdbdatatoolkit/bundle.ini

echo  '-------------保存当前服务器上已安装组件信息 :----------------'$initdbdatatmp"pvo_clients.sql tfs_name_db.sql"
${mysqlcmd}mysqldump-h$mysqlhost -u$mysqluser -p$mysqlpassword -t sysadmin pvo_clients > $initdbdatatmp/pvo_clients.sql
${mysqlcmd}mysqldump-h$mysqlhost -u$mysqluser -p$mysqlpassword -t tfs_name_db --ignore-table=togressa.tgs_logs > $initdbdatatmp/tfs_name_db.sql
echo  '-------------ok:----------------'


today=`date +%Y%m%d`
timestamp=`date +%s`
bakdatafile="bakdata_"$today"_"$timestamp".sql"
bakschemafile="bakschema_"$today"_"$timestamp".sql"

echo  '-------------all-databases schema:----------------'$initdbdatatmp/$bakschemafile
echo  '-------------all-databases data:----------------'$initdbdatatmp/$bakdatafile
${mysqlcmd}mysqldump-h$mysqlhost -u$mysqluser -p$mysqlpassword -d -R --all-databases  >$initdbdatatmp/$bakschemafile
${mysqlcmd}mysqldump-h$mysqlhost -u$mysqluser -p$mysqlpassword -t --all-databases --ignore-table=togressa.tgs_logs >$initdbdatatmp/$bakdatafile
