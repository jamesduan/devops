use mysql;

set GLOBAL log_bin_trust_function_creators = ON;

delete from mysql.user where user='';
grant usage on *.* to 'space'@'%' identified by 'magima.1';
drop user 'space'@'%';
grant usage on *.* to 'sysadmin'@'%' identified by 'magima.1';
drop user 'sysadmin'@'%';
grant usage on *.* to 'activity'@'%' identified by 'magima.1';
drop user 'activity'@'%';

create user 'space'@'%' identified by 'magima.1';
grant all on spacedb.* to 'space'@'%';
grant select  on sysadmin.* to 'space'@'%';
grant execute on spacedb.* to 'space'@'%';
grant execute  on sysadmin.*  to 'space'@'%';
grant select on mysql.proc to 'space'@'%';

create user 'sysadmin'@'%' identified by 'magima.1';
grant all  on sysadmin.*  to 'sysadmin'@'%';
grant select  on spacedb.* to 'sysadmin'@'%';
grant insert  on spacedb.* to 'sysadmin'@'%';
grant execute  on spacedb.*  to 'sysadmin'@'%';
grant select on mysql.proc to 'sysadmin'@'%';

create user 'activity'@'%' identified by 'magima.1';
grant all  on activitystreamdb.*  to 'activity'@'%';
grant select  on *.* to 'activity'@'%';

flush privileges;
#create user 'root'@'%' identified by 'magima.1';
#grant all privileges on *.* to 'root'@'%';
#update mysql.user set Grant_priv='Y' where user='root' and host='%';
flush privileges;











