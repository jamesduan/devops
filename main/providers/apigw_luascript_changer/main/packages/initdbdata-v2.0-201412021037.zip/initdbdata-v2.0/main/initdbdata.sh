#!/bin/bash -ex
#sh /opt/mtprovision/daas/initdbdata/initdbdata-v1.0/main/initdbdata.sh
shpath=$(cd $(dirname $0); pwd)
source $shpath/properties.ini
initdbdatatmp=$shpath/$initdbdatatmp
initdbdatabundles=$shpath/$initdbdatabundles
initdbdatatoolkit=$shpath/$initdbdatatoolkit
echo $initdbdatatmp
echo $initdbdatabundles
echo $initdbdatatoolkit

if [ $initcom == 1 ];then  
    source $initdbdatatoolkit/initdbdata_mysql_bakbusiness.sh
fi

if [ $initmongo == 1 ];then  
    echo  '------------- mongodb  begin:----------------'     
    source $initdbdatatoolkit/initdbdata_mongo.sh
    echo  '------------- mongodb  end:----------------' 
fi

if [ $initboc == 1 ];then  
    echo  '------------- boc   begin:----------------'     
    source $initdbdatatoolkit/initdbdata_mysql_boc.sh
    echo  '------------- boc   end:----------------' 
fi

if [ $initproduce == 1 ];then  
    echo  '------------- produce  begin:----------------'     
    source $initdbdatatoolkit/initdbdata_mysql_produce.sh
    echo  '------------- produce  end:----------------' 
fi

if [ $initcom == 1 ];then  
    source $initdbdatatoolkit/initdbdata_mysql_rebusiness.sh
fi
