-- MySQL dump 10.13  Distrib 5.6.20, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: activitystreamdb
-- ------------------------------------------------------
-- Server version	5.6.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `activitystreamdb`
--

/*!40000 DROP DATABASE IF EXISTS `activitystreamdb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `activitystreamdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `activitystreamdb`;

--
-- Table structure for table `as_action_relation_types`
--

DROP TABLE IF EXISTS `as_action_relation_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_action_relation_types` (
  `id` int(8) NOT NULL,
  `locale` varchar(8) NOT NULL,
  `expression` varchar(48) NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_action_types`
--

DROP TABLE IF EXISTS `as_action_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_action_types` (
  `id` int(8) NOT NULL,
  `verb` varchar(16) NOT NULL,
  `object_entity_type` varchar(16) NOT NULL,
  `locale` varchar(8) NOT NULL,
  `template` varchar(128) NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_activities`
--

DROP TABLE IF EXISTS `as_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_activities` (
  `site_id` bigint(20) DEFAULT NULL,
  `event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `space_id` int(10) DEFAULT NULL,
  `place_id` int(10) DEFAULT NULL,
  `event_type_id` int(8) NOT NULL,
  `action_type_id` int(8) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `duration` int(11) DEFAULT NULL,
  `time_cost` int(11) DEFAULT NULL,
  `spatial_value` text,
  `application_id` int(8) DEFAULT NULL,
  `client_ip` varchar(32) DEFAULT NULL,
  `template_params` text,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_activity_entity_relationships`
--

DROP TABLE IF EXISTS `as_activity_entity_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_activity_entity_relationships` (
  `event_id` bigint(20) NOT NULL,
  `entity_type` varchar(16) NOT NULL,
  `entity_id` bigint(20) NOT NULL,
  `activity_role` enum('SUBJECT','OBJECT','TARGET','CONTAINER') NOT NULL DEFAULT 'SUBJECT',
  PRIMARY KEY (`event_id`,`entity_id`,`activity_role`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_activity_relations`
--

DROP TABLE IF EXISTS `as_activity_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_activity_relations` (
  `relation_type_id` int(8) NOT NULL,
  `from_id` bigint(20) NOT NULL,
  `to_id` bigint(20) NOT NULL,
  PRIMARY KEY (`relation_type_id`,`from_id`,`to_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_criteria_rule`
--

DROP TABLE IF EXISTS `as_criteria_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_criteria_rule` (
  `criteria_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `json_expression` text NOT NULL,
  `sql_expression` text,
  `publish_id` int(10) unsigned DEFAULT NULL,
  `creator_id` bigint(40) unsigned DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  `is_subscribefeed` enum('true','false') DEFAULT NULL,
  `place_id` int(10) DEFAULT NULL,
  `space_id` int(10) DEFAULT NULL,
  `inner_rule` varchar(16) DEFAULT NULL,
  `is_public` enum('true','false') DEFAULT 'false',
  PRIMARY KEY (`criteria_id`),
  UNIQUE KEY `inner_rule` (`inner_rule`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_criteria_user_mapping`
--

DROP TABLE IF EXISTS `as_criteria_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_criteria_user_mapping` (
  `cu_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `criteria_id` int(10) unsigned NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`cu_id`),
  KEY `fk_cu_criteria` (`criteria_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_event_types`
--

DROP TABLE IF EXISTS `as_event_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_event_types` (
  `id` int(8) NOT NULL,
  `locale` varchar(8) NOT NULL,
  `expression` varchar(48) NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `as_publish`
--

DROP TABLE IF EXISTS `as_publish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `as_publish` (
  `publish_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `source_type` enum('place','space') DEFAULT 'place',
  `source_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`publish_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'activitystreamdb'
--

--
-- Current Database: `addb`
--

/*!40000 DROP DATABASE IF EXISTS `addb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `addb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `addb`;

--
-- Table structure for table `channel`
--

DROP TABLE IF EXISTS `channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel` (
  `channel_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` varchar(1024) DEFAULT '',
  PRIMARY KEY (`channel_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slot`
--

DROP TABLE IF EXISTS `slot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slot` (
  `slot_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned DEFAULT '0',
  `channel_id` bigint(20) unsigned NOT NULL DEFAULT '1',
  `name` varchar(200) NOT NULL DEFAULT '',
  `wide` varchar(50) NOT NULL DEFAULT '',
  `high` varchar(50) NOT NULL DEFAULT '',
  `show_type` enum('fixed','float','popup','guide') DEFAULT 'fixed',
  `state` enum('enabled','disable','delete') DEFAULT 'enabled',
  `code` text,
  `is_release` tinyint(1) DEFAULT '0',
  `entity_type` enum('party') DEFAULT 'party',
  `entity_id` bigint(40) DEFAULT '0',
  `supervise_state` enum('normal','freeze','waiting_unfreeze') DEFAULT 'normal',
  `latest_log_id` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`slot_id`),
  KEY `fk_slot_channel` (`channel_id`),
  KEY `fk_slot_parent` (`parent_id`),
  CONSTRAINT `fk_slot_channel` FOREIGN KEY (`channel_id`) REFERENCES `channel` (`channel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slot_supervise_log`
--

DROP TABLE IF EXISTS `slot_supervise_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slot_supervise_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slot_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  `action` enum('freeze','apply_unfreeze','apply_dispose') NOT NULL,
  `freeze_reason` enum('none','content_violation','location_violation') DEFAULT 'none',
  `apply_unfreeze_reason` enum('none','content_adjust','location_adjust') DEFAULT 'none',
  `apply_dispose_reason` enum('none','agree','disagree') DEFAULT 'none',
  `description` varchar(60) DEFAULT '',
  `time_created` datetime NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `fk_slot_supervise_log` (`slot_id`),
  CONSTRAINT `fk_slot_supervise_log` FOREIGN KEY (`slot_id`) REFERENCES `slot` (`slot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'addb'
--

--
-- Current Database: `assetdb`
--

/*!40000 DROP DATABASE IF EXISTS `assetdb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `assetdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `assetdb`;

--
-- Table structure for table `asset_category`
--

DROP TABLE IF EXISTS `asset_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_category` (
  `category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `identity` varchar(50) DEFAULT '',
  `parent_id` int(10) DEFAULT '0',
  `party_id` bigint(40) DEFAULT '0',
  `keeper_id` bigint(40) DEFAULT '0',
  `is_alive` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asset_item`
--

DROP TABLE IF EXISTS `asset_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_item` (
  `item_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `item_num` varchar(64) DEFAULT '',
  `location_id` bigint(40) DEFAULT '0',
  `region_id` bigint(40) DEFAULT '0',
  `asset_group_id` bigint(40) DEFAULT '0',
  `keeper_id` bigint(40) DEFAULT '0',
  `asset_category_id` int(10) DEFAULT '0',
  `brand` varchar(200) DEFAULT '',
  `model_num` varchar(200) DEFAULT '',
  `remark` varchar(1024) DEFAULT '',
  `party_id` bigint(40) DEFAULT '0',
  `creator_id` bigint(40) DEFAULT '0',
  `attachment` text,
  `asset_category_identity` varchar(50) DEFAULT '',
  `item_uid` varchar(32) DEFAULT '',
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asset_item_relation`
--

DROP TABLE IF EXISTS `asset_item_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_item_relation` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `from_item_id` bigint(40) NOT NULL DEFAULT '0',
  `to_item_id` bigint(40) NOT NULL DEFAULT '0',
  `time_related` bigint(13) NOT NULL,
  `relation_type` enum('general') DEFAULT 'general',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asset_operation_archive_mapping`
--

DROP TABLE IF EXISTS `asset_operation_archive_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_operation_archive_mapping` (
  `aoam_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `log_id` bigint(40) NOT NULL,
  `archive_id` bigint(40) NOT NULL,
  `action_type` enum('onset_action','offset_action') DEFAULT 'onset_action',
  PRIMARY KEY (`aoam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asset_operation_issue_mapping`
--

DROP TABLE IF EXISTS `asset_operation_issue_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_operation_issue_mapping` (
  `aoim_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `log_id` bigint(40) NOT NULL,
  `issue_id` bigint(40) NOT NULL,
  `action_type` enum('onset_action','offset_action') DEFAULT 'onset_action',
  PRIMARY KEY (`aoim_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asset_operation_log`
--

DROP TABLE IF EXISTS `asset_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_operation_log` (
  `log_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `asset_item_id` bigint(40) NOT NULL,
  `time_created` bigint(13) NOT NULL,
  `onset_action` enum('Purchase','Lease','Checkin','Checkout','Lend','Loss','Sold','Repair','Obsolescence','ThrowLease') DEFAULT NULL,
  `onset_action_time` bigint(13) DEFAULT '0',
  `onset_action_user` bigint(40) DEFAULT '0',
  `onset_json` varchar(500) DEFAULT '',
  `offset_action` enum('Return','Found','ObsolescenceCancel','SoldCancel','ThrowLeaseCancel') DEFAULT NULL,
  `offset_action_time` bigint(13) DEFAULT '0',
  `offset_action_user` bigint(40) DEFAULT '0',
  `offset_json` varchar(500) DEFAULT '',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT '',
  `area_id` int(8) DEFAULT '0',
  `address` varchar(200) DEFAULT '',
  `postcode` varchar(20) DEFAULT '',
  `phone` varchar(20) DEFAULT '',
  `mobile` varchar(20) DEFAULT '',
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `region_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT '',
  `location_id` bigint(40) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`region_id`),
  KEY `fk_region_location` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequence`
--

DROP TABLE IF EXISTS `sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequence` (
  `name` varchar(30) NOT NULL,
  `nextid` int(11) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'assetdb'
--

--
-- Current Database: `docdb`
--

/*!40000 DROP DATABASE IF EXISTS `docdb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `docdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `docdb`;

--
-- Table structure for table `doc_comment`
--

DROP TABLE IF EXISTS `doc_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_comment` (
  `comment_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(40) unsigned NOT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `creator_id` bigint(40) DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `fk_doc_comment` (`doc_id`),
  CONSTRAINT `fk_doc_comment` FOREIGN KEY (`doc_id`) REFERENCES `document` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_download`
--

DROP TABLE IF EXISTS `doc_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_download` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(40) unsigned NOT NULL,
  `entity_type` enum('user','role') DEFAULT NULL,
  `entity_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_doc_download` (`doc_id`),
  CONSTRAINT `fk_doc_download` FOREIGN KEY (`doc_id`) REFERENCES `document` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_evaluate`
--

DROP TABLE IF EXISTS `doc_evaluate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_evaluate` (
  `eva_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(40) unsigned NOT NULL,
  `score` varchar(50) DEFAULT NULL,
  `creator_id` bigint(40) DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`eva_id`),
  KEY `fk_doc_eva` (`doc_id`),
  CONSTRAINT `fk_doc_eva` FOREIGN KEY (`doc_id`) REFERENCES `document` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_tag_mapping`
--

DROP TABLE IF EXISTS `doc_tag_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_tag_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(40) unsigned NOT NULL,
  `tag_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `doc_id` (`doc_id`,`tag_id`),
  KEY `fk_doc_id` (`doc_id`),
  KEY `fk_tag_id` (`tag_id`),
  CONSTRAINT `fk_doc_id` FOREIGN KEY (`doc_id`) REFERENCES `document` (`doc_id`),
  CONSTRAINT `fk_tag_id` FOREIGN KEY (`tag_id`) REFERENCES `doctag` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `docref`
--

DROP TABLE IF EXISTS `docref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `docref` (
  `ref_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(40) unsigned NOT NULL,
  `entity_type` enum('play','play_admin','party','issue','general','topic','chat','stream') DEFAULT NULL,
  `entity_id` bigint(40) unsigned NOT NULL,
  `download_control` enum('all','user','role') DEFAULT NULL,
  PRIMARY KEY (`ref_id`),
  KEY `fk_doc_ref` (`doc_id`),
  CONSTRAINT `fk_doc_ref` FOREIGN KEY (`doc_id`) REFERENCES `document` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doctag`
--

DROP TABLE IF EXISTS `doctag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctag` (
  `tag_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `doc_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `docname` varchar(200) DEFAULT NULL,
  `docsize` varchar(50) DEFAULT NULL,
  `fetch_code` varchar(50) DEFAULT NULL,
  `backstage_type` enum('tfs','mongilefs','qiniu','fastdfs') DEFAULT NULL,
  `path_url` varchar(500) DEFAULT NULL,
  `creator_id` bigint(40) DEFAULT NULL,
  `time_created` bigint(13) NOT NULL,
  `time_updated` bigint(13) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT '0',
  `is_encrypt` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `image_entity_mapping`
--

DROP TABLE IF EXISTS `image_entity_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image_entity_mapping` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tfs_id` varchar(200) DEFAULT NULL,
  `entity_type` enum('play','play_admin','network','issue','topic','chat','stream','org_asset') NOT NULL,
  `entity_id` bigint(40) unsigned NOT NULL,
  `creator_id` bigint(40) unsigned NOT NULL,
  `time_created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_image_entity` (`tfs_id`),
  CONSTRAINT `fk_image_entity` FOREIGN KEY (`tfs_id`) REFERENCES `user_image` (`tfs_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_rule_doc`
--

DROP TABLE IF EXISTS `sys_rule_doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_rule_doc` (
  `doc_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `url` varchar(200) NOT NULL,
  `content` mediumtext,
  `status` enum('on','off','del') DEFAULT 'off',
  `time_created` int(11) NOT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `sort` int(5) DEFAULT '1',
  `entry_prefix` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_image`
--

DROP TABLE IF EXISTS `user_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_image` (
  `tfs_id` varchar(200) NOT NULL,
  `user_id` bigint(40) unsigned DEFAULT NULL,
  `filename` varchar(50) DEFAULT NULL,
  `size` bigint(40) unsigned DEFAULT NULL,
  `format` varchar(20) DEFAULT NULL,
  `upload_time` datetime DEFAULT NULL,
  `original_bucket` varchar(20) DEFAULT NULL,
  `md5` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`tfs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'docdb'
--

--
-- Current Database: `maintaindb`
--

/*!40000 DROP DATABASE IF EXISTS `maintaindb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `maintaindb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `maintaindb`;

--
-- Table structure for table `fix_job`
--

DROP TABLE IF EXISTS `fix_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fix_job` (
  `job_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`job_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fix_task`
--

DROP TABLE IF EXISTS `fix_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fix_task` (
  `task_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint(40) unsigned NOT NULL,
  `rule_class` varchar(64) NOT NULL,
  `rule` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_id`),
  KEY `fk_task_job` (`job_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fix_task_log`
--

DROP TABLE IF EXISTS `fix_task_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fix_task_log` (
  `tasklog_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` bigint(40) unsigned NOT NULL,
  `manipulation` enum('none','insert','update','delete') NOT NULL DEFAULT 'none',
  `table_schema` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `table_name_alias` varchar(64) DEFAULT NULL,
  `id_column_name` varchar(64) NOT NULL,
  `id_select_source` varchar(4096) NOT NULL,
  `ids` varchar(4096) NOT NULL,
  `columns` varchar(4096) DEFAULT NULL,
  `values_expr_before` mediumtext,
  `values_expr_after` mediumtext,
  `restored` tinyint(1) NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tasklog_id`),
  KEY `fk_task_log_task` (`task_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `maintain_log`
--

DROP TABLE IF EXISTS `maintain_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintain_log` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(4096) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mongo_data_trash`
--

DROP TABLE IF EXISTS `mongo_data_trash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mongo_data_trash` (
  `table_schema` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `value` varchar(4096) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'maintaindb'
--

--
-- Current Database: `partydb`
--

/*!40000 DROP DATABASE IF EXISTS `partydb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `partydb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `partydb`;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `blacklist_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `baduser_id` bigint(40) NOT NULL,
  `owner_id` bigint(40) NOT NULL,
  `time_created` bigint(20) NOT NULL,
  PRIMARY KEY (`blacklist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `contact_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `information` varchar(500) DEFAULT NULL,
  `binding_user` bigint(40) unsigned DEFAULT NULL,
  `owner_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`contact_id`),
  KEY `fk_contact_user` (`binding_user`),
  KEY `fk_contact_owner` (`owner_id`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`),
  CONSTRAINT `fk_contact_user` FOREIGN KEY (`binding_user`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts_group`
--

DROP TABLE IF EXISTS `contacts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts_group` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `owner_id` bigint(40) unsigned DEFAULT NULL,
  `issue_num` int(8) DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `name` (`name`),
  KEY `fk_contact_group_owner` (`owner_id`),
  CONSTRAINT `contacts_group_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `default_group_issuenum`
--

DROP TABLE IF EXISTS `default_group_issuenum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_group_issuenum` (
  `group_id` bigint(20) unsigned NOT NULL,
  `owner_id` bigint(40) unsigned NOT NULL,
  `issue_num` int(8) DEFAULT '0',
  PRIMARY KEY (`group_id`,`owner_id`),
  KEY `fk_group_issue` (`group_id`),
  KEY `fk_owner_issue` (`owner_id`),
  CONSTRAINT `fk_group_issue` FOREIGN KEY (`group_id`) REFERENCES `contacts_group` (`group_id`),
  CONSTRAINT `fk_owner_issue` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `group_contacts_mapping`
--

DROP TABLE IF EXISTS `group_contacts_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_contacts_mapping` (
  `contact_id` bigint(20) unsigned NOT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`contact_id`,`group_id`),
  KEY `fk_mapping_contact` (`contact_id`),
  KEY `fk_mapping_group` (`group_id`),
  CONSTRAINT `fk_mapping_contact` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`contact_id`),
  CONSTRAINT `fk_mapping_group` FOREIGN KEY (`group_id`) REFERENCES `contacts_group` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `individual`
--

DROP TABLE IF EXISTS `individual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `individual` (
  `indiv_id` bigint(40) NOT NULL,
  `real_name` varchar(20) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `birthdate_year` varchar(5) DEFAULT NULL,
  `birthdate_month` varchar(2) DEFAULT NULL,
  `birthdate_day` varchar(2) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_url` varchar(100) DEFAULT NULL,
  `qq` varchar(30) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `zodiac_sign` enum('aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces') DEFAULT NULL,
  `safety_info` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`indiv_id`),
  KEY `fk_indiv_party` (`indiv_id`),
  CONSTRAINT `fk_indiv_party` FOREIGN KEY (`indiv_id`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mobile_contact_ext`
--

DROP TABLE IF EXISTS `mobile_contact_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_contact_ext` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `auto_add_mobile_contact` tinyint(1) DEFAULT '1',
  `add_me_friend_allowed` tinyint(1) DEFAULT '1',
  `recommend_friend_allowed` tinyint(1) DEFAULT '1',
  `time_updated` bigint(20) NOT NULL,
  `owner_id` bigint(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org`
--

DROP TABLE IF EXISTS `org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org` (
  `org_id` bigint(40) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `description` text,
  `type` enum('network','studio','company','federation','association','family') DEFAULT NULL,
  `org_logo` varchar(200) DEFAULT NULL,
  `url` varchar(80) DEFAULT NULL,
  `state` enum('normal','seal_up','dismiss') DEFAULT 'normal',
  `scope_id` bigint(40) unsigned DEFAULT NULL,
  `member_policy` enum('default','free','invitation','application') DEFAULT 'default',
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`org_id`),
  UNIQUE KEY `u_url` (`url`,`deleted`),
  KEY `fk_org_party` (`org_id`),
  CONSTRAINT `fk_org_party` FOREIGN KEY (`org_id`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party` (
  `party_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `time_approved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `organization_id` bigint(40) DEFAULT NULL,
  `province` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `street_address` varchar(200) DEFAULT NULL,
  `approve_mobile` varchar(20) DEFAULT NULL,
  `approve_email` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_party_mapping`
--

DROP TABLE IF EXISTS `party_party_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_party_mapping` (
  `pp_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `from_party` bigint(40) NOT NULL,
  `to_party` bigint(40) NOT NULL,
  `type` enum('manage','member','subjection','linkman','follow') DEFAULT NULL,
  PRIMARY KEY (`pp_id`),
  UNIQUE KEY `uk_party_id_user_id_type` (`from_party`,`to_party`,`type`),
  KEY `fk_pp1_party` (`from_party`),
  KEY `fk_pp2_party` (`to_party`),
  CONSTRAINT `fk_pp1_party` FOREIGN KEY (`from_party`) REFERENCES `party` (`party_id`),
  CONSTRAINT `fk_pp2_party` FOREIGN KEY (`to_party`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_recommendation`
--

DROP TABLE IF EXISTS `party_recommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_recommendation` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `party_id` bigint(40) NOT NULL,
  `status` enum('pending','passed') NOT NULL DEFAULT 'pending',
  `dest` enum('home','channel') NOT NULL,
  `sequence` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_party_id_dest` (`party_id`,`dest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_user_mapping`
--

DROP TABLE IF EXISTS `party_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_user_mapping` (
  `pu_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `party_id` bigint(40) NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  `type` enum('official','employee','customer','admin','relate','incomer','follow','owner','inviting','applying') DEFAULT NULL,
  PRIMARY KEY (`pu_id`),
  UNIQUE KEY `uk_party_id_user_id_type` (`party_id`,`user_id`,`type`),
  KEY `fk_pu_party` (`party_id`),
  KEY `fk_pu_user` (`user_id`),
  CONSTRAINT `fk_pu_party` FOREIGN KEY (`party_id`) REFERENCES `party` (`party_id`),
  CONSTRAINT `fk_pu_user` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege` (
  `privilege_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `ptype_id` bigint(40) unsigned NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `propagate` tinyint(1) DEFAULT NULL,
  `quota` varchar(40) DEFAULT NULL,
  `cron_expression` varchar(50) DEFAULT NULL,
  `instances` varchar(250) NOT NULL DEFAULT '',
  `actions` varchar(250) NOT NULL DEFAULT '',
  `scope_id` bigint(40) DEFAULT NULL,
  `utype` enum('admin','normal','both') DEFAULT 'normal',
  `built_in` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`privilege_id`),
  UNIQUE KEY `uk_ptype_id_actions_instances` (`ptype_id`,`actions`,`instances`),
  KEY `fk_privilege_type` (`ptype_id`),
  CONSTRAINT `fk_privilege_type` FOREIGN KEY (`ptype_id`) REFERENCES `privilege_type` (`ptype_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `privilege_type`
--

DROP TABLE IF EXISTS `privilege_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege_type` (
  `ptype_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `built_in` tinyint(1) DEFAULT '0',
  `for_platform` tinyint(1) DEFAULT '0',
  `for_site` tinyint(1) DEFAULT '0',
  `for_place` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`ptype_id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qq_expand`
--

DROP TABLE IF EXISTS `qq_expand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qq_expand` (
  `third_id` bigint(20) unsigned NOT NULL,
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`third_id`),
  KEY `fk_qq_third` (`third_id`),
  CONSTRAINT `fk_qq_third` FOREIGN KEY (`third_id`) REFERENCES `third_user` (`third_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_user`
--

DROP TABLE IF EXISTS `register_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `register_user` (
  `user_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `nickname` varchar(200) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `last_action` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `is_validated` tinyint(1) DEFAULT NULL,
  `is_banned` tinyint(1) DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `identity_card_num` varchar(10) DEFAULT NULL,
  `mobile` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `signature` varchar(200) DEFAULT NULL,
  `big_avatar` varchar(100) DEFAULT NULL,
  `middle_avatar` varchar(100) DEFAULT NULL,
  `small_avatar` varchar(100) DEFAULT NULL,
  `tiny_avatar` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `snd_password` varchar(40) DEFAULT NULL,
  `gender` enum('male','female','secret') DEFAULT 'secret',
  `allow_account_search` tinyint(1) DEFAULT '1',
  `allow_mobile_search` tinyint(1) DEFAULT '1',
  `add_friend_verification` tinyint(1) DEFAULT '1',
  `district_desc` varchar(500) DEFAULT '',
  `district_id` int(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `u_username_deleted` (`username`,`deleted`),
  UNIQUE KEY `u_email_deleted` (`email`,`deleted`),
  UNIQUE KEY `v_unique_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `remark`
--

DROP TABLE IF EXISTS `remark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remark` (
  `remark_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(40) NOT NULL,
  `remark_name` varchar(200) DEFAULT '',
  `owner_id` bigint(40) NOT NULL,
  PRIMARY KEY (`remark_id`),
  UNIQUE KEY `ukey_ou` (`owner_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `scope_id` bigint(40) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `built_in` tinyint(1) DEFAULT '0',
  `utype` enum('admin','normal') DEFAULT 'normal',
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uk_name_scope_id` (`name`,`scope_id`),
  KEY `fk_role_scope` (`scope_id`),
  CONSTRAINT `fk_role_scope` FOREIGN KEY (`scope_id`) REFERENCES `scope` (`scope_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_privilege_mapping`
--

DROP TABLE IF EXISTS `role_privilege_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_privilege_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(40) unsigned NOT NULL,
  `privilege_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`privilege_id`),
  KEY `fk_rp_1` (`role_id`),
  KEY `fk_rp_2` (`privilege_id`),
  CONSTRAINT `role_privilege_mapping_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE,
  CONSTRAINT `role_privilege_mapping_ibfk_2` FOREIGN KEY (`privilege_id`) REFERENCES `privilege` (`privilege_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_user_mapping`
--

DROP TABLE IF EXISTS `role_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(40) unsigned NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`user_id`),
  KEY `fk_ru_1` (`role_id`),
  KEY `fk_ru_2` (`user_id`),
  CONSTRAINT `role_user_mapping_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_mapping_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scope`
--

DROP TABLE IF EXISTS `scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scope` (
  `scope_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(40) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `is_classification` tinyint(1) DEFAULT '1',
  `is_system` tinyint(1) DEFAULT '0',
  `type` enum('site','place','platform') DEFAULT 'site',
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`scope_id`),
  KEY `fk_org_scope` (`org_id`),
  CONSTRAINT `fk_org_scope` FOREIGN KEY (`org_id`) REFERENCES `org` (`org_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sina_expand`
--

DROP TABLE IF EXISTS `sina_expand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sina_expand` (
  `third_id` bigint(20) unsigned NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `lang` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`third_id`),
  KEY `fk_sina_third` (`third_id`),
  CONSTRAINT `fk_sina_third` FOREIGN KEY (`third_id`) REFERENCES `third_user` (`third_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_user`
--

DROP TABLE IF EXISTS `third_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_user` (
  `third_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('qq','sina') DEFAULT NULL,
  `uid` varchar(100) DEFAULT NULL,
  `access_token` varchar(100) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `profile_image_url` varchar(200) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`third_id`),
  UNIQUE KEY `type_uid` (`type`,`uid`),
  KEY `fk_third_user` (`user_id`),
  CONSTRAINT `fk_third_user` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_preference`
--

DROP TABLE IF EXISTS `user_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preference` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(40) unsigned NOT NULL,
  `key` varchar(200) NOT NULL,
  `value` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`key`),
  KEY `fk_user_preference` (`user_id`),
  CONSTRAINT `fk_user_preference` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_user_mapping`
--

DROP TABLE IF EXISTS `user_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_user_mapping` (
  `uu_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `from_user` bigint(40) unsigned NOT NULL,
  `to_user` bigint(40) unsigned NOT NULL,
  `type` enum('friend','follow') DEFAULT NULL,
  PRIMARY KEY (`uu_id`),
  UNIQUE KEY `from_user` (`from_user`,`to_user`,`type`),
  KEY `fk_from_user` (`from_user`),
  KEY `fk_to_user` (`to_user`),
  CONSTRAINT `fk_from_user` FOREIGN KEY (`from_user`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_to_user` FOREIGN KEY (`to_user`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `v_unique_mobile`
--

DROP TABLE IF EXISTS `v_unique_mobile`;
/*!50001 DROP VIEW IF EXISTS `v_unique_mobile`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_unique_mobile` AS SELECT 
 1 AS `user_id`,
 1 AS `username`,
 1 AS `password`,
 1 AS `mobile`,
 1 AS `deleted`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'partydb'
--

--
-- Current Database: `sessiondb`
--

/*!40000 DROP DATABASE IF EXISTS `sessiondb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sessiondb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `sessiondb`;

--
-- Table structure for table `s_login_token`
--

DROP TABLE IF EXISTS `s_login_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_login_token` (
  `token` varchar(32) NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  `phone_bind_time` int(11) DEFAULT NULL,
  `qr_code_path` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `s_user_session`
--

DROP TABLE IF EXISTS `s_user_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_user_session` (
  `session` varchar(255) NOT NULL,
  `ts` int(11) unsigned NOT NULL DEFAULT '0',
  `data` mediumblob,
  `access_token` char(32) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  `trust_level` enum('NONE','EXPERIENCE','PHONE','USER_PASSWORD','SOFTWARE_TOKEN','HARDWARE_TOKEN','TWO_FACTOR_SOFTWARE_TOKEN','TWO_FACTOR_HARDWARE_TOKEN') DEFAULT NULL,
  `application_id` varchar(32) DEFAULT NULL,
  `client_ip` varchar(39) DEFAULT NULL,
  `device_id` varchar(32) DEFAULT NULL,
  `invisible` enum('Y','N') DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  `perm_code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`session`),
  KEY `ts` (`ts`),
  KEY `idx_access_token` (`access_token`),
  KEY `idx_user` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `s_user_session_perm`
--

DROP TABLE IF EXISTS `s_user_session_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_user_session_perm` (
  `code` varchar(32) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `time_created` int(11) DEFAULT '0',
  PRIMARY KEY (`code`),
  UNIQUE KEY `idx_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'sessiondb'
--

--
-- Current Database: `sysadmin`
--

/*!40000 DROP DATABASE IF EXISTS `sysadmin`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sysadmin` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `sysadmin`;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `blacklist_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `baduser_id` bigint(40) NOT NULL,
  `owner_id` bigint(40) NOT NULL,
  `time_created` bigint(20) NOT NULL,
  PRIMARY KEY (`blacklist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `common_district`
--

DROP TABLE IF EXISTS `common_district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_district` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `level` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `usetype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `upid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `displayorder` smallint(6) NOT NULL DEFAULT '0',
  `geo_index_x` varchar(20) DEFAULT NULL,
  `geo_index_y` varchar(20) DEFAULT NULL,
  `location_remark` varchar(200) DEFAULT NULL,
  `is_exist_child` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45054 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `contact_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `information` varchar(1024) DEFAULT '',
  `binding_user_id` bigint(40) DEFAULT '0',
  `owner_id` bigint(40) NOT NULL,
  `time_created` bigint(20) NOT NULL,
  `source` enum('mobile','weibo','request','scan') DEFAULT 'mobile',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `contact_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `information` varchar(500) DEFAULT NULL,
  `binding_user` bigint(40) unsigned DEFAULT NULL,
  `owner_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`contact_id`),
  KEY `fk_contact_user` (`binding_user`),
  KEY `fk_contact_owner` (`owner_id`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`),
  CONSTRAINT `fk_contact_user` FOREIGN KEY (`binding_user`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts_group`
--

DROP TABLE IF EXISTS `contacts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts_group` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `owner_id` bigint(40) unsigned DEFAULT NULL,
  `issue_num` int(8) DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `name` (`name`),
  KEY `fk_contact_group_owner` (`owner_id`),
  CONSTRAINT `contacts_group_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `default_group_issuenum`
--

DROP TABLE IF EXISTS `default_group_issuenum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_group_issuenum` (
  `group_id` bigint(20) unsigned NOT NULL,
  `owner_id` bigint(40) unsigned NOT NULL,
  `issue_num` int(8) DEFAULT '0',
  PRIMARY KEY (`group_id`,`owner_id`),
  KEY `fk_group_issue` (`group_id`),
  KEY `fk_owner_issue` (`owner_id`),
  CONSTRAINT `fk_group_issue` FOREIGN KEY (`group_id`) REFERENCES `contacts_group` (`group_id`),
  CONSTRAINT `fk_owner_issue` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `group_contacts_mapping`
--

DROP TABLE IF EXISTS `group_contacts_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_contacts_mapping` (
  `contact_id` bigint(20) unsigned NOT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`contact_id`,`group_id`),
  KEY `fk_mapping_contact` (`contact_id`),
  KEY `fk_mapping_group` (`group_id`),
  CONSTRAINT `fk_mapping_contact` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`contact_id`),
  CONSTRAINT `fk_mapping_group` FOREIGN KEY (`group_id`) REFERENCES `contacts_group` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `individual`
--

DROP TABLE IF EXISTS `individual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `individual` (
  `indiv_id` bigint(40) NOT NULL,
  `real_name` varchar(20) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `birthdate_year` varchar(5) DEFAULT NULL,
  `birthdate_month` varchar(2) DEFAULT NULL,
  `birthdate_day` varchar(2) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_url` varchar(100) DEFAULT NULL,
  `qq` varchar(30) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `zodiac_sign` enum('aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces') DEFAULT NULL,
  `safety_info` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`indiv_id`),
  KEY `fk_indiv_party` (`indiv_id`),
  CONSTRAINT `fk_indiv_party` FOREIGN KEY (`indiv_id`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mobile_contact_ext`
--

DROP TABLE IF EXISTS `mobile_contact_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_contact_ext` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `auto_add_mobile_contact` tinyint(1) DEFAULT '1',
  `add_me_friend_allowed` tinyint(1) DEFAULT '1',
  `recommend_friend_allowed` tinyint(1) DEFAULT '1',
  `time_updated` bigint(20) NOT NULL,
  `owner_id` bigint(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org`
--

DROP TABLE IF EXISTS `org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org` (
  `org_id` bigint(40) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `description` text,
  `type` enum('network','studio','company','federation','association','family') DEFAULT NULL,
  `org_logo` varchar(200) DEFAULT NULL,
  `url` varchar(80) DEFAULT NULL,
  `state` enum('normal','seal_up','dismiss') DEFAULT 'normal',
  `scope_id` bigint(40) DEFAULT NULL,
  `member_policy` enum('default','free','invitation','application') DEFAULT 'default',
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `org_uid` varchar(32) DEFAULT '',
  PRIMARY KEY (`org_id`),
  UNIQUE KEY `u_url` (`url`,`deleted`),
  KEY `fk_org_party` (`org_id`),
  CONSTRAINT `fk_org_party` FOREIGN KEY (`org_id`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org_tag`
--

DROP TABLE IF EXISTS `org_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org_tag` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` bigint(40) unsigned NOT NULL,
  `tag_name` varchar(50) NOT NULL,
  `party_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_org_tag` (`tag_id`),
  CONSTRAINT `fk_org_tag` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party` (
  `party_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `time_approved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `organization_id` bigint(40) DEFAULT NULL,
  `province` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `street_address` varchar(200) DEFAULT NULL,
  `approve_mobile` varchar(20) DEFAULT NULL,
  `approve_email` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`party_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_party_mapping`
--

DROP TABLE IF EXISTS `party_party_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_party_mapping` (
  `pp_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `from_party` bigint(40) NOT NULL,
  `to_party` bigint(40) NOT NULL,
  `type` enum('manage','member','subjection','linkman','follow') DEFAULT NULL,
  PRIMARY KEY (`pp_id`),
  UNIQUE KEY `uk_party_id_user_id_type` (`from_party`,`to_party`,`type`),
  KEY `fk_pp1_party` (`from_party`),
  KEY `fk_pp2_party` (`to_party`),
  CONSTRAINT `fk_pp1_party` FOREIGN KEY (`from_party`) REFERENCES `party` (`party_id`),
  CONSTRAINT `fk_pp2_party` FOREIGN KEY (`to_party`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_recommendation`
--

DROP TABLE IF EXISTS `party_recommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_recommendation` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `party_id` bigint(40) NOT NULL,
  `status` enum('pending','passed') NOT NULL DEFAULT 'pending',
  `dest` enum('home','channel') NOT NULL,
  `sequence` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_party_id_dest` (`party_id`,`dest`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_user_mapping`
--

DROP TABLE IF EXISTS `party_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_user_mapping` (
  `pu_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `party_id` bigint(40) NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  `type` enum('official','employee','customer','admin','relate','incomer','follow','owner','inviting','applying') DEFAULT NULL,
  PRIMARY KEY (`pu_id`),
  UNIQUE KEY `uk_party_id_user_id_type` (`party_id`,`user_id`,`type`),
  KEY `fk_pu_party` (`party_id`),
  KEY `fk_pu_user` (`user_id`),
  CONSTRAINT `fk_pu_party` FOREIGN KEY (`party_id`) REFERENCES `party` (`party_id`),
  CONSTRAINT `fk_pu_user` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege` (
  `privilege_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `ptype_id` bigint(40) unsigned NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `propagate` tinyint(1) DEFAULT NULL,
  `quota` varchar(40) DEFAULT NULL,
  `cron_expression` varchar(50) DEFAULT NULL,
  `instances` varchar(250) NOT NULL DEFAULT '',
  `actions` varchar(250) NOT NULL DEFAULT '',
  `scope_id` bigint(40) DEFAULT NULL,
  `utype` enum('admin','normal','both') DEFAULT 'normal',
  `built_in` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`privilege_id`),
  UNIQUE KEY `uk_ptype_id_actions_instances` (`ptype_id`,`actions`,`instances`),
  KEY `fk_privilege_type` (`ptype_id`),
  CONSTRAINT `fk_privilege_type` FOREIGN KEY (`ptype_id`) REFERENCES `privilege_type` (`ptype_id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `privilege_type`
--

DROP TABLE IF EXISTS `privilege_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege_type` (
  `ptype_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `built_in` tinyint(1) DEFAULT '0',
  `for_platform` tinyint(1) DEFAULT '0',
  `for_site` tinyint(1) DEFAULT '0',
  `for_place` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`ptype_id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_api_groups`
--

DROP TABLE IF EXISTS `pvo_api_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_api_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_apis`
--

DROP TABLE IF EXISTS `pvo_apis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_apis` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `group_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_client_groups`
--

DROP TABLE IF EXISTS `pvo_client_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_client_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_clients`
--

DROP TABLE IF EXISTS `pvo_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_clients` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(32) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `callback_url` varchar(160) DEFAULT NULL,
  `client_type` varchar(32) NOT NULL DEFAULT 'web',
  `name` varchar(128) NOT NULL,
  `group_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_id` (`client_id`),
  UNIQUE KEY `uk_name_type_url` (`name`,`client_type`,`callback_url`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_quotas`
--

DROP TABLE IF EXISTS `pvo_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_quotas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `applicant` bigint(20) NOT NULL,
  `applicant_type` varchar(24) NOT NULL DEFAULT 'app',
  `target` bigint(20) NOT NULL,
  `target_type` varchar(24) NOT NULL DEFAULT 'api',
  `type` varchar(24) NOT NULL DEFAULT 'normal',
  `rule` varchar(128) NOT NULL DEFAULT 'allow',
  PRIMARY KEY (`id`),
  UNIQUE KEY `applicant` (`applicant`,`applicant_type`,`target`,`target_type`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_tokens`
--

DROP TABLE IF EXISTS `pvo_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_tokens` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(256) NOT NULL,
  `scope` varchar(128) DEFAULT NULL,
  `client_id` bigint(20) NOT NULL,
  `username` varchar(128) NOT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `client_id` (`client_id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_users`
--

DROP TABLE IF EXISTS `pvo_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_user`
--

DROP TABLE IF EXISTS `register_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `register_user` (
  `user_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `nickname` varchar(200) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `last_action` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `is_validated` tinyint(1) DEFAULT NULL,
  `is_banned` tinyint(1) DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `identity_card_num` varchar(10) DEFAULT NULL,
  `mobile` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `signature` varchar(200) DEFAULT NULL,
  `big_avatar` varchar(100) DEFAULT NULL,
  `middle_avatar` varchar(100) DEFAULT NULL,
  `small_avatar` varchar(100) DEFAULT NULL,
  `tiny_avatar` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `snd_password` varchar(40) DEFAULT NULL,
  `gender` enum('male','female','secret') DEFAULT 'secret',
  `allow_account_search` tinyint(1) DEFAULT '1',
  `allow_mobile_search` tinyint(1) DEFAULT '1',
  `add_friend_verification` tinyint(1) DEFAULT '1',
  `district_desc` varchar(500) DEFAULT '',
  `district_id` int(8) unsigned DEFAULT NULL,
  `user_uid` varchar(32) DEFAULT '',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `u_username_deleted` (`username`,`deleted`),
  UNIQUE KEY `u_email_deleted` (`email`,`deleted`),
  UNIQUE KEY `v_unique_mobile` (`mobile`),
  KEY `fk_user_district` (`district_id`),
  CONSTRAINT `fk_user_district` FOREIGN KEY (`district_id`) REFERENCES `common_district` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger tr_bf_update_user before update on `register_user`
for each row
begin
        if new.email = '' then
                set new.email = null;
        end if;
        if new.mobile = '' then
                set new.mobile = null;
        end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `remark`
--

DROP TABLE IF EXISTS `remark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remark` (
  `remark_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(40) NOT NULL,
  `remark_name` varchar(200) DEFAULT '',
  `owner_id` bigint(40) NOT NULL,
  PRIMARY KEY (`remark_id`),
  UNIQUE KEY `ukey_ou` (`owner_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `scope_id` bigint(40) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `built_in` tinyint(1) DEFAULT '0',
  `utype` enum('admin','normal') DEFAULT 'normal',
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uk_name_scope_id` (`name`,`scope_id`),
  KEY `fk_role_scope` (`scope_id`),
  CONSTRAINT `fk_role_scope` FOREIGN KEY (`scope_id`) REFERENCES `scope` (`scope_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_privilege_mapping`
--

DROP TABLE IF EXISTS `role_privilege_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_privilege_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(40) unsigned NOT NULL,
  `privilege_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`privilege_id`),
  KEY `fk_rp_1` (`role_id`),
  KEY `fk_rp_2` (`privilege_id`),
  CONSTRAINT `role_privilege_mapping_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE,
  CONSTRAINT `role_privilege_mapping_ibfk_2` FOREIGN KEY (`privilege_id`) REFERENCES `privilege` (`privilege_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_user_mapping`
--

DROP TABLE IF EXISTS `role_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(40) unsigned NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`user_id`),
  KEY `fk_ru_1` (`role_id`),
  KEY `fk_ru_2` (`user_id`),
  CONSTRAINT `role_user_mapping_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_mapping_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `s_catalog`
--

DROP TABLE IF EXISTS `s_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_catalog` (
  `catalog_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(40) unsigned NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  `status` enum('private','shareable','public') DEFAULT 'private',
  `usage` enum('dev','consumption','individual','org','orgmgr','custtool','play','playmgr','fastapp') DEFAULT NULL,
  PRIMARY KEY (`catalog_id`),
  KEY `fk_catalog_org` (`org_id`),
  CONSTRAINT `fk_catalog_org` FOREIGN KEY (`org_id`) REFERENCES `s_organization` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=733 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `s_organization`
--

DROP TABLE IF EXISTS `s_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_organization` (
  `org_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `org_type` bigint(10) unsigned DEFAULT NULL,
  `is_enabled` int(1) DEFAULT '1',
  `publish_allowed` int(1) DEFAULT '0',
  PRIMARY KEY (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=393 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scope`
--

DROP TABLE IF EXISTS `scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scope` (
  `scope_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(40) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `is_classification` tinyint(1) DEFAULT '1',
  `is_system` tinyint(1) DEFAULT '0',
  `type` enum('site','place','platform') DEFAULT 'site',
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`scope_id`),
  KEY `fk_org_scope` (`org_id`),
  CONSTRAINT `fk_org_scope` FOREIGN KEY (`org_id`) REFERENCES `org` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_config` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(50) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `tag_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_user`
--

DROP TABLE IF EXISTS `third_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_user` (
  `third_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('qq','sina') DEFAULT NULL,
  `uid` varchar(100) DEFAULT NULL,
  `access_token` varchar(100) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `profile_image_url` varchar(200) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`third_id`),
  UNIQUE KEY `type_uid` (`type`,`uid`),
  KEY `fk_third_user` (`user_id`),
  CONSTRAINT `fk_third_user` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_preference`
--

DROP TABLE IF EXISTS `user_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preference` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(40) unsigned NOT NULL,
  `key` varchar(200) NOT NULL,
  `value` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`key`),
  KEY `fk_user_preference` (`user_id`),
  CONSTRAINT `fk_user_preference` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_user_mapping`
--

DROP TABLE IF EXISTS `user_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_user_mapping` (
  `uu_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `from_user` bigint(40) unsigned NOT NULL,
  `to_user` bigint(40) unsigned NOT NULL,
  `type` enum('friend','follow') DEFAULT NULL,
  PRIMARY KEY (`uu_id`),
  UNIQUE KEY `from_user` (`from_user`,`to_user`,`type`),
  KEY `fk_from_user` (`from_user`),
  KEY `fk_to_user` (`to_user`),
  CONSTRAINT `fk_from_user` FOREIGN KEY (`from_user`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_to_user` FOREIGN KEY (`to_user`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `v_unique_mobile`
--

DROP TABLE IF EXISTS `v_unique_mobile`;
/*!50001 DROP VIEW IF EXISTS `v_unique_mobile`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_unique_mobile` AS SELECT 
 1 AS `user_id`,
 1 AS `username`,
 1 AS `password`,
 1 AS `mobile`,
 1 AS `deleted`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'sysadmin'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_party_tags` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO,STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_party_tags`(p_party_id  bigint(40) unsigned) RETURNS text CHARSET utf8
begin
        declare done int default false;
        declare v_ret text;
        declare v_json varchar(200);
        declare v_tag_id bigint(40) unsigned;
        declare v_tag_name varchar(50);
        declare v_cur cursor for select tag_id, tag_name from org_tag where party_id = p_party_id;
        declare continue handler for not found set done = true;
        set v_ret = '';
        open v_cur;

        main_loop: loop
                fetch v_cur into v_tag_id, v_tag_name;
                if done then
                leave main_loop;
        end if;
                set v_json = concat ('{"tag_id":', v_tag_id, ', "tag_name":"', v_tag_name, '"}');
                set v_ret = concat (v_ret, v_json, ',');
        end loop;

        close v_cur;
        set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
        return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_party_users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_party_users`(p_party_id bigint(40) unsigned) RETURNS text CHARSET utf8
begin
	declare done int default false;
	declare v_ret text;
	declare v_json varchar(200);
	declare v_username varchar(200);
	declare v_nickname varchar(200);
	declare v_type varchar(50);
	declare v_cur cursor for 
	  select ru.username, ru.nickname, pum.type from party_user_mapping pum join register_user ru on
	  pum.user_id = ru.user_id  where pum.party_id = p_party_id and pum.type in ('owner');
	declare continue handler for not found set done = true;
	set v_ret = '';
	open v_cur;
	
	main_loop: loop
		fetch v_cur into v_username, v_nickname, v_type;
		if done then
      		leave main_loop;
    	end if;
    		set v_json = concat ('{"username":"', v_username, 
    			'", "nickname":"', v_nickname, '", "type":"', v_type, '"}');
		set v_ret = concat (v_ret, v_json, ',');
	end loop;	
	
	close v_cur;
	set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
	return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_up_types` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_up_types`(p_user_id bigint(40) unsigned,
	p_party_id bigint(40) unsigned) RETURNS text CHARSET utf8
begin
	declare done int default false;
	declare v_ret text;
	declare v_json varchar(200);
	declare v_type varchar(50);
	declare v_cur cursor for select type from party_user_mapping where user_id = p_user_id and party_id = p_party_id;
	declare continue handler for not found set done = true;
	set v_ret = '';
	open v_cur;	
	
	main_loop: loop
		fetch v_cur into v_type;
		if done then
      		leave main_loop;
    	end if;
    		set v_json = concat ('{"type":"', v_type, '"}');
		set v_ret = concat (v_ret, v_json, ',');
	end loop;	
	
	close v_cur;
	set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
	return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_user_third_users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_user_third_users`(p_user_id bigint(40) unsigned) RETURNS text CHARSET utf8
begin
	declare done int default false;
	declare v_ret text;
	declare v_json text;
	declare v_type varchar(50);
	declare v_uid varchar(100);
	declare v_access_token varchar(100);
	declare v_nick_name varchar(100);
	declare v_profile_image_url varchar(200);
	declare v_gender varchar(50);
	declare v_cur cursor for 
	  select type, uid, access_token, nick_name, profile_image_url, gender from third_user where user_id = p_user_id;
	declare continue handler for not found set done = true;
	set v_ret = '';
	open v_cur;	
	
	main_loop: loop
		fetch v_cur into v_type, v_uid, v_access_token, v_nick_name, v_profile_image_url, v_gender;
		if done then
      		leave main_loop;
    	end if;
    		set v_json = concat ('{"type":"', v_type, 
    			'", "uid":"', v_uid, '", "access_token":"', v_access_token, 
    			'", "nick_name":"', v_nick_name, '", "profile_image_url":"', v_profile_image_url,
    			'", "gender":"', v_gender, '"}');
		set v_ret = concat (v_ret, v_json, ',');
	end loop;	
	
	close v_cur;
	set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
	return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_privilege` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_privilege`(ptid BIGINT(40) UNSIGNED, a VARCHAR(1024), n VARCHAR(200))
BEGIN
	DECLARE _pid BIGINT(40) UNSIGNED;
	DECLARE _n VARCHAR(200);
	DECLARE _d VARCHAR(500);

	SELECT privilege_id, name, description INTO _pid, _n, _d FROM privilege WHERE ptype_id = ptid AND actions = a;
	IF _pid IS NULL THEN
		INSERT INTO privilege (`ptype_id`,`name`,`description`,`actions`) VALUES (ptid, n, n, a);
	ELSEIF _n != n THEN
		UPDATE privilege SET name = n, description = d WHERE privilege_id = _pid;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_privilege_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_privilege_type`(n VARCHAR(128), d VARCHAR(256), fplatform TINYINT(1), fsite TINYINT(1), fplace TINYINT(1))
BEGIN
	DECLARE _ptid BIGINT(40) UNSIGNED;
	DECLARE _d VARCHAR(256);
	DECLARE _fplatform, _fsite, _fplace TINYINT(1);

	SELECT ptype_id, description, for_platform, for_site, for_place INTO _ptid, _d, _fplatform, _fsite, _fplace FROM privilege_type WHERE name = n AND built_in = 1;
	IF _ptid IS NULL THEN
		INSERT INTO privilege_type (`name`,`description`,`built_in`, `for_platform`, `for_site`, `for_place`) VALUES (n, d, '1', fplatform, fsite, fplace);
		SET @ptid = LAST_INSERT_ID();
	ELSE
		SET @s = NULL;
		IF _d != d THEN
			IF @s IS NULL THEN 
				SET @s = CONCAT('description = "', d, '"'); 
			ELSE
				SET @s = CONCAT(@s, ', description = "', d, '"');
			END IF;
			
		END IF;
		IF _fplatform != fplatform THEN
			IF @s IS NULL THEN 
				SET @s = CONCAT('for_platform = ', fplatform); 
			ELSE
				SET @s = CONCAT(@s, ', for_platform = ', fplatform);
			END IF;
			
		END IF;
		IF _fsite != fsite THEN
			IF @s IS NULL THEN 
				SET @s = CONCAT('for_site = ', fsite); 
			ELSE
				SET @s = CONCAT(@s, ', for_site = ', fsite);
			END IF;
			
		END IF;
		IF _fplace != fplace THEN
			IF @s IS NULL THEN 
				SET @s = CONCAT('for_place = ', fplace); 
			ELSE
				SET @s = CONCAT(@s, ', for_place = ', fplace);
			END IF;
			
		END IF;

		IF @s IS NOT NULL THEN
			SET @s = CONCAT('UPDATE privilege_type SET ', @s, ' WHERE ptype_id = ', _ptid);
			PREPARE _stmt FROM @s;
			EXECUTE _stmt;
			DEALLOCATE PREPARE _stmt;
		END IF;

		SET @ptid = _ptid;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_role` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_role`(sid BIGINT(40) UNSIGNED, n VARCHAR(128), d VARCHAR(256))
BEGIN
	DECLARE _rid BIGINT(40) UNSIGNED;
	DECLARE _d VARCHAR(256);
	DECLARE _bltin TINYINT(1);

	
	
	SELECT role_id, description, built_in INTO _rid, _d, _bltin FROM role WHERE scope_id = sid AND name = n;
	IF _rid IS NULL THEN
		INSERT INTO role (`scope_id`,`name`,`description`,`built_in`) VALUES (sid, n, d, '1');
		SET @rid = LAST_INSERT_ID();
	ELSE
		IF _d != d THEN
			UPDATE role SET description = d WHERE role_id = _rid;
		END IF;
		IF _bltin != 1 THEN
			UPDATE role SET built_in = 1 WHERE role_id = _rid;
		END IF;
		SET @rid = _rid;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_role_privilege` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_role_privilege`(sid BIGINT(40) UNSIGNED, rid BIGINT(40) UNSIGNED, tn VARCHAR(128), pa VARCHAR(256))
BEGIN
	DECLARE _pid BIGINT(40) UNSIGNED;
	DECLARE _mid BIGINT(40) UNSIGNED;

	SELECT p.privilege_id INTO _pid FROM privilege p JOIN privilege_type pt ON p.ptype_id = pt.ptype_id WHERE pt.name = tn AND p.actions = pa;
	IF _pid IS NULL THEN
		SET @done = 1;
	ELSE
		SELECT id INTO _mid FROM role_privilege_mapping WHERE role_id = rid AND privilege_id = _pid;
		IF _mid IS NULL THEN
			INSERT INTO role_privilege_mapping (`role_id`, `privilege_id`) VALUES (rid, _pid);
		END IF;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_scope_org` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_scope_org`(sid BIGINT(40) UNSIGNED)
BEGIN
	
	CALL m_builtin_role(sid, 'placeowner', 'place owner');

	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyInfo');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyIdentity');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'memberPolicy');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'shut');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyPage');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'collectServiceCard');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'orderService');

	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignOwner');
	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignAdmin');
	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignRole');
	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyRole');
	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyPermission');

	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'modifyInfo');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'remove');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'changePassword');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'kickOut');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'invite');

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviders', 'register');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviders', 'modify');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviders', 'shut');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviders', 'export');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviders', 'destroy');

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'modify');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'modifyCard');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'submit');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'unpublish');

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceOrderAdmin', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceOrderAdmin', 'confirm');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceOrderAdmin', 'accept');

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'submitResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalog');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeResource');

	
	CALL m_builtin_role(sid, 'placeadmin', 'place administrator');

	
	
	
	
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyPage');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'collectServiceCard');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'orderService');

	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

	
	
	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignRole');
	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyRole');
	CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyPermission');

	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'modifyInfo');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'remove');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'changePassword');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'kickOut');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'invite');

	
	
	
	
	

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'modify');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'modifyCard');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'submit');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceAdmin', 'unpublish');

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceOrderAdmin', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceOrderAdmin', 'confirm');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceOrderAdmin', 'accept');

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'submitResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalog');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeResource');

	
	CALL m_builtin_role(sid, 'placemember', 'place member');

	CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'collectServiceCard');

	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'invite');

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceOrderAdmin', 'accept');

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_scope_site` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_scope_site`(sid BIGINT(40) UNSIGNED)
BEGIN
	
	CALL m_builtin_role(sid, 'webadmin', 'web administrator');

	CALL m_builtin_role_privilege(sid, @rid, 'SitePermissions', 'modifyRole');
	CALL m_builtin_role_privilege(sid, @rid, 'SitePermissions', 'modifyPermission');
	CALL m_builtin_role_privilege(sid, @rid, 'SitePermissions', 'assignRole');

	CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'basicInfo');
	CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'userRegistration');
	CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'placeCreation');
	CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'userSession');
	CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'serviceCard');
	CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'domainName');
	CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'modifyDistrict');

	CALL m_builtin_role_privilege(sid, @rid, 'SitePages', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'SitePages', 'modify');
	CALL m_builtin_role_privilege(sid, @rid, 'SitePages', 'delete');

	CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'ban');

	

	CALL m_builtin_role_privilege(sid, @rid, 'PlaceGovern', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceGovern', 'verifyIdentity');
	CALL m_builtin_role_privilege(sid, @rid, 'PlaceGovern', 'ban');

	
	
	
	
	
	

	
	

	
	
	
	
	

	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'modifyInfo');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'remove');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'changePassword');
	CALL m_builtin_role_privilege(sid, @rid, 'Members', 'kickOut');
	

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceTypeAdmin', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceTypeAdmin', 'modify');

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviderGovern', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviderGovern', 'approve');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceProviderGovern', 'ban');

	
	
	
	
	

	CALL m_builtin_role_privilege(sid, @rid, 'ServiceGovern', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceGovern', 'approve');
	CALL m_builtin_role_privilege(sid, @rid, 'ServiceGovern', 'ban');

	
	
	
	
	

	

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceCategoryAdmin', 'view');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceCategoryAdmin', 'modify');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceCategoryAdmin', 'remove');

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceGovern', 'publishCatalog');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceGovern', 'publishResource');

	
	
	
	
	
	
	
	

	
	CALL m_builtin_role(sid, 'gplaceowner', 'global place owner estate');

	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

	CALL m_builtin_role_privilege(sid, @rid, 'Services', 'addFavorite');
	CALL m_builtin_role_privilege(sid, @rid, 'Services', 'order');

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'submitResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalog');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeResource');

	
	CALL m_builtin_role(sid, 'gplaceadmin', 'global place administrator estate');

	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

	CALL m_builtin_role_privilege(sid, @rid, 'Services', 'addFavorite');
	CALL m_builtin_role_privilege(sid, @rid, 'Services', 'order');

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'submitResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalog');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeResource');

	
	CALL m_builtin_role(sid, 'user', 'normal user');

	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

	CALL m_builtin_role_privilege(sid, @rid, 'Services', 'addFavorite');
	CALL m_builtin_role_privilege(sid, @rid, 'Services', 'order');

	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'submitResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalog');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'modifyCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeCatalogItem');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
	CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'removeResource');

	
	CALL m_builtin_role(sid, 'guest', 'guest');

	CALL m_builtin_role_privilege(sid, @rid, 'Users', 'register');

	CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');

	
	CALL m_builtin_role(sid, 'noaccess', 'no access');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_prepare_user_role` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_prepare_user_role`()
BEGIN
	
	PREPARE stmt_allur FROM "SELECT u.user_id, u.username, o.org_id AS org_id, o.name AS org_name, r.name AS role_name FROM role_user_mapping AS ru JOIN register_user AS u ON ru.user_id = u.user_id JOIN role AS r ON ru.role_id = r.role_id JOIN scope AS s ON r.scope_id = s.scope_id JOIN org AS o ON s.org_id = o.org_id";
	PREPARE stmt_ur FROM "SELECT u.user_id, u.username, o.org_id AS org_id, o.name AS org_name, r.name AS role_name FROM role_user_mapping AS ru JOIN register_user AS u ON ru.user_id = u.user_id JOIN role AS r ON ru.role_id = r.role_id JOIN scope AS s ON r.scope_id = s.scope_id JOIN org AS o ON s.org_id = o.org_id WHERE u.user_id = ?";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_privilege_no_scope_id_foreign_key` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_privilege_no_scope_id_foreign_key`()
BEGIN
	ALTER TABLE privilege DROP FOREIGN KEY `fk_privilege_scope`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_privilege_scope_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_privilege_scope_id`()
BEGIN
	UPDATE privilege SET scope_id = NULL WHERE scope_id != NULL;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_privilege_type_for` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_privilege_type_for`()
BEGIN
	ALTER TABLE privilege_type DROP COLUMN `pt_scope`;
	ALTER TABLE privilege_type ADD COLUMN `for_platform` TINYINT(1) DEFAULT '0';
	ALTER TABLE privilege_type ADD COLUMN `for_site` TINYINT(1) DEFAULT '0';
	ALTER TABLE privilege_type ADD COLUMN `for_place` TINYINT(1) DEFAULT '0';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_scope_default_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_scope_default_type`()
BEGIN
	UPDATE scope SET `type`='place' WHERE `type`='site' AND is_system=0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_scope_no_classification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_scope_no_classification`()
BEGIN
	UPDATE scope SET is_classification=0 WHERE is_classification=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_privilege_type` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_privilege_type`()
BEGIN
	CALL m_builtin_privilege_type('SitePermissions','site permissions',0,1,0);
	CALL m_builtin_privilege(@ptid, 'modifyRole', 'modify role');
	CALL m_builtin_privilege(@ptid, 'modifyPermission', 'modify permission');
	CALL m_builtin_privilege(@ptid, 'assignRole', 'assign role');

	CALL m_builtin_privilege_type('Permissions','permissions',0,0,1);
	CALL m_builtin_privilege(@ptid, 'assignOwner', 'assign owner');
	CALL m_builtin_privilege(@ptid, 'assignAdmin', 'assign admin');
	CALL m_builtin_privilege(@ptid, 'assignRole', 'assign role');
	CALL m_builtin_privilege(@ptid, 'modifyRole', 'modify role');
	CALL m_builtin_privilege(@ptid, 'modifyPermission', 'modify permission');

	CALL m_builtin_privilege_type('SiteSettings','site settings',0,1,0);
	CALL m_builtin_privilege(@ptid, 'basicInfo', 'set basic info');
	CALL m_builtin_privilege(@ptid, 'userRegistration', 'set user registration policy');
	CALL m_builtin_privilege(@ptid, 'placeCreation', 'set place creation policy');
	CALL m_builtin_privilege(@ptid, 'userSession', 'set user session policy');
	CALL m_builtin_privilege(@ptid, 'serviceCard', 'set service card policy');
	CALL m_builtin_privilege(@ptid, 'domainName', 'set domain name policy');
	CALL m_builtin_privilege(@ptid, 'modifyDistrict', 'modify district');

	CALL m_builtin_privilege_type('SitePages','site page management',0,1,0);
	CALL m_builtin_privilege(@ptid, 'create', 'create page');
	CALL m_builtin_privilege(@ptid, 'modify', 'modify page');
	CALL m_builtin_privilege(@ptid, 'delete', 'delete page');

	CALL m_builtin_privilege_type('UserAdmin','user administration',0,1,0);
	CALL m_builtin_privilege(@ptid, 'view', 'view user info');
	CALL m_builtin_privilege(@ptid, 'ban', 'ban/unban user');

	CALL m_builtin_privilege_type('Users','user',0,1,0);
	CALL m_builtin_privilege(@ptid, 'register', 'user registration');

	CALL m_builtin_privilege_type('Members','place members',0,1,1);
	CALL m_builtin_privilege(@ptid, 'view', 'view members');
	CALL m_builtin_privilege(@ptid, 'create', 'create employee');
	CALL m_builtin_privilege(@ptid, 'modifyInfo', 'modify employee info');
	CALL m_builtin_privilege(@ptid, 'remove', 'remove member');
	CALL m_builtin_privilege(@ptid, 'changePassword', 'change employee password');
	CALL m_builtin_privilege(@ptid, 'kickOut', 'kick out incomer');
	CALL m_builtin_privilege(@ptid, 'invite', 'invite');

	CALL m_builtin_privilege_type('PlaceGovern','place governance',0,1,0);
	CALL m_builtin_privilege(@ptid, 'view', 'view places');
	CALL m_builtin_privilege(@ptid, 'verifyIdentity', 'verify place identity');
	CALL m_builtin_privilege(@ptid, 'ban', 'ban/unban place');

	CALL m_builtin_privilege_type('PlaceAdmin','place admin',0,0,1);
	CALL m_builtin_privilege(@ptid, 'modifyInfo', 'modify place info');
	CALL m_builtin_privilege(@ptid, 'modifyIdentity', 'modify place identity');
	CALL m_builtin_privilege(@ptid, 'memberPolicy', 'set place member policy');
	CALL m_builtin_privilege(@ptid, 'shut', 'shut place');
	CALL m_builtin_privilege(@ptid, 'modifyPage', 'modify place presentation');
	CALL m_builtin_privilege(@ptid, 'collectServiceCard', 'collect service card');
	CALL m_builtin_privilege(@ptid, 'orderService', 'order service');

	CALL m_builtin_privilege_type('Places','place',0,1,1);
	CALL m_builtin_privilege(@ptid, 'create', 'create (sub) place');
	CALL m_builtin_privilege(@ptid, 'join', 'join (sub) place');

	CALL m_builtin_privilege_type('ServiceTypeAdmin','service type administration',0,1,0);
	CALL m_builtin_privilege(@ptid, 'view', 'view service types');
	CALL m_builtin_privilege(@ptid, 'modify', 'modify service types');

	CALL m_builtin_privilege_type('ServiceProviderGovern','service provider governance',0,1,0);
	CALL m_builtin_privilege(@ptid, 'view', 'view service providers');
	CALL m_builtin_privilege(@ptid, 'approve', 'approve service provider');
	CALL m_builtin_privilege(@ptid, 'ban', 'ban/unban service provider');

	CALL m_builtin_privilege_type('ServiceProviders','service provider admin',0,0,1);
	CALL m_builtin_privilege(@ptid, 'register', 'register service provider');
	CALL m_builtin_privilege(@ptid, 'modify', 'modify service provider registration info');
	CALL m_builtin_privilege(@ptid, 'shut', 'shut service provider');
	CALL m_builtin_privilege(@ptid, 'export', 'export service provider data');
	CALL m_builtin_privilege(@ptid, 'destroy', 'destroy service provider data');

	CALL m_builtin_privilege_type('ServiceGovern','service governance',0,1,0);
	CALL m_builtin_privilege(@ptid, 'view', 'view services');
	CALL m_builtin_privilege(@ptid, 'approve', 'approve service');
	CALL m_builtin_privilege(@ptid, 'ban', 'ban/unban service');

	CALL m_builtin_privilege_type('ServiceAdmin','service admin',0,0,1);
	CALL m_builtin_privilege(@ptid, 'create', 'create service');
	CALL m_builtin_privilege(@ptid, 'modify', 'modify service');
	CALL m_builtin_privilege(@ptid, 'modifyCard', 'modify service card');
	CALL m_builtin_privilege(@ptid, 'submit', 'submit service for approvement');
	CALL m_builtin_privilege(@ptid, 'unpublish', 'unpublish service');

	CALL m_builtin_privilege_type('ServiceOrderAdmin','service order admin',0,0,1);
	CALL m_builtin_privilege(@ptid, 'view', 'view orders');
	CALL m_builtin_privilege(@ptid, 'confirm', 'confirm orders');
	CALL m_builtin_privilege(@ptid, 'accept', 'accept orders');

	CALL m_builtin_privilege_type('Services','service',0,1,0);
	CALL m_builtin_privilege(@ptid, 'addFavorite', 'mark service as favorite');
	CALL m_builtin_privilege(@ptid, 'order', 'order services');

	CALL m_builtin_privilege_type('ResourceCategoryAdmin','resource category admin',0,1,0);
	CALL m_builtin_privilege(@ptid, 'view', 'view resource categories');
	CALL m_builtin_privilege(@ptid, 'modify', 'modify resource category');
	CALL m_builtin_privilege(@ptid, 'remove', 'remove resource category');

	CALL m_builtin_privilege_type('ResourceGovern','resource governance',0,1,0);
	CALL m_builtin_privilege(@ptid, 'publishCatalog', 'publish resource catalog');
	CALL m_builtin_privilege(@ptid, 'publishResource', 'publish resource');

	CALL m_builtin_privilege_type('ResourceAdmin','resource admin',0,1,1);
	CALL m_builtin_privilege(@ptid, 'submitResource', 'submit resource');
	CALL m_builtin_privilege(@ptid, 'modifyCatalog', 'modify catalog');
	CALL m_builtin_privilege(@ptid, 'modifyCatalogItem', 'modify resource');
	CALL m_builtin_privilege(@ptid, 'removeCatalogItem', 'reomve resource form catalog');
	CALL m_builtin_privilege(@ptid, 'developResource', 'develop resource');
	CALL m_builtin_privilege(@ptid, 'removeResource', 'remove resource');
	CALL m_builtin_privilege(@ptid, 'exportResource', 'export resource');
	CALL m_builtin_privilege(@ptid, 'importResource', 'import resource');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_scope` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_scope`()
BEGIN
	DECLARE sid, oid, osid BIGINT(40) UNSIGNED;
	DECLARE issys TINYINT(1);
	DECLARE org_name VARCHAR(80);
	DECLARE org_scope_cur CURSOR FOR SELECT s.scope_id, s.org_id, s.is_system, o.name, o.scope_id FROM scope AS s RIGHT JOIN org AS o ON o.org_id = s.org_id WHERE s.is_classification IS NULL OR s.is_classification=0;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @done = 1;

	

	SET @done = 0;

	OPEN org_scope_cur;

	REPEAT
		FETCH org_scope_cur INTO sid, oid, issys, org_name, osid;
		IF NOT @done THEN
			
			IF sid IS NULL THEN
				INSERT INTO scope (`org_id`,`name`,`is_classification`,`is_system`,`type`) 
					VALUES (oid, org_name, 0, 0, 'place');
				SET sid = LAST_INSERT_ID();
				SET issys = 0;
			END IF;

			
			IF osid IS NULL THEN
				UPDATE org SET scope_id = sid WHERE org_id = oid;
			END IF;

			IF issys = 1 THEN
				
				CALL m_builtin_scope_site(sid);
			ELSE
				
				CALL m_builtin_scope_org(sid);
			END IF;
		END IF;
	UNTIL @done END REPEAT;

	CLOSE org_scope_cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_user_role` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_user_role`()
BEGIN
	DECLARE u BIGINT(40) UNSIGNED;
	DECLARE ia TINYINT(1);
	DECLARE user_cur CURSOR FOR SELECT user_id, is_admin FROM register_user;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @done = 1;

	SET @done = 0;

	SELECT org_id, scope_id INTO @wooid, @wosid FROM scope WHERE is_classification = 0 AND is_system = 1 AND `type` = 'site';
	IF @wooid IS NULL THEN
		SELECT warning_scope_classification_or_type_not_fixed FROM scope;
	END IF;

	OPEN user_cur;

	REPEAT
		FETCH user_cur INTO u, ia;
		IF NOT @done THEN
			CALL m_user_role(u, ia);
		END IF;
	UNTIL @done END REPEAT;

	CLOSE user_cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_user_default_role` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_user_default_role`(o BIGINT(40) UNSIGNED, s BIGINT(40) UNSIGNED, u BIGINT(40) UNSIGNED, rn VARCHAR(256))
BEGIN
	DECLARE rid BIGINT(40) UNSIGNED;
	DECLARE c INT;

	SELECT role_id INTO rid FROM role WHERE scope_id = s AND name = rn AND built_in = 1;
	IF rid IS NULL THEN
		SELECT warning_scope_not_fixed FROM role;
	END IF;

	SELECT COUNT(*) INTO c FROM role_user_mapping WHERE role_id = rid AND user_id = u;
	IF c = 0 THEN
		INSERT INTO role_user_mapping (`role_id`, `user_id`) VALUES (rid, u);
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `m_user_role` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_user_role`(u BIGINT(40) UNSIGNED, ia TINYINT(1))
BEGIN
	DECLARE s_wa, s_po, s_pa, s_pm TINYINT(1) DEFAULT 0;
	DECLARE p, s BIGINT(40) UNSIGNED;
	DECLARE t ENUM('official','employee','customer','admin','relate','incomer');
	DECLARE pu_cur CURSOR FOR SELECT pu.party_id, pu.`type`, o.scope_id FROM party_user_mapping AS pu JOIN org AS o ON pu.party_id = o.org_id WHERE pu.user_id = u AND pu.`type` != 'relate';
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @ur_done = 1;

	IF @wooid IS NULL THEN
		SELECT org_id, scope_id INTO @wooid, @wosid FROM scope WHERE is_classification = 0 AND is_system = 1 AND type = site;
		IF @wooid IS NULL THEN
			SELECT warning_scope_classification_or_type_not_fixed FROM scope;
		END IF;
	END IF;

	SET @ur_done = 0;

	OPEN pu_cur;

	REPEAT
		FETCH pu_cur INTO p, t, s;
		IF NOT @ur_done THEN
			IF p = @wooid THEN
				IF t = 'admin' THEN
					CALL m_user_default_role(@wooid, @wosid, u, 'webadmin');
					SET s_wa = 1;
				ELSEIF t = 'employee' AND ia THEN
					CALL m_user_default_role(@wooid, @wosid, u, 'webadmin');
					SET s_wa = 1;
				END IF;
			ELSE
				IF t = 'admin' THEN
					CALL m_user_default_role(p, s, u, 'placeowner');
					SET s_po = 1;
				ELSEIF t = 'employee' AND ia THEN
					CALL m_user_default_role(p, s, u, 'placeadmin');
					SET s_pa = 1;
				ELSE
					CALL m_user_default_role(p, s, u, 'placemember');
					SET s_pm = 1;
				END IF;
			END IF;
		END IF;
	UNTIL @ur_done END REPEAT;

	CLOSE pu_cur;

	IF NOT s_wa THEN
		IF s_po THEN
			CALL m_user_default_role(@wooid, @wosid, u, 'gplaceowner');
		ELSEIF s_pa THEN
			CALL m_user_default_role(@wooid, @wosid, u, 'gplaceadmin');
		ELSE
			CALL m_user_default_role(@wooid, @wosid, u, 'user');
		END IF;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pr_clean_uumaping` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `pr_clean_uumaping`()
begin
	declare done int default false;
	declare v_uu_id bigint(40);
	declare v_from_user bigint(40);
	declare v_to_user bigint(40);
	declare v_type enum('friend','follow');
	declare v_cur cursor for select uu_id, from_user, to_user, type from user_user_mapping;
	declare continue handler for not found set done = true;

	drop temporary table if exists uutemp;
        create temporary table uutemp (
	    uu_id bigint(40),
	    from_user bigint(40),
	    to_user bigint(40),
            type enum('friend','follow')
	);	
	open v_cur;	
	
	main_loop: loop
		fetch v_cur into v_uu_id, v_from_user, v_to_user, v_type;
		if done then
      		leave main_loop;
    	end if;
    		if not exists (select * from uutemp where from_user = v_from_user and to_user = v_to_user and type = v_type) then
		   insert into uutemp (uu_id, from_user, to_user, type) values (v_uu_id, v_from_user, v_to_user, v_type);
		end if;
	end loop;	
	
	close v_cur;
	delete from user_user_mapping;
	insert into user_user_mapping (select * from uutemp);
        drop temporary table uutemp;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pr_ru_alter_mobile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `pr_ru_alter_mobile`()
begin
	declare done int default false;
	declare v_user_id int(10);
	declare v_cur cursor for select user_id from register_user;
	declare continue handler for not found set done = true;
	open v_cur;	
	
	main_loop: loop
		fetch v_cur into v_user_id;
		if done then
      		leave main_loop;
    	end if;
    		update register_user set mobile = v_user_id where user_id = v_user_id;
	end loop;	
	
	close v_cur;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Current Database: `tfs_name_db`
--

/*!40000 DROP DATABASE IF EXISTS `tfs_name_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `tfs_name_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `tfs_name_db`;

--
-- Table structure for table `t_app_info`
--

DROP TABLE IF EXISTS `t_app_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_app_info` (
  `app_key` varchar(255) NOT NULL DEFAULT '',
  `id` int(11) DEFAULT NULL,
  `quto` bigint(20) DEFAULT NULL,
  `cluster_group_id` int(11) DEFAULT NULL,
  `use_remote_cache` int(11) DEFAULT '0',
  `app_name` varchar(255) NOT NULL,
  `app_owner` varchar(255) DEFAULT NULL,
  `report_interval` int(11) DEFAULT NULL,
  `need_duplicate` int(11) DEFAULT NULL,
  `rem` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`app_key`),
  UNIQUE KEY `app_info_un_name` (`app_name`),
  UNIQUE KEY `app_info_un_id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_app_ip_replace`
--

DROP TABLE IF EXISTS `t_app_ip_replace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_app_ip_replace` (
  `app_id` int(11) NOT NULL DEFAULT '0',
  `source_ip` varchar(64) NOT NULL DEFAULT '',
  `turn_ip` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`app_id`,`source_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_app_stat`
--

DROP TABLE IF EXISTS `t_app_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_app_stat` (
  `app_id` int(11) NOT NULL DEFAULT '0',
  `used_capacity` bigint(20) DEFAULT NULL,
  `file_count` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`app_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_base_info_update_time`
--

DROP TABLE IF EXISTS `t_base_info_update_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_base_info_update_time` (
  `base_last_update_time` datetime DEFAULT NULL,
  `app_last_update_time` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_caculate_ip_info`
--

DROP TABLE IF EXISTS `t_caculate_ip_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_caculate_ip_info` (
  `source_ip` varchar(64) NOT NULL DEFAULT '',
  `caculate_ip` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`source_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_cluster_cache_info`
--

DROP TABLE IF EXISTS `t_cluster_cache_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cluster_cache_info` (
  `cache_server_addr` varchar(128) NOT NULL DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`cache_server_addr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_cluster_rack_duplicate_server`
--

DROP TABLE IF EXISTS `t_cluster_rack_duplicate_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cluster_rack_duplicate_server` (
  `cluster_rack_id` int(11) NOT NULL DEFAULT '0',
  `dupliate_server_addr` varchar(64) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`cluster_rack_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_cluster_rack_group`
--

DROP TABLE IF EXISTS `t_cluster_rack_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cluster_rack_group` (
  `cluster_group_id` int(11) NOT NULL DEFAULT '0',
  `cluster_rack_id` int(11) NOT NULL DEFAULT '0',
  `cluster_rack_access_type` int(11) DEFAULT NULL,
  `rem` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`cluster_group_id`,`cluster_rack_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_cluster_rack_info`
--

DROP TABLE IF EXISTS `t_cluster_rack_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cluster_rack_info` (
  `cluster_rack_id` int(11) NOT NULL DEFAULT '0',
  `cluster_id` varchar(8) NOT NULL DEFAULT '',
  `ns_vip` varchar(64) DEFAULT NULL,
  `cluster_stat` int(11) DEFAULT NULL,
  `rem` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`cluster_rack_id`,`cluster_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_meta_root_info`
--

DROP TABLE IF EXISTS `t_meta_root_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_meta_root_info` (
  `app_id` int(11) NOT NULL DEFAULT '0',
  `addr_info` varchar(64) NOT NULL,
  `stat` int(11) NOT NULL DEFAULT '1',
  `rem` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`app_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_resource_server_info`
--

DROP TABLE IF EXISTS `t_resource_server_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_resource_server_info` (
  `addr_info` varchar(64) NOT NULL,
  `stat` int(11) NOT NULL DEFAULT '1',
  `rem` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`addr_info`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_session_info`
--

DROP TABLE IF EXISTS `t_session_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_session_info` (
  `session_id` varchar(255) NOT NULL DEFAULT '',
  `cache_size` bigint(20) DEFAULT NULL,
  `cache_time` bigint(20) DEFAULT NULL,
  `client_version` varchar(64) DEFAULT NULL,
  `log_out_time` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_session_stat`
--

DROP TABLE IF EXISTS `t_session_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_session_stat` (
  `session_id` varchar(255) NOT NULL DEFAULT '',
  `oper_type` int(11) NOT NULL DEFAULT '0',
  `oper_times` bigint(20) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `response_time` int(11) DEFAULT NULL,
  `succ_times` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `modify_time` datetime DEFAULT NULL,
  PRIMARY KEY (`session_id`,`oper_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'tfs_name_db'
--

--
-- Current Database: `togressa`
--

/*!40000 DROP DATABASE IF EXISTS `togressa`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `togressa` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `togressa`;

--
-- Table structure for table `boc_logs_type`
--

DROP TABLE IF EXISTS `boc_logs_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boc_logs_type` (
  `type_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `first_entry` varchar(50) DEFAULT NULL,
  `second_entry` varchar(50) DEFAULT NULL,
  `third_entry` varchar(50) DEFAULT NULL,
  `verb` varchar(50) DEFAULT NULL,
  `object` varchar(50) DEFAULT NULL,
  `entry_name` varchar(500) DEFAULT '',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `boc_manage_logs`
--

DROP TABLE IF EXISTS `boc_manage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boc_manage_logs` (
  `log_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(5) unsigned DEFAULT NULL,
  `user_id` bigint(40) unsigned DEFAULT NULL,
  `time_created` int(11) NOT NULL,
  `client_ip` varchar(50) DEFAULT NULL,
  `client_type` enum('web','mobile','pad') DEFAULT 'web',
  `detail` varchar(512) DEFAULT '',
  `app_id` varchar(50) DEFAULT NULL,
  `user_name` varchar(200) DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `fk_boc_logs` (`type_id`),
  CONSTRAINT `fk_boc_logs` FOREIGN KEY (`type_id`) REFERENCES `boc_logs_type` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tgs_configs`
--

DROP TABLE IF EXISTS `tgs_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tgs_configs` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `KY` varchar(100) NOT NULL,
  `VL` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `KY` (`KY`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tgs_logs`
--

DROP TABLE IF EXISTS `tgs_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tgs_logs` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SOURCE_ID` varchar(50) NOT NULL,
  `SOURCE_NAME` varchar(120) NOT NULL,
  `LEVEL` varchar(20) NOT NULL,
  `TYPE` varchar(50) NOT NULL,
  `OCCURRED_AT` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `USER_ID` varchar(50) DEFAULT NULL,
  `ORIGINATED_FROM` varchar(50) DEFAULT NULL,
  `CLIENT_IP` varchar(50) DEFAULT NULL,
  `SITE_ID` varchar(100) DEFAULT NULL,
  `SITE_NAME` varchar(50) DEFAULT NULL,
  `RECIPIENT_TYPE` varchar(50) DEFAULT NULL,
  `RECIPIENT_ID` varchar(120) DEFAULT NULL,
  `MESSAGE` text,
  `ADDED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=266175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'togressa'
--

--
-- Current Database: `topicdb`
--

/*!40000 DROP DATABASE IF EXISTS `topicdb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `topicdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `topicdb`;

--
-- Table structure for table `activity_usage_type`
--

DROP TABLE IF EXISTS `activity_usage_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_usage_type` (
  `ausage_type_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT '',
  `identify` varchar(50) NOT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`ausage_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `apply_object`
--

DROP TABLE IF EXISTS `apply_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apply_object` (
  `object_id` int(10) NOT NULL AUTO_INCREMENT,
  `object_name` varchar(50) NOT NULL,
  `parent_id` int(10) DEFAULT '0',
  PRIMARY KEY (`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `approval_record`
--

DROP TABLE IF EXISTS `approval_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `approval_record` (
  `record_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `status` enum('agree','refuse','wait_approval','uncommitted') DEFAULT 'uncommitted',
  `approver_id` bigint(40) NOT NULL,
  `time_created` bigint(13) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `topic_id` bigint(40) DEFAULT '0',
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `archive_beinvokedof_topic`
--

DROP TABLE IF EXISTS `archive_beinvokedof_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `archive_beinvokedof_topic` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `archive_id` bigint(40) NOT NULL,
  `topic_id` bigint(40) NOT NULL,
  `time_invoked` bigint(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `archive_permission`
--

DROP TABLE IF EXISTS `archive_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `archive_permission` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `archive_id` bigint(40) NOT NULL,
  `user_id` bigint(40) NOT NULL,
  `is_manage` tinyint(4) DEFAULT '0',
  `is_invoke` tinyint(4) DEFAULT '0',
  `is_read` tinyint(4) DEFAULT '0',
  `operator_id` bigint(40) NOT NULL,
  `time_operated` bigint(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assign_record`
--

DROP TABLE IF EXISTS `assign_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assign_record` (
  `record_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `assigner_id` bigint(40) NOT NULL,
  `designee_id` bigint(40) DEFAULT NULL,
  `status` enum('noassign','unconfirmed','assigned') DEFAULT 'unconfirmed',
  `action` enum('delete_assign','again_assign','assign','confirm_assign') DEFAULT 'assign',
  `operator_id` bigint(40) DEFAULT NULL,
  `issue_topic_id` bigint(40) DEFAULT '0',
  `assign_topic_id` bigint(40) DEFAULT '0',
  `time_created` bigint(13) DEFAULT '0',
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_point`
--

DROP TABLE IF EXISTS `check_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_point` (
  `point_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `content` varchar(1024) DEFAULT '',
  `time_ended` bigint(13) DEFAULT '0',
  `time_finished` bigint(13) DEFAULT '0',
  `status` enum('finished','unfinished') DEFAULT 'unfinished',
  `creator_id` bigint(40) NOT NULL,
  `time_created` bigint(13) NOT NULL,
  `disposer_id` bigint(40) DEFAULT '0',
  `accepter_id` bigint(40) DEFAULT '0',
  `time_started` bigint(13) DEFAULT '0',
  `is_sync` int(1) DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0',
  `time_updated` bigint(13) DEFAULT '0',
  `action` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`point_id`),
  KEY `fk_topic_point` (`topic_id`),
  CONSTRAINT `fk_topic_point` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkpoint_topic_relation`
--

DROP TABLE IF EXISTS `checkpoint_topic_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkpoint_topic_relation` (
  `point_id` bigint(40) NOT NULL,
  `topic_id` bigint(40) NOT NULL,
  `type` enum('issue','topic') NOT NULL DEFAULT 'issue',
  PRIMARY KEY (`point_id`,`topic_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `discussion_usage_type`
--

DROP TABLE IF EXISTS `discussion_usage_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_usage_type` (
  `dusage_type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT '',
  `identify` varchar(50) NOT NULL,
  `attribute_type` varchar(50) DEFAULT '',
  `is_binding_topic` tinyint(1) DEFAULT '0',
  `singleton` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`dusage_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `identify`
--

DROP TABLE IF EXISTS `identify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identify` (
  `identify_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `identify_value` varchar(200) DEFAULT NULL,
  `time_created` bigint(13) NOT NULL DEFAULT '0',
  `creator_id` bigint(40) NOT NULL DEFAULT '0',
  PRIMARY KEY (`identify_id`),
  KEY `fk_identify_type` (`type_id`),
  CONSTRAINT `fk_identify_type` FOREIGN KEY (`type_id`) REFERENCES `identify_type` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `identify_type`
--

DROP TABLE IF EXISTS `identify_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identify_type` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `issue_security_setting`
--

DROP TABLE IF EXISTS `issue_security_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_security_setting` (
  `setting_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `member_add_member` tinyint(1) DEFAULT '0',
  `allow_copy_text` tinyint(1) DEFAULT '0',
  `allow_download_picture` tinyint(1) DEFAULT '0',
  `member_source_inside` tinyint(1) DEFAULT '0',
  `share_destination` enum('unlimited','enterprise','disable','topic') DEFAULT 'disable',
  PRIMARY KEY (`setting_id`),
  KEY `fk_issue_security` (`topic_id`),
  CONSTRAINT `fk_issue_security` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `label`
--

DROP TABLE IF EXISTS `label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label` (
  `label_id` int(10) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(50) NOT NULL,
  `type` enum('todo_check','approval_refuse') NOT NULL,
  PRIMARY KEY (`label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org_security_setting`
--

DROP TABLE IF EXISTS `org_security_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org_security_setting` (
  `setting_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(40) NOT NULL,
  `member_add_member` tinyint(1) DEFAULT '0',
  `allow_copy_text` tinyint(1) DEFAULT '0',
  `allow_download_picture` tinyint(1) DEFAULT '0',
  `member_source_inside` tinyint(1) DEFAULT '0',
  `share_destination` enum('unlimited','enterprise','disable') DEFAULT 'disable',
  `topiclist_admin_only` tinyint(1) DEFAULT '1',
  `issuelist_admin_only` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plan_approval`
--

DROP TABLE IF EXISTS `plan_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plan_approval` (
  `approval_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) DEFAULT '0',
  `approver_id` bigint(40) DEFAULT '0',
  `result_status` enum('agree','refuse','wait_approval','uncommitted') DEFAULT 'uncommitted',
  `applicant_id` bigint(40) DEFAULT '0',
  `time_applied` bigint(13) DEFAULT '0',
  `time_approved` bigint(13) DEFAULT '0',
  `note` varchar(1000) DEFAULT '',
  PRIMARY KEY (`approval_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recipient_list`
--

DROP TABLE IF EXISTS `recipient_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipient_list` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `recipient_id` bigint(40) NOT NULL,
  `status` enum('confirmed','unconfirmed') DEFAULT 'unconfirmed',
  `time_updated` bigint(13) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_recipient_topic` (`topic_id`),
  CONSTRAINT `fk_recipient_topic` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reply_archive`
--

DROP TABLE IF EXISTS `reply_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reply_archive` (
  `archive_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `archive_num` varchar(30) NOT NULL,
  `name` varchar(200) DEFAULT '',
  `brief_desc` varchar(1000) DEFAULT '',
  `description` varchar(200) DEFAULT '',
  `owner_id` bigint(40) DEFAULT '0',
  `creator_id` bigint(40) NOT NULL DEFAULT '0',
  `acceptor_id` bigint(40) DEFAULT '0',
  `approver_id` bigint(40) DEFAULT '0',
  `time_started` bigint(13) DEFAULT '0',
  `time_ended` bigint(13) DEFAULT '0',
  `time_finished` bigint(13) DEFAULT '0',
  `remark` varchar(1024) DEFAULT '',
  `currency` varchar(50) DEFAULT '',
  `price` double DEFAULT '0',
  `approval_result` varchar(50) DEFAULT '',
  `approval_note` varchar(1000) DEFAULT '',
  `topic_id` bigint(40) NOT NULL,
  `is_enable` tinyint(1) NOT NULL DEFAULT '1',
  `applicant_id` bigint(40) DEFAULT '0',
  `time_applied` bigint(13) DEFAULT '0',
  `time_approved` bigint(13) DEFAULT '0',
  `parent_id` bigint(40) DEFAULT NULL,
  `parent_name` varchar(500) DEFAULT NULL,
  `archive_uid` varchar(32) DEFAULT '',
  `party_id` bigint(40) DEFAULT '0',
  PRIMARY KEY (`archive_id`),
  UNIQUE KEY `archive_num` (`archive_num`),
  UNIQUE KEY `archive_num_2` (`archive_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resource_issue_prepare_mapping`
--

DROP TABLE IF EXISTS `resource_issue_prepare_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_issue_prepare_mapping` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(40) NOT NULL,
  `res_id` bigint(40) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rip_resource` (`res_id`),
  CONSTRAINT `fk_rip_resource` FOREIGN KEY (`res_id`) REFERENCES `resources` (`res_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resource_issue_usage_log`
--

DROP TABLE IF EXISTS `resource_issue_usage_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_issue_usage_log` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(40) NOT NULL,
  `res_id` bigint(40) NOT NULL,
  `status` enum('reserved','applying','given','return','revoked') DEFAULT 'reserved',
  `operator_id` bigint(40) DEFAULT '0',
  `time_created` bigint(13) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ri_resource` (`res_id`),
  CONSTRAINT `fk_ri_resource` FOREIGN KEY (`res_id`) REFERENCES `resources` (`res_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `res_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) DEFAULT NULL,
  `name` varchar(200) DEFAULT '',
  `status` enum('preparing','ready') DEFAULT NULL,
  `creator_id` bigint(40) NOT NULL,
  `keeper_id` bigint(40) NOT NULL,
  `time_created` bigint(13) NOT NULL,
  PRIMARY KEY (`res_id`),
  KEY `fk_resources_topic` (`topic_id`),
  CONSTRAINT `fk_resources_topic` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `template_item`
--

DROP TABLE IF EXISTS `template_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_item` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ausage_type_id` int(10) NOT NULL,
  `dusage_type_id` bigint(20) NOT NULL,
  `name` varchar(200) DEFAULT '',
  `is_allow_delete` tinyint(1) DEFAULT '0',
  `is_preset` tinyint(1) DEFAULT '0',
  `is_default_discuss` tinyint(1) DEFAULT '0',
  `is_parent_son_relation` tinyint(1) DEFAULT '1',
  `is_member_visible` tinyint(1) DEFAULT '1',
  `is_outsider_visible` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`item_id`),
  KEY `fk_rtt_item` (`dusage_type_id`),
  KEY `fk_activity_type_item` (`ausage_type_id`),
  CONSTRAINT `fk_activity_type_item` FOREIGN KEY (`ausage_type_id`) REFERENCES `activity_usage_type` (`ausage_type_id`),
  CONSTRAINT `fk_rtt_item` FOREIGN KEY (`dusage_type_id`) REFERENCES `discussion_usage_type` (`dusage_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic` (
  `topic_id` bigint(40) NOT NULL DEFAULT '0',
  `name` varchar(2000) DEFAULT '',
  `user_id` bigint(40) NOT NULL,
  `time_created` bigint(13) NOT NULL,
  `recent_as` text,
  `time_as_update` bigint(13) DEFAULT NULL,
  `unread_show` tinyint(1) DEFAULT '1',
  `reward_checkin` tinyint(1) DEFAULT '0',
  `status` enum('open','close') DEFAULT 'open',
  `is_delete` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_apply_mapping`
--

DROP TABLE IF EXISTS `topic_apply_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_apply_mapping` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `object_id` int(10) NOT NULL,
  `topic_id` bigint(40) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tam_object` (`object_id`),
  KEY `fk_tam_topic` (`topic_id`),
  CONSTRAINT `fk_tam_object` FOREIGN KEY (`object_id`) REFERENCES `apply_object` (`object_id`),
  CONSTRAINT `fk_tam_topic` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_apply_object`
--

DROP TABLE IF EXISTS `topic_apply_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_apply_object` (
  `apply_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `object_id` int(10) NOT NULL,
  `object_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`apply_id`),
  KEY `fk_tao_topic` (`topic_id`),
  KEY `fk_tao_object` (`object_id`),
  CONSTRAINT `fk_tao_topic` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_apply_record`
--

DROP TABLE IF EXISTS `topic_apply_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_apply_record` (
  `record_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `user_id` bigint(40) NOT NULL,
  `status` enum('applying','inviting') DEFAULT NULL,
  `time_created` bigint(13) DEFAULT '0',
  PRIMARY KEY (`record_id`),
  KEY `fk_topic_apply_record` (`topic_id`),
  CONSTRAINT `fk_topic_apply_record` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_entity`
--

DROP TABLE IF EXISTS `topic_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_entity` (
  `topic_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) DEFAULT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `creator_id` bigint(40) NOT NULL,
  `parent_id` bigint(40) DEFAULT '0',
  `source_id` bigint(40) DEFAULT '0',
  `is_ban` tinyint(1) DEFAULT '0',
  `is_delete` tinyint(1) DEFAULT '0',
  `status` enum('finished','created','closed','submitted','countermand','approved','processed','realized') DEFAULT 'created',
  `recent_as` text,
  `unread_show` tinyint(1) DEFAULT '1',
  `reward_checkin` tinyint(1) DEFAULT '0',
  `is_allow_join` tinyint(1) DEFAULT '1',
  `time_created` bigint(13) NOT NULL,
  `time_ended` bigint(13) DEFAULT NULL,
  `owner_id` bigint(40) DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `root_topic_id` bigint(40) DEFAULT '0',
  `is_allow_tour` tinyint(1) DEFAULT '1',
  `password` varchar(40) DEFAULT NULL,
  `time_finished` bigint(13) DEFAULT NULL,
  `type` enum('task','discussion','group') DEFAULT 'task',
  `assign_status` enum('unconfirmed','assigned','none') DEFAULT 'none',
  `price` double DEFAULT '0',
  `usage_type_id` bigint(20) DEFAULT '1',
  `brief_desc` varchar(1000) DEFAULT NULL,
  `is_chat_room` tinyint(4) DEFAULT '0',
  `is_publish` tinyint(1) DEFAULT '0',
  `currency` enum('Rmb','Twd','Euro','Dollar') DEFAULT 'Rmb',
  `time_started` bigint(13) DEFAULT '0',
  `remark` varchar(5000) DEFAULT '',
  `is_show_money` tinyint(1) DEFAULT '1',
  `acceptor_id` bigint(40) DEFAULT '0',
  `approver_id` bigint(40) DEFAULT '0',
  `attachment` text,
  `result_label_id` int(10) DEFAULT NULL,
  `result_message` varchar(500) DEFAULT '',
  `feetype` enum('income','expense') DEFAULT 'expense',
  `party_id` bigint(40) DEFAULT '0',
  `time_updated` bigint(13) DEFAULT '0',
  `result_attachment` text,
  `time_processed` bigint(13) DEFAULT '0',
  `time_closed` bigint(13) DEFAULT '0',
  `topic_uid` varchar(32) DEFAULT '',
  `time_dispose_send` bigint(13) DEFAULT '0',
  `time_dispose_confirm` bigint(13) DEFAULT '0',
  `time_acceptance_send` bigint(13) DEFAULT '0',
  `time_acceptance_confirm` bigint(13) DEFAULT '0',
  PRIMARY KEY (`topic_id`),
  KEY `fk_topic_label` (`result_label_id`),
  CONSTRAINT `fk_topic_label` FOREIGN KEY (`result_label_id`) REFERENCES `label` (`label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5023 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_member`
--

DROP TABLE IF EXISTS `topic_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_member` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `member_id` bigint(40) NOT NULL,
  `time_joined` bigint(13) NOT NULL,
  `introducer_id` bigint(40) DEFAULT '0',
  `topicmember_nickname` varchar(500) DEFAULT NULL,
  `is_topic_admin` tinyint(1) DEFAULT '1',
  `staff_tag` enum('none','serviceprovider','absent','principal','tourer') DEFAULT NULL,
  `staff_name` varchar(200) DEFAULT '',
  `sub_tag` enum('none','inspector','resourcemanager') DEFAULT 'none',
  PRIMARY KEY (`id`),
  KEY `fk_topic_member` (`topic_id`),
  CONSTRAINT `fk_topic_member` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_member_mapping`
--

DROP TABLE IF EXISTS `topic_member_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_member_mapping` (
  `topic_id` bigint(40) NOT NULL DEFAULT '0',
  `member_type` enum('people','team') NOT NULL DEFAULT 'people',
  `member_id` bigint(40) NOT NULL DEFAULT '0',
  `time_joined` bigint(13) NOT NULL,
  `owner_id` bigint(40) DEFAULT '0',
  `is_active` int(1) DEFAULT '1',
  PRIMARY KEY (`topic_id`,`member_type`,`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_notice`
--

DROP TABLE IF EXISTS `topic_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_notice` (
  `topic_id` bigint(40) NOT NULL DEFAULT '0',
  `owner_id` bigint(40) DEFAULT '0',
  `acceptor_id` bigint(40) DEFAULT '0',
  `old_owner_id` bigint(40) DEFAULT '0',
  `old_acceptor_id` bigint(40) DEFAULT '0',
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_photo`
--

DROP TABLE IF EXISTS `topic_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_photo` (
  `picture_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `tfs_id` varchar(50) NOT NULL,
  `filename` varchar(50) DEFAULT '',
  `topic_id` bigint(40) NOT NULL,
  `description` varchar(1024) DEFAULT '',
  `is_publish` tinyint(1) DEFAULT '0',
  `user_id` bigint(40) unsigned NOT NULL,
  `time_upload` bigint(13) NOT NULL,
  `time_updated` bigint(13) DEFAULT '0',
  `url` varchar(2000) DEFAULT NULL,
  `type` enum('archive','default') DEFAULT 'default',
  PRIMARY KEY (`picture_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_poster`
--

DROP TABLE IF EXISTS `topic_poster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_poster` (
  `poster_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `t_url` varchar(1000) DEFAULT '',
  `origin_url` varchar(1000) DEFAULT '',
  `tfs_id` varchar(50) DEFAULT '',
  `time_created` bigint(13) DEFAULT '0',
  PRIMARY KEY (`poster_id`),
  KEY `fk_topic_poster` (`topic_id`),
  CONSTRAINT `fk_topic_poster` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_realize`
--

DROP TABLE IF EXISTS `topic_realize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_realize` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `message` varchar(500) DEFAULT '',
  `attachment` text,
  `topic_id` bigint(40) NOT NULL,
  `time_realized` bigint(13) NOT NULL,
  `operator_id` bigint(40) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_realize_topic` (`topic_id`),
  CONSTRAINT `fk_realize_topic` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_relation_mapping`
--

DROP TABLE IF EXISTS `topic_relation_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_relation_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `from_topic_id` bigint(40) NOT NULL,
  `to_topic_id` bigint(40) NOT NULL,
  `relation` enum('before_after','other') NOT NULL DEFAULT 'other',
  `creator_id` bigint(40) NOT NULL,
  `time_created` bigint(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_security_setting`
--

DROP TABLE IF EXISTS `topic_security_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_security_setting` (
  `setting_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(40) NOT NULL,
  `member_add_member` tinyint(1) DEFAULT '0',
  `allow_copy_text` tinyint(1) DEFAULT '0',
  `allow_download_picture` tinyint(1) DEFAULT '0',
  `member_source_inside` tinyint(1) DEFAULT '0',
  `share_destination` enum('unlimited','enterprise','disable') DEFAULT 'disable',
  PRIMARY KEY (`setting_id`),
  KEY `fk_topic_security` (`topic_id`),
  CONSTRAINT `fk_topic_security` FOREIGN KEY (`topic_id`) REFERENCES `topic_entity` (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `topic_sync`
--

DROP TABLE IF EXISTS `topic_sync`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic_sync` (
  `topic_id` bigint(40) NOT NULL DEFAULT '0',
  `user_id` bigint(40) NOT NULL DEFAULT '0',
  `time_synced` bigint(13) NOT NULL,
  PRIMARY KEY (`topic_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'topicdb'
--

--
-- Current Database: `appdb`
--

/*!40000 DROP DATABASE IF EXISTS `appdb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `appdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `appdb`;

--
-- Table structure for table `app_thirdapp_setting`
--

DROP TABLE IF EXISTS `app_thirdapp_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_thirdapp_setting` (
  `setting_id` int(5) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(100) NOT NULL DEFAULT '',
  `third_appkey` varchar(100) NOT NULL DEFAULT '',
  `config_id` int(5) NOT NULL,
  `value` varchar(300) DEFAULT '',
  PRIMARY KEY (`setting_id`),
  KEY `fk_config` (`config_id`),
  CONSTRAINT `fk_config` FOREIGN KEY (`config_id`) REFERENCES `thirdapp_config` (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_thirdapp_status`
--

DROP TABLE IF EXISTS `app_thirdapp_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_thirdapp_status` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(100) NOT NULL DEFAULT '',
  `third_appkey` varchar(100) NOT NULL DEFAULT '',
  `status` enum('open','close') DEFAULT 'open',
  `platform` enum('android','apple','microsoft') DEFAULT 'android',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `applist`
--

DROP TABLE IF EXISTS `applist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applist` (
  `app_id` int(5) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `creator_id` bigint(40) NOT NULL,
  `time_created` int(11) NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  `deleter_id` bigint(40) DEFAULT '0',
  `time_deleted` int(11) DEFAULT '0',
  `start_page_url` varchar(200) DEFAULT '',
  PRIMARY KEY (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_applist`
--

DROP TABLE IF EXISTS `third_applist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_applist` (
  `third_appkey` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`third_appkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `thirdapp_config`
--

DROP TABLE IF EXISTS `thirdapp_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thirdapp_config` (
  `config_id` int(5) NOT NULL AUTO_INCREMENT,
  `third_appkey` varchar(100) NOT NULL DEFAULT '',
  `config_key` varchar(100) NOT NULL DEFAULT '',
  `platform` enum('android','apple','microsoft') DEFAULT 'android',
  PRIMARY KEY (`config_id`),
  KEY `fk_thirdapp` (`third_appkey`),
  CONSTRAINT `fk_thirdapp` FOREIGN KEY (`third_appkey`) REFERENCES `third_applist` (`third_appkey`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'appdb'
--

--
-- Current Database: `activitystreamdb`
--

USE `activitystreamdb`;

--
-- Current Database: `addb`
--

USE `addb`;

--
-- Current Database: `assetdb`
--

USE `assetdb`;

--
-- Current Database: `docdb`
--

USE `docdb`;

--
-- Current Database: `maintaindb`
--

USE `maintaindb`;

--
-- Current Database: `partydb`
--

USE `partydb`;

--
-- Final view structure for view `v_unique_mobile`
--

/*!50001 DROP VIEW IF EXISTS `v_unique_mobile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_unique_mobile` AS select `register_user`.`user_id` AS `user_id`,`register_user`.`username` AS `username`,`register_user`.`password` AS `password`,`register_user`.`mobile` AS `mobile`,`register_user`.`deleted` AS `deleted` from `register_user` where ((`register_user`.`mobile` is not null) and (`register_user`.`mobile` <> '') and (`register_user`.`deleted` = 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Current Database: `sessiondb`
--

USE `sessiondb`;

--
-- Current Database: `sysadmin`
--

USE `sysadmin`;

--
-- Final view structure for view `v_unique_mobile`
--

/*!50001 DROP VIEW IF EXISTS `v_unique_mobile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_unique_mobile` AS select `register_user`.`user_id` AS `user_id`,`register_user`.`username` AS `username`,`register_user`.`password` AS `password`,`register_user`.`mobile` AS `mobile`,`register_user`.`deleted` AS `deleted` from `register_user` where ((`register_user`.`mobile` is not null) and (`register_user`.`mobile` <> '') and (`register_user`.`deleted` = 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Current Database: `tfs_name_db`
--

USE `tfs_name_db`;

--
-- Current Database: `togressa`
--

USE `togressa`;

--
-- Current Database: `topicdb`
--

USE `topicdb`;

--
-- Current Database: `appdb`
--

USE `appdb`;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-24 13:46:44
