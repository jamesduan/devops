-- MySQL dump 10.13  Distrib 5.6.16, for Linux (x86_64)
--
-- Host: localhost    Database: bocdb
-- ------------------------------------------------------
-- Server version	5.6.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `bocdb`
--

/*!40000 DROP DATABASE IF EXISTS `bocdb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `bocdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `bocdb`;

--
-- Table structure for table `admin_entry`
--

DROP TABLE IF EXISTS `admin_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_entry` (
  `entry_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned DEFAULT '0',
  `name` varchar(200) NOT NULL,
  `gbk_name` varchar(200) NOT NULL,
  `zh_hant_name` varchar(200) NOT NULL,
  `en_name` varchar(200) NOT NULL,
  `privilege` varchar(100) DEFAULT '',
  `reserve` varchar(100) DEFAULT '',
  `sort` int(5) NOT NULL,
  `doc_profix` varchar(50) DEFAULT '',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `blacklist_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `baduser_id` bigint(40) NOT NULL,
  `owner_id` bigint(40) NOT NULL,
  `time_created` bigint(20) NOT NULL,
  PRIMARY KEY (`blacklist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `boc_logs_type`
--

DROP TABLE IF EXISTS `boc_logs_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boc_logs_type` (
  `type_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `first_entry` varchar(50) DEFAULT NULL,
  `second_entry` varchar(50) DEFAULT NULL,
  `third_entry` varchar(50) DEFAULT NULL,
  `verb` varchar(50) DEFAULT NULL,
  `object` varchar(50) DEFAULT NULL,
  `entry_name` varchar(500) DEFAULT '',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `boc_manage_logs`
--

DROP TABLE IF EXISTS `boc_manage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boc_manage_logs` (
  `log_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(5) unsigned DEFAULT NULL,
  `user_id` bigint(40) unsigned DEFAULT NULL,
  `time_created` int(11) NOT NULL,
  `client_ip` varchar(50) DEFAULT NULL,
  `client_type` enum('web','mobile','pad') DEFAULT 'web',
  `detail` varchar(512) DEFAULT '',
  `app_id` varchar(50) DEFAULT NULL,
  `user_name` varchar(200) DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `fk_boc_logs` (`type_id`),
  CONSTRAINT `fk_boc_logs` FOREIGN KEY (`type_id`) REFERENCES `boc_logs_type` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `common_district`
--

DROP TABLE IF EXISTS `common_district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_district` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `level` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `usetype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `upid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `displayorder` smallint(6) NOT NULL DEFAULT '0',
  `geo_index_x` varchar(20) DEFAULT NULL,
  `geo_index_y` varchar(20) DEFAULT NULL,
  `location_remark` varchar(200) DEFAULT NULL,
  `is_exist_child` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45054 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `contact_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `information` varchar(1024) DEFAULT '',
  `binding_user_id` bigint(40) DEFAULT '0',
  `owner_id` bigint(40) NOT NULL,
  `time_created` bigint(20) NOT NULL,
  `source` enum('mobile','weibo','request','scan') DEFAULT 'mobile',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `contact_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `information` varchar(500) DEFAULT NULL,
  `binding_user` bigint(40) unsigned DEFAULT NULL,
  `owner_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`contact_id`),
  KEY `fk_contact_user` (`binding_user`),
  KEY `fk_contact_owner` (`owner_id`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`),
  CONSTRAINT `fk_contact_user` FOREIGN KEY (`binding_user`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts_group`
--

DROP TABLE IF EXISTS `contacts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts_group` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `owner_id` bigint(40) unsigned DEFAULT NULL,
  `issue_num` int(8) DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `name` (`name`),
  KEY `fk_contact_group_owner` (`owner_id`),
  CONSTRAINT `contacts_group_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `datalists`
--

DROP TABLE IF EXISTS `datalists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datalists` (
  `name` varchar(32) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `default_group_issuenum`
--

DROP TABLE IF EXISTS `default_group_issuenum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_group_issuenum` (
  `group_id` bigint(20) unsigned NOT NULL,
  `owner_id` bigint(40) unsigned NOT NULL,
  `issue_num` int(8) DEFAULT '0',
  PRIMARY KEY (`group_id`,`owner_id`),
  KEY `fk_group_issue` (`group_id`),
  KEY `fk_owner_issue` (`owner_id`),
  CONSTRAINT `fk_group_issue` FOREIGN KEY (`group_id`) REFERENCES `contacts_group` (`group_id`),
  CONSTRAINT `fk_owner_issue` FOREIGN KEY (`owner_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feedback_refresh`
--

DROP TABLE IF EXISTS `feedback_refresh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_refresh` (
  `refresh_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `time_started` int(11) DEFAULT '0',
  `time_ended` int(11) DEFAULT '0',
  `refresh_status` enum('refreshing','refreshed') DEFAULT 'refreshing',
  `latest_msg_id` varchar(50) DEFAULT '',
  `refresher_id` bigint(40) DEFAULT '0',
  PRIMARY KEY (`refresh_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feture`
--

DROP TABLE IF EXISTS `feture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feture` (
  `feture_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `feture_name` varchar(50) DEFAULT '',
  `zh_name` varchar(50) DEFAULT '',
  `feture_key` varchar(50) DEFAULT '',
  PRIMARY KEY (`feture_id`),
  UNIQUE KEY `feture_name` (`feture_name`),
  UNIQUE KEY `feture_key` (`feture_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feture_entry`
--

DROP TABLE IF EXISTS `feture_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feture_entry` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `feture_key` varchar(50) DEFAULT NULL,
  `entry_id` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_feture_entry_key` (`feture_key`),
  CONSTRAINT `fk_feture_entry_key` FOREIGN KEY (`feture_key`) REFERENCES `feture` (`feture_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feture_privilege`
--

DROP TABLE IF EXISTS `feture_privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feture_privilege` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `feture_key` varchar(50) DEFAULT NULL,
  `privilege_type` varchar(100) DEFAULT NULL,
  `privilege_action` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_feture_privilege_key` (`feture_key`),
  CONSTRAINT `fk_feture_privilege_key` FOREIGN KEY (`feture_key`) REFERENCES `feture` (`feture_key`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `filterbadwordaction`
--

DROP TABLE IF EXISTS `filterbadwordaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filterbadwordaction` (
  `filterbadwordaction_id` int(4) NOT NULL AUTO_INCREMENT,
  `filterbadwordaction_value` varchar(50) NOT NULL,
  `sub1` varchar(100) NOT NULL,
  PRIMARY KEY (`filterbadwordaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `filterbadwordrule`
--

DROP TABLE IF EXISTS `filterbadwordrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filterbadwordrule` (
  `filterbadwordrule_id` int(8) NOT NULL AUTO_INCREMENT,
  `badword` varchar(300) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `sub1` varchar(100) NOT NULL,
  `filterbadwordaction_id` int(4) NOT NULL,
  `site_id` bigint(20) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`filterbadwordrule_id`),
  KEY `kf_badword_filteracton` (`filterbadwordaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=294 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `group_contacts_mapping`
--

DROP TABLE IF EXISTS `group_contacts_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_contacts_mapping` (
  `contact_id` bigint(20) unsigned NOT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`contact_id`,`group_id`),
  KEY `fk_mapping_contact` (`contact_id`),
  KEY `fk_mapping_group` (`group_id`),
  CONSTRAINT `fk_mapping_contact` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`contact_id`),
  CONSTRAINT `fk_mapping_group` FOREIGN KEY (`group_id`) REFERENCES `contacts_group` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `individual`
--

DROP TABLE IF EXISTS `individual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `individual` (
  `indiv_id` bigint(40) NOT NULL,
  `real_name` varchar(20) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `birthdate_year` varchar(5) DEFAULT NULL,
  `birthdate_month` varchar(2) DEFAULT NULL,
  `birthdate_day` varchar(2) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_url` varchar(100) DEFAULT NULL,
  `qq` varchar(30) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `zodiac_sign` enum('aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces') DEFAULT NULL,
  `safety_info` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`indiv_id`),
  KEY `fk_indiv_party` (`indiv_id`),
  CONSTRAINT `fk_indiv_party` FOREIGN KEY (`indiv_id`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inform_item`
--

DROP TABLE IF EXISTS `inform_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inform_item` (
  `item_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `informer_id` bigint(40) unsigned NOT NULL,
  `target_id` int(10) unsigned NOT NULL,
  `target_object` bigint(40) unsigned NOT NULL,
  `description` varchar(2048) DEFAULT '',
  `is_exist_attachment` tinyint(1) DEFAULT '0',
  `status` varchar(200) NOT NULL DEFAULT 'IIS_UNDISTRIBUTED',
  `result_description` varchar(2048) NOT NULL DEFAULT '',
  `owner_id` bigint(40) DEFAULT '0',
  `creator_id` bigint(40) NOT NULL,
  `time_created` int(11) NOT NULL,
  `informer_name` varchar(500) DEFAULT '',
  `owner_name` varchar(500) DEFAULT '',
  `creator_name` varchar(500) DEFAULT '',
  PRIMARY KEY (`item_id`),
  KEY `fk_inform_item_target` (`target_id`),
  KEY `fk_inform_item_status` (`status`),
  CONSTRAINT `fk_inform_item_status` FOREIGN KEY (`status`) REFERENCES `inform_status` (`status`),
  CONSTRAINT `fk_inform_item_target` FOREIGN KEY (`target_id`) REFERENCES `inform_target` (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inform_language`
--

DROP TABLE IF EXISTS `inform_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inform_language` (
  `language` varchar(50) NOT NULL,
  PRIMARY KEY (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inform_log_mapping`
--

DROP TABLE IF EXISTS `inform_log_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inform_log_mapping` (
  `log_id` bigint(40) unsigned NOT NULL,
  `inform_item_id` bigint(40) unsigned NOT NULL,
  `description` varchar(2048) DEFAULT '',
  PRIMARY KEY (`log_id`,`inform_item_id`),
  KEY `fk_inform_log` (`inform_item_id`),
  CONSTRAINT `fk_inform_log` FOREIGN KEY (`inform_item_id`) REFERENCES `inform_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inform_process_policy`
--

DROP TABLE IF EXISTS `inform_process_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inform_process_policy` (
  `policy_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `target_id` int(10) unsigned DEFAULT NULL,
  `key` varchar(500) DEFAULT 'default',
  `value` varchar(500) DEFAULT '',
  PRIMARY KEY (`policy_id`),
  KEY `fk_inform_process_policy_target` (`target_id`),
  CONSTRAINT `fk_inform_process_policy_target` FOREIGN KEY (`target_id`) REFERENCES `inform_target` (`target_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inform_status`
--

DROP TABLE IF EXISTS `inform_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inform_status` (
  `status` varchar(200) NOT NULL,
  `status_description` varchar(200) DEFAULT '',
  PRIMARY KEY (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inform_target`
--

DROP TABLE IF EXISTS `inform_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inform_target` (
  `target_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `target_type` varchar(200) DEFAULT '',
  `target_subtype` varchar(500) DEFAULT '',
  `language` varchar(50) NOT NULL DEFAULT 'en',
  `target_type_key` varchar(50) NOT NULL DEFAULT 'topic',
  PRIMARY KEY (`target_id`),
  KEY `fk_inform_target_language` (`language`),
  CONSTRAINT `fk_inform_target_language` FOREIGN KEY (`language`) REFERENCES `inform_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mobile_contact_ext`
--

DROP TABLE IF EXISTS `mobile_contact_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_contact_ext` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `auto_add_mobile_contact` tinyint(1) DEFAULT '1',
  `add_me_friend_allowed` tinyint(1) DEFAULT '1',
  `recommend_friend_allowed` tinyint(1) DEFAULT '1',
  `time_updated` bigint(20) NOT NULL,
  `owner_id` bigint(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org`
--

DROP TABLE IF EXISTS `org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org` (
  `org_id` bigint(40) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `description` text,
  `type` enum('network','studio','company','federation','association','family') DEFAULT NULL,
  `org_logo` varchar(200) DEFAULT NULL,
  `url` varchar(80) DEFAULT NULL,
  `state` enum('normal','seal_up','dismiss') DEFAULT 'normal',
  `scope_id` bigint(40) DEFAULT NULL,
  `member_policy` enum('default','free','invitation','application') DEFAULT 'default',
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`org_id`),
  UNIQUE KEY `u_url` (`url`,`deleted`),
  KEY `fk_org_party` (`org_id`),
  CONSTRAINT `fk_org_party` FOREIGN KEY (`org_id`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `org_tag`
--

DROP TABLE IF EXISTS `org_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `org_tag` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` bigint(40) unsigned NOT NULL,
  `tag_name` varchar(50) NOT NULL,
  `party_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_org_tag` (`tag_id`),
  CONSTRAINT `fk_org_tag` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party` (
  `party_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `time_approved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `organization_id` bigint(40) DEFAULT NULL,
  `province` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `street_address` varchar(200) DEFAULT NULL,
  `approve_mobile` varchar(20) DEFAULT NULL,
  `approve_email` varchar(100) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`party_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_party_mapping`
--

DROP TABLE IF EXISTS `party_party_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_party_mapping` (
  `pp_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `from_party` bigint(40) NOT NULL,
  `to_party` bigint(40) NOT NULL,
  `type` enum('manage','member','subjection','linkman','follow') DEFAULT NULL,
  PRIMARY KEY (`pp_id`),
  UNIQUE KEY `uk_party_id_user_id_type` (`from_party`,`to_party`,`type`),
  KEY `fk_pp1_party` (`from_party`),
  KEY `fk_pp2_party` (`to_party`),
  CONSTRAINT `fk_pp1_party` FOREIGN KEY (`from_party`) REFERENCES `party` (`party_id`),
  CONSTRAINT `fk_pp2_party` FOREIGN KEY (`to_party`) REFERENCES `party` (`party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_recommendation`
--

DROP TABLE IF EXISTS `party_recommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_recommendation` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `party_id` bigint(40) NOT NULL,
  `status` enum('pending','passed') NOT NULL DEFAULT 'pending',
  `dest` enum('home','channel') NOT NULL,
  `sequence` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_party_id_dest` (`party_id`,`dest`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_user_mapping`
--

DROP TABLE IF EXISTS `party_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_user_mapping` (
  `pu_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `party_id` bigint(40) NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  `type` enum('official','employee','customer','admin','relate','incomer','follow','owner','inviting','applying') DEFAULT NULL,
  PRIMARY KEY (`pu_id`),
  UNIQUE KEY `uk_party_id_user_id_type` (`party_id`,`user_id`,`type`),
  KEY `fk_pu_party` (`party_id`),
  KEY `fk_pu_user` (`user_id`),
  CONSTRAINT `fk_pu_party` FOREIGN KEY (`party_id`) REFERENCES `party` (`party_id`),
  CONSTRAINT `fk_pu_user` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege` (
  `privilege_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `ptype_id` bigint(40) unsigned NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `propagate` tinyint(1) DEFAULT NULL,
  `quota` varchar(40) DEFAULT NULL,
  `cron_expression` varchar(50) DEFAULT NULL,
  `instances` varchar(250) NOT NULL DEFAULT '',
  `actions` varchar(250) NOT NULL DEFAULT '',
  `scope_id` bigint(40) DEFAULT NULL,
  `utype` enum('admin','normal','both') DEFAULT 'normal',
  `built_in` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`privilege_id`),
  UNIQUE KEY `uk_ptype_id_actions_instances` (`ptype_id`,`actions`,`instances`),
  KEY `fk_privilege_type` (`ptype_id`),
  CONSTRAINT `fk_privilege_type` FOREIGN KEY (`ptype_id`) REFERENCES `privilege_type` (`ptype_id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `privilege_type`
--

DROP TABLE IF EXISTS `privilege_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege_type` (
  `ptype_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `built_in` tinyint(1) DEFAULT '0',
  `for_platform` tinyint(1) DEFAULT '0',
  `for_site` tinyint(1) DEFAULT '0',
  `for_place` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`ptype_id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_api_groups`
--

DROP TABLE IF EXISTS `pvo_api_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_api_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `pvo_api_groups_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `pvo_api_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_apis`
--

DROP TABLE IF EXISTS `pvo_apis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_apis` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `group_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `pvo_apis_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `pvo_api_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_client_groups`
--

DROP TABLE IF EXISTS `pvo_client_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_client_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `pvo_client_groups_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `pvo_client_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_clients`
--

DROP TABLE IF EXISTS `pvo_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_clients` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(32) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `callback_url` varchar(160) DEFAULT NULL,
  `client_type` varchar(32) NOT NULL DEFAULT 'web',
  `name` varchar(128) NOT NULL,
  `group_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_id` (`client_id`),
  UNIQUE KEY `uk_name_type_url` (`name`,`client_type`,`callback_url`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `pvo_clients_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `pvo_client_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_quotas`
--

DROP TABLE IF EXISTS `pvo_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_quotas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `applicant` bigint(20) NOT NULL,
  `applicant_type` varchar(24) NOT NULL DEFAULT 'app',
  `target` bigint(20) NOT NULL,
  `target_type` varchar(24) NOT NULL DEFAULT 'api',
  `type` varchar(24) NOT NULL DEFAULT 'normal',
  `rule` varchar(128) NOT NULL DEFAULT 'allow',
  PRIMARY KEY (`id`),
  UNIQUE KEY `applicant` (`applicant`,`applicant_type`,`target`,`target_type`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_tokens`
--

DROP TABLE IF EXISTS `pvo_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_tokens` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(256) NOT NULL,
  `scope` varchar(128) DEFAULT NULL,
  `client_id` bigint(20) NOT NULL,
  `username` varchar(128) NOT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `pvo_tokens_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `pvo_clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pvo_users`
--

DROP TABLE IF EXISTS `pvo_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvo_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `register_user`
--

DROP TABLE IF EXISTS `register_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `register_user` (
  `user_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `nickname` varchar(200) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `last_action` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `is_validated` tinyint(1) DEFAULT NULL,
  `is_banned` tinyint(1) DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `identity_card_num` varchar(10) DEFAULT NULL,
  `mobile` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `signature` varchar(200) DEFAULT NULL,
  `big_avatar` varchar(100) DEFAULT NULL,
  `middle_avatar` varchar(100) DEFAULT NULL,
  `small_avatar` varchar(100) DEFAULT NULL,
  `tiny_avatar` varchar(100) DEFAULT NULL,
  `gender` enum('male','female','secret') DEFAULT 'secret',
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `snd_password` varchar(40) DEFAULT NULL,
  `allow_account_search` tinyint(1) DEFAULT '1',
  `allow_mobile_search` tinyint(1) DEFAULT '1',
  `add_friend_verification` tinyint(1) DEFAULT '1',
  `district_desc` varchar(500) DEFAULT '',
  `district_id` int(8) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `u_username_deleted` (`username`,`deleted`),
  UNIQUE KEY `u_email_deleted` (`email`,`deleted`),
  UNIQUE KEY `v_unique_mobile` (`mobile`),
  KEY `fk_user_district` (`district_id`),
  CONSTRAINT `fk_user_district` FOREIGN KEY (`district_id`) REFERENCES `common_district` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `remark`
--

DROP TABLE IF EXISTS `remark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remark` (
  `remark_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(40) NOT NULL,
  `remark_name` varchar(200) DEFAULT '',
  `owner_id` bigint(40) NOT NULL,
  PRIMARY KEY (`remark_id`),
  UNIQUE KEY `ukey_ou` (`owner_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `scope_id` bigint(40) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `built_in` tinyint(1) DEFAULT '0',
  `utype` enum('admin','normal') DEFAULT 'normal',
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uk_name_scope_id` (`name`,`scope_id`),
  KEY `fk_role_scope` (`scope_id`),
  CONSTRAINT `fk_role_scope` FOREIGN KEY (`scope_id`) REFERENCES `scope` (`scope_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_privilege_mapping`
--

DROP TABLE IF EXISTS `role_privilege_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_privilege_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(40) unsigned NOT NULL,
  `privilege_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`privilege_id`),
  KEY `fk_rp_1` (`role_id`),
  KEY `fk_rp_2` (`privilege_id`),
  CONSTRAINT `role_privilege_mapping_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE,
  CONSTRAINT `role_privilege_mapping_ibfk_2` FOREIGN KEY (`privilege_id`) REFERENCES `privilege` (`privilege_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_user_mapping`
--

DROP TABLE IF EXISTS `role_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user_mapping` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(40) unsigned NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`user_id`),
  KEY `fk_ru_1` (`role_id`),
  KEY `fk_ru_2` (`user_id`),
  CONSTRAINT `role_user_mapping_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_mapping_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `scope`
--

DROP TABLE IF EXISTS `scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scope` (
  `scope_id` bigint(40) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(40) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `is_classification` tinyint(1) DEFAULT '1',
  `is_system` tinyint(1) DEFAULT '0',
  `type` enum('site','place','platform') DEFAULT 'site',
  `deleted` tinyint(1) DEFAULT '0',
  `deleted_by` varchar(256) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`scope_id`),
  KEY `fk_org_scope` (`org_id`),
  CONSTRAINT `fk_org_scope` FOREIGN KEY (`org_id`) REFERENCES `org` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `suggest_dispose_desc`
--

DROP TABLE IF EXISTS `suggest_dispose_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suggest_dispose_desc` (
  `desc_id` int(5) NOT NULL AUTO_INCREMENT,
  `suggest_id` bigint(20) unsigned NOT NULL,
  `content` varchar(200) DEFAULT '',
  `action` enum('dispose','aside','remove') DEFAULT 'dispose',
  `user_id` bigint(40) NOT NULL,
  `time_created` int(11) NOT NULL,
  `user_name` varchar(200) DEFAULT '',
  PRIMARY KEY (`desc_id`),
  KEY `fk_suggest_dispose` (`suggest_id`),
  CONSTRAINT `fk_suggest_dispose` FOREIGN KEY (`suggest_id`) REFERENCES `user_feedback_suggest` (`suggest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_rule_doc`
--

DROP TABLE IF EXISTS `sys_rule_doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_rule_doc` (
  `doc_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `url` varchar(200) NOT NULL,
  `content` mediumtext,
  `status` enum('on','off','del') DEFAULT 'off',
  `time_created` int(11) NOT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `sort` int(5) DEFAULT '1',
  `content_draft` mediumtext,
  `entry_prefix` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_rule_doc_content`
--

DROP TABLE IF EXISTS `sys_rule_doc_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_rule_doc_content` (
  `doc_content_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) NOT NULL,
  `content` mediumtext,
  `content_status` enum('publish','draft','del') DEFAULT 'draft',
  `time_created` int(11) NOT NULL,
  `creator_id` bigint(40) DEFAULT '0',
  `time_modified` int(11) DEFAULT '0',
  `modifier_id` bigint(40) DEFAULT '0',
  `time_published` int(11) DEFAULT '0',
  `publisher_id` bigint(20) DEFAULT '0',
  `time_deleteed` int(11) DEFAULT '0',
  `deleter_id` bigint(40) DEFAULT '0',
  `entry_prefix` varchar(50) DEFAULT '',
  PRIMARY KEY (`doc_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_rule_doc_his`
--

DROP TABLE IF EXISTS `sys_rule_doc_his`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_rule_doc_his` (
  `his_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doc_id` bigint(20) unsigned NOT NULL,
  `content` text,
  `time_publish` int(11) DEFAULT NULL,
  `publisher_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`his_id`),
  KEY `fk_rule_doc` (`doc_id`,`time_publish`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_config` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(50) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `tag_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_user`
--

DROP TABLE IF EXISTS `third_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_user` (
  `third_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('qq','sina') DEFAULT NULL,
  `uid` varchar(100) DEFAULT NULL,
  `access_token` varchar(100) DEFAULT NULL,
  `nick_name` varchar(100) DEFAULT NULL,
  `profile_image_url` varchar(200) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`third_id`),
  UNIQUE KEY `type_uid` (`type`,`uid`),
  KEY `fk_third_user` (`user_id`),
  CONSTRAINT `fk_third_user` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_feedback_suggest`
--

DROP TABLE IF EXISTS `user_feedback_suggest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_feedback_suggest` (
  `suggest_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(2) DEFAULT '1',
  `content` text NOT NULL,
  `user_id` bigint(40) NOT NULL,
  `channel` enum('mobile','web','pad') DEFAULT 'mobile',
  `time_created` int(11) NOT NULL,
  `user_name` varchar(200) DEFAULT '',
  `status` enum('undisposed','processed','aside') DEFAULT 'undisposed',
  `is_delete` tinyint(1) DEFAULT '0',
  `msg_id` varchar(50) DEFAULT '',
  PRIMARY KEY (`suggest_id`),
  KEY `fk_suggest_type` (`type_id`),
  CONSTRAINT `fk_suggest_type` FOREIGN KEY (`type_id`) REFERENCES `user_feedback_type` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_feedback_type`
--

DROP TABLE IF EXISTS `user_feedback_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_feedback_type` (
  `type_id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT '',
  `description` varchar(200) DEFAULT '',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_preference`
--

DROP TABLE IF EXISTS `user_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preference` (
  `id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(40) unsigned NOT NULL,
  `key` varchar(200) NOT NULL,
  `value` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`key`),
  KEY `fk_user_preference` (`user_id`),
  CONSTRAINT `fk_user_preference` FOREIGN KEY (`user_id`) REFERENCES `register_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_session`
--

DROP TABLE IF EXISTS `user_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_session` (
  `session` varchar(255) NOT NULL,
  `ts` int(11) unsigned NOT NULL DEFAULT '0',
  `data` mediumblob,
  `access_token` char(32) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  `application_id` varchar(32) DEFAULT NULL,
  `client_ip` varchar(39) DEFAULT NULL,
  `device_id` varchar(32) DEFAULT NULL,
  `invisible` enum('Y','N') DEFAULT NULL,
  `time_created` int(11) DEFAULT NULL,
  `trust_level` enum('NONE','EXPERIENCE','PHONE','USER_PASSWORD','SOFTWARE_TOKEN','HARDWARE_TOKEN','TWO_FACTOR_SOFTWARE_TOKEN','TWO_FACTOR_HARDWARE_TOKEN') DEFAULT NULL,
  PRIMARY KEY (`session`),
  KEY `ts` (`ts`),
  KEY `idx_access_token` (`access_token`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_session_perm`
--

DROP TABLE IF EXISTS `user_session_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_session_perm` (
  `code` varchar(32) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `time_created` int(11) DEFAULT '0',
  PRIMARY KEY (`code`),
  UNIQUE KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_user_mapping`
--

DROP TABLE IF EXISTS `user_user_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_user_mapping` (
  `uu_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `from_user` bigint(40) unsigned NOT NULL,
  `to_user` bigint(40) unsigned NOT NULL,
  `type` enum('friend','follow') DEFAULT NULL,
  PRIMARY KEY (`uu_id`),
  UNIQUE KEY `from_user` (`from_user`,`to_user`,`type`),
  KEY `fk_from_user` (`from_user`),
  KEY `fk_to_user` (`to_user`),
  CONSTRAINT `fk_from_user` FOREIGN KEY (`from_user`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_to_user` FOREIGN KEY (`to_user`) REFERENCES `register_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `v_unique_mobile`
--

DROP TABLE IF EXISTS `v_unique_mobile`;
/*!50001 DROP VIEW IF EXISTS `v_unique_mobile`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_unique_mobile` (
  `user_id` tinyint NOT NULL,
  `username` tinyint NOT NULL,
  `password` tinyint NOT NULL,
  `mobile` tinyint NOT NULL,
  `deleted` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'bocdb'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_party_tags` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_party_tags`(p_party_id text) RETURNS text CHARSET utf8
begin
        declare done int default false;
        declare v_ret text;
        declare v_json varchar(200);
        declare v_tag_id bigint(40) unsigned;
        declare v_tag_name varchar(50);
        declare v_cur cursor for select tag_id, tag_name from org_tag where party_id = p_party_id;
        declare continue handler for not found set done = true;
        set v_ret = '';
        open v_cur;

        main_loop: loop
                fetch v_cur into v_tag_id, v_tag_name;
                if done then
                leave main_loop;
        end if;
                set v_json = concat ('{"tag_id":', v_tag_id, ', "tag_name":"', v_tag_name, '"}');
                set v_ret = concat (v_ret, v_json, ',');
        end loop;

        close v_cur;
        set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
        return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_party_users` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_party_users`(p_party_id bigint(40) unsigned) RETURNS text CHARSET utf8
begin
        declare done int default false;
        declare v_ret text;
        declare v_json varchar(200);
        declare v_username varchar(200);
        declare v_nickname varchar(200);
        declare v_type varchar(50);
        declare v_cur cursor for 
          select ru.username, ru.nickname, pum.type from party_user_mapping pum join register_user ru on
          pum.user_id = ru.user_id  where pum.party_id = p_party_id and pum.type in ('owner');
        declare continue handler for not found set done = true;
        set v_ret = '';
        open v_cur;

        main_loop: loop
                fetch v_cur into v_username, v_nickname, v_type;
                if done then
                leave main_loop;
        end if;
                set v_json = concat ('{"username":"', v_username, 
                        '", "nickname":"', v_nickname, '", "type":"', v_type, '"}');
                set v_ret = concat (v_ret, v_json, ',');
        end loop;

        close v_cur;
        set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
        return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_up_types` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_up_types`(p_user_id bigint(40) unsigned,
        p_party_id bigint(40) unsigned) RETURNS text CHARSET utf8
begin
        declare done int default false;
        declare v_ret text;
        declare v_json varchar(200);
        declare v_type varchar(50);
        declare v_cur cursor for select type from party_user_mapping where user_id = p_user_id and party_id = p_party_id;
        declare continue handler for not found set done = true;
        set v_ret = '';
        open v_cur;

        main_loop: loop
                fetch v_cur into v_type;
                if done then
                leave main_loop;
        end if;
                set v_json = concat ('{"type":"', v_type, '"}');
                set v_ret = concat (v_ret, v_json, ',');
        end loop;

        close v_cur;
        set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
        return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_user_third_users` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_user_third_users`(p_user_id bigint(40) unsigned) RETURNS text CHARSET latin1
begin
	declare done int default false;
	declare v_ret text;
	declare v_json text;
	declare v_type varchar(50);
	declare v_uid varchar(100);
	declare v_access_token varchar(100);
	declare v_nick_name varchar(100);
	declare v_profile_image_url varchar(200);
	declare v_gender varchar(50);
	declare v_cur cursor for 
	  select type, uid, access_token, nick_name, profile_image_url, gender from third_user where user_id = p_user_id;
	declare continue handler for not found set done = true;
	set v_ret = '';
	open v_cur;	
	
	main_loop: loop
		fetch v_cur into v_type, v_uid, v_access_token, v_nick_name, v_profile_image_url, v_gender;
		if done then
      		leave main_loop;
    	end if;
    		set v_json = concat ('{"type":"', v_type, 
    			'", "uid":"', v_uid, '", "access_token":"', v_access_token, 
    			'", "nick_name":"', v_nick_name, '", "profile_image_url":"', v_profile_image_url,
    			'", "gender":"', v_gender, '"}');
		set v_ret = concat (v_ret, v_json, ',');
	end loop;	
	
	close v_cur;
	set v_ret = concat ('[', substr(v_ret, 1, char_length(v_ret)-1), ']');
	return v_ret;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP FUNCTION IF EXISTS `get_entry_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_entry_list`() RETURNS text CHARSET utf8
    READS SQL DATA
BEGIN
        DECLARE _json TEXT;

        SET SESSION group_concat_max_len = 82768;

        SELECT CONCAT ("[", GROUP_CONCAT(
 
                
                CONCAT("{\"id\":", entry_id, ""),
                CONCAT(",\"parent_id\":", parent_id, ""),
                CONCAT(",\"name\":\"", name, "\""),
                CONCAT(",\"gbk_name\":\"", gbk_name, "\""),
                CONCAT(",\"zh_hant_name\":\"",zh_hant_name, "\""),
                CONCAT(",\"en_name\":\"",en_name, "\""),
                CONCAT(",\"privilege\":\"", IFNULL(privilege, ""), "\""),             
                CONCAT(",\"second\":", get_second_entry_list(entry_id)),
              
        "}"), "]")  INTO _json FROM admin_entry WHERE parent_id = 0 and deleted=0 order by sort;
 IF _json IS NULL THEN
                SET _json = '{}';
        END IF;

        RETURN _json;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_second_entry_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_second_entry_list`(entryId BIGINT(20) UNSIGNED) RETURNS text CHARSET utf8
    READS SQL DATA
BEGIN
        DECLARE _json TEXT;

        SELECT  CONCAT ("[", GROUP_CONCAT(
                CONCAT("{\"id\":", entry_id, ""),
                CONCAT(",\"parent_id\":", parent_id, ""),
                CONCAT(",\"name\":\"", name, "\""),
                CONCAT(",\"gbk_name\":\"", gbk_name, "\""),
                CONCAT(",\"zh_hant_name\":\"",zh_hant_name, "\""),
                CONCAT(",\"en_name\":\"",en_name, "\""),
                CONCAT(",\"privilege\":\"", IFNULL(privilege, ""), "\""),
                CONCAT(",\"third\":", get_third_entry_list(entry_id)),
        "}"), "]") INTO _json FROM admin_entry where deleted=0 and parent_id = entryId and entry_id not in(23,24,68,69) order by sort;

        IF _json IS NULL THEN
                SET _json = '[]';
        END IF;

        RETURN _json;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_third_entry_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_third_entry_list`(entryId BIGINT(20) UNSIGNED) RETURNS text CHARSET utf8
    READS SQL DATA
BEGIN
        DECLARE _json TEXT;

        SELECT  CONCAT ("[", GROUP_CONCAT(

                CONCAT("{\"id\":", entry_id, ""),
                CONCAT(",\"parent_id\":", parent_id, ""),
                CONCAT(",\"name\":\"", name, "\""),
                CONCAT(",\"gbk_name\":\"", gbk_name, "\""),
                CONCAT(",\"zh_hant_name\":\"",zh_hant_name, "\""),
                CONCAT(",\"en_name\":\"",en_name, "\""),
                CONCAT(",\"privilege\":\"", IFNULL(privilege, ""), "\""),
        "}"), "]") INTO _json FROM admin_entry where  parent_id = entryId and deleted=0 order by sort;

        IF _json IS NULL THEN
                SET _json = '[]';
        END IF;

        RETURN _json;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_entry` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_entry`(in feature_type varchar(200))
BEGIN
  declare var_isite int default -1;
  declare is_found  int default 0;
  
  declare entryId int;
  

     select entry_id into entryId from bocdb.feture_entry where feture_key = (select feture_key from  bocdb.feture where feture_name = feature_type);
 
       delete from bocdb.admin_entry where entry_id = entryId;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_entry` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_entry`(in feature_type varchar(200))
BEGIN
  declare var_isite int default -1;
  declare is_found  int default 0;
  
  declare entryId int;

  select entry_id into entryId from feture_entry where feture_key = (select feture_key from  feture where feture_name = feature_type);
 
      if entryId= 68  then
         insert into bocdb.`admin_entry`   (entry_id,parent_id,name,gbk_name,zh_hant_name,en_name,privilege,reserve) values(68,66,"plays","活动管理","活動管理","plays","","");
     elseif entryId =69 then
       insert into bocdb.`admin_entry` (entry_id,parent_id,name,gbk_name,zh_hant_name,en_name,privilege,reserve) values(69,66,"networks","圈子管理","圈子管理","networks","","");

      end if;
     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_feture_network` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_feture_network`()
BEGIN
 
 start transaction;
    
    insert into bocdb.`feture`(feture_id,feture_name,zh_name,feture_key) values(2,'network','圈子','feture_plugin_network') on duplicate key update feture_id=feture_id;
    insert into bocdb.`feture_entry`(id,feture_key,entry_id) values(2,'feture_plugin_network',69) on duplicate key update id=id;
    insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(5,'feture_plugin_network','CommunityAdmin','editNetwork') on duplicate key update id=id;
    insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(6,'feture_plugin_network','CommunityAdmin','recommendNetwork') on duplicate key update id=id;
    insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(7,'feture_plugin_network','CommunityAdmin','rankNetwork') on duplicate key update id=id;
    insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(8,'feture_plugin_network','CommunityAdmin','banNetwork') on duplicate key update id=id;
    insert into spacedb.s_datalists(name,value) values('feture_plugin_network','off') on duplicate key update name=name;


commit;
    
     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_feture_play` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_feture_play`()
BEGIN
 
 start transaction;
    insert into bocdb.`feture`(feture_id,feture_name,zh_name,feture_key) values(1,'play','活动','feture_plugin_play') on duplicate key update feture_id=feture_id;

    insert into bocdb.`feture_entry`(id,feture_key,entry_id) values(1,'feture_plugin_play',68)  on duplicate key update id=id;
    insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(1,'feture_plugin_play','CommunityAdmin','editPlay') on duplicate key update id=id;
    insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(2,'feture_plugin_play','CommunityAdmin','recommendPlay') on duplicate key update id=id;
    insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(3,'feture_plugin_play','CommunityAdmin','rankPlay') on duplicate key update id=id;
     insert into bocdb.`feture_privilege`(id,feture_key,privilege_type,privilege_action) values(4,'feture_plugin_play','CommunityAdmin','banPlay') on duplicate key update id=id;
    insert into spacedb.s_datalists(name,value) values('feture_plugin_play','off') on duplicate key update name=name;

commit;
    
     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_privilege` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_privilege`(ptid BIGINT(40) UNSIGNED, a VARCHAR(1024), n VARCHAR(200), u VARCHAR(10))
BEGIN
        DECLARE _pid BIGINT(40) UNSIGNED;
        DECLARE _n VARCHAR(200);
        DECLARE _d VARCHAR(500);
	DECLARE _u VARCHAR(10);

        SELECT privilege_id, name, description, utype INTO _pid, _n, _d, _u FROM privilege WHERE ptype_id = ptid AND actions = a AND built_in = 1;
        IF _pid IS NULL THEN
                INSERT INTO privilege (`ptype_id`,`name`,`description`,`actions`, `utype`, `built_in`) VALUES (ptid, n, n, a, u, '1');
	ELSE
		SET @s = NULL;
                IF _n != n THEN
                        IF @s IS NULL THEN
                                SET @s = CONCAT("name = '", n, "',description = '", n, "'");
                        ELSE
                                SET @s = CONCAT(@s, ", name = '", n, "',description = '", n, "'");
                        END IF;
                        
                END IF;
		
		IF _u != u THEN
			IF @s IS NULL THEN
				SET @s = CONCAT("utype = '",u,"'");
			ELSE
				SET @s = CONCAT(@s,", utype = '",u,"'");
			END IF;
		END IF;
		
                IF @s IS NOT NULL THEN
                        SET @s = CONCAT('UPDATE privilege SET ', @s, ' WHERE privilege_id = ', _pid);
                        PREPARE _stmt FROM @s;
                        EXECUTE _stmt;
                        DEALLOCATE PREPARE _stmt;
                END IF;
        END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_privilege_type` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_privilege_type`(n VARCHAR(128), d VARCHAR(256), fplatform TINYINT(1), fsite TINYINT(1), fplace TINYINT(1))
BEGIN
        DECLARE _ptid BIGINT(40) UNSIGNED;
        DECLARE _d VARCHAR(256);
        DECLARE _fplatform, _fsite, _fplace TINYINT(1);

        SELECT ptype_id, description, for_platform, for_site, for_place INTO _ptid, _d, _fplatform, _fsite, _fplace FROM privilege_type WHERE name = n AND built_in = 1;
        IF _ptid IS NULL THEN
                INSERT INTO privilege_type (`name`,`description`,`built_in`, `for_platform`, `for_site`, `for_place`) VALUES (n, d, '1', fplatform, fsite, fplace);
                SET @ptid = LAST_INSERT_ID();
        ELSE
                SET @s = NULL;
                IF _d != d THEN
                        IF @s IS NULL THEN
                                SET @s = CONCAT('description = "', d, '"');
                        ELSE
                                SET @s = CONCAT(@s, ', description = "', d, '"');
                        END IF;
                        
                END IF;
                IF _fplatform != fplatform THEN
                        IF @s IS NULL THEN
                                SET @s = CONCAT('for_platform = ', fplatform);
                        ELSE
                                SET @s = CONCAT(@s, ', for_platform = ', fplatform);
                        END IF;
                        
                END IF;
                IF _fsite != fsite THEN
                        IF @s IS NULL THEN
                                SET @s = CONCAT('for_site = ', fsite);
                        ELSE
                                SET @s = CONCAT(@s, ', for_site = ', fsite);
                        END IF;
                        
                END IF;
                IF _fplace != fplace THEN
                        IF @s IS NULL THEN
                                SET @s = CONCAT('for_place = ', fplace);
                        ELSE
                                SET @s = CONCAT(@s, ', for_place = ', fplace);
                        END IF;
                        
                END IF;

                IF @s IS NOT NULL THEN
                        SET @s = CONCAT('UPDATE privilege_type SET ', @s, ' WHERE ptype_id = ', _ptid);
                        PREPARE _stmt FROM @s;
                        EXECUTE _stmt;
                        DEALLOCATE PREPARE _stmt;
                END IF;

                SET @ptid = _ptid;
        END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_role` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_role`(
	scope_id BIGINT(40), 
	name VARCHAR(128), 
	description VARCHAR(256), 
	utype VARCHAR(10)
)
BEGIN
        DECLARE _rid BIGINT(40);
        DECLARE _d VARCHAR(256);
        DECLARE _bltin TINYINT(1);
        DECLARE _u VARCHAR(10);

        SELECT r.role_id, r.description, r.built_in, r.utype INTO _rid, _d, _bltin, _u 
        	FROM role r WHERE r.scope_id = scope_id AND r.name = name;
        IF _rid IS NULL THEN
                INSERT INTO role (`scope_id`,`name`,`description`,`built_in`, `utype`) VALUES (scope_id, name, description, 1, utype);
                SET @rid = LAST_INSERT_ID();
        ELSE
                UPDATE role r SET r.built_in = 1, r.description = description, r.utype = utype 
                	WHERE r.role_id = _rid;
                SET @rid = _rid;
        END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_role_privilege` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_role_privilege`(
	scope_id BIGINT(40), 
	role_id BIGINT(40), 
	ptype_name VARCHAR(128), 
	privilege_action VARCHAR(256)
)
BEGIN
        DECLARE _pid BIGINT(40) UNSIGNED; 
        DECLARE _mid BIGINT(40) UNSIGNED; 

        SELECT p.privilege_id INTO _pid 
        	FROM privilege p JOIN privilege_type pt ON p.ptype_id = pt.ptype_id 
        	WHERE pt.name = ptype_name AND p.actions = privilege_action;
        IF _pid IS NULL THEN
                SET @done = 1;
        ELSE
                SELECT id INTO _mid FROM role_privilege_mapping m WHERE m.role_id = role_id AND m.privilege_id = _pid;
                IF _mid IS NULL THEN
                        INSERT INTO role_privilege_mapping (`role_id`, `privilege_id`) VALUES (role_id, _pid);
                END IF;
        END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_scope_org` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_scope_org`(sid BIGINT(40) UNSIGNED)
BEGIN
        
        CALL m_builtin_role(sid, 'placeowner', 'place owner','normal');

        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyInfo');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyIdentity');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'memberPolicy');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'shut');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyPage');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'collectServiceCard');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'orderService');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'enterAdminPage');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'sendAnnMessage');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'sendMessage');

        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignOwner');
        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignAdmin');
        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignRole');
        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyRole');
        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyPermission');

        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'view');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'modifyInfo');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'remove');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'changePassword');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'kickOut');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'invite');

        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAd', 'slotAdmin');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAd', 'adAdmin');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');


        
        CALL m_builtin_role(sid, 'placeadmin', 'place administrator','normal');

        
        
        
        
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'modifyPage');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'collectServiceCard');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'orderService');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'enterAdminPage');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'sendAnnMessage');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'sendMessage');

        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

        
        
        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'assignRole');
        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyRole');
        CALL m_builtin_role_privilege(sid, @rid, 'Permissions', 'modifyPermission');

        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'view');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'modifyInfo');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'remove');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'changePassword');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'kickOut');
        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'invite');

        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAd', 'slotAdmin');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAd', 'adAdmin');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');


        
        CALL m_builtin_role(sid, 'placemember', 'place member','normal');

        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'collectServiceCard');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceAdmin', 'sendMessage');

        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

        CALL m_builtin_role_privilege(sid, @rid, 'Members', 'invite');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_builtin_scope_site` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_builtin_scope_site`(sid BIGINT(40) UNSIGNED)
BEGIN
        
        CALL m_builtin_role(sid, 'webadmin', 'web administrator', 'admin');

        CALL m_builtin_role_privilege(sid, @rid, 'SitePermissions', 'modifyRole');
        CALL m_builtin_role_privilege(sid, @rid, 'SitePermissions', 'modifyPermission');
        CALL m_builtin_role_privilege(sid, @rid, 'SitePermissions', 'assignRole');

        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'basicInfo');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'userRegistration');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'placeCreation');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'userSession');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'domainName');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'modifyDistrict');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'sendAnnMessage');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'messageChannel');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'messageFormat');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'webpageAccessSet');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'StatisticsCodeSet');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'closeSite');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'fileAttachment');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'imgWaterprint');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'attachType');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'userVerification');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'ugcReportReceipt');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'ugcReportPhrase');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteSettings', 'smsRateLimiting');

        CALL m_builtin_role_privilege(sid, @rid, 'NavAdmin', 'managePage');
        CALL m_builtin_role_privilege(sid, @rid, 'NavAdmin', 'setHeaderNav');
        CALL m_builtin_role_privilege(sid, @rid, 'NavAdmin', 'setTopNav');
        CALL m_builtin_role_privilege(sid, @rid, 'NavAdmin', 'setFooterNav');
        CALL m_builtin_role_privilege(sid, @rid, 'NavAdmin', 'setMyNav');
        CALL m_builtin_role_privilege(sid, @rid, 'NavAdmin', 'manageStyle');

        CALL m_builtin_role_privilege(sid, @rid, 'MobileNavAdmin', 'setBranding');
        CALL m_builtin_role_privilege(sid, @rid, 'MobileNavAdmin', 'setMainNav');
        CALL m_builtin_role_privilege(sid, @rid, 'MobileNavAdmin', 'setAppMenu');

        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'inviteTokenMgr');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'editNews');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'editHelp');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'editAbout');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'editLink');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'editAdmin');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'addAdmin');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'editAdminRole');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'setAdminNotfication');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'trafficStatistics');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'userBehaviorStatistics');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'auditAdminLog');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'setAdmc');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'setBe');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'publishHelp');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'message');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'reportReply');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'adviceReply');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'complaintReply');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'disputeReply');
	CALL m_builtin_role_privilege(sid, @rid, 'SiteAdmin', 'shareSettings');

        CALL m_builtin_role_privilege(sid, @rid, 'SiteTasks', 'updateWidget');

        CALL m_builtin_role_privilege(sid, @rid, 'SiteAd', 'slotAdmin');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAd', 'adAdmin');
        CALL m_builtin_role_privilege(sid, @rid, 'SiteAd', 'adGovern');

        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'edit');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'view');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'add');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'delete');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'ban');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'newsletter');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'verifyRealname');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'verifyOrg');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'statistics');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'profile');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'handleReport');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'handleComplaint');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'handleAdvice');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'handleDispute');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'rewardSocialCredit');
        CALL m_builtin_role_privilege(sid, @rid, 'UserAdmin', 'rewardBusinessCredit');

        CALL m_builtin_role_privilege(sid, @rid, 'PlaceGovern', 'view');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceGovern', 'verifyIdentity');
        CALL m_builtin_role_privilege(sid, @rid, 'PlaceGovern', 'ban');

        CALL m_builtin_role_privilege(sid, @rid, 'WidgetAdmin', 'manageCategory');
        CALL m_builtin_role_privilege(sid, @rid, 'WidgetAdmin', 'manageBuiltin');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceGovern', 'publishCatalog');
        CALL m_builtin_role_privilege(sid, @rid, 'ResourceGovern', 'publishResource');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');
        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'manageResource');

        CALL m_builtin_role_privilege(sid, @rid, 'UgcAdmin', 'moderate');
        CALL m_builtin_role_privilege(sid, @rid, 'UgcAdmin', 'censor');
        CALL m_builtin_role_privilege(sid, @rid, 'UgcAdmin', 'handleReport');
        CALL m_builtin_role_privilege(sid, @rid, 'UgcAdmin', 'manageTag');

        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'manageCreditRule');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'manageCreditLevel');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'editPolicy');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'editPlay');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'recommendPlay');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'rankPlay');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'banPlay');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'editNetwork');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'recommendNetwork');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'rankNetwork');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'banNetwork');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'markTalent');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'recommendTalent');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'rankTalent');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'manageTag');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'statistics');
        CALL m_builtin_role_privilege(sid, @rid, 'CommunityAdmin', 'publishPolicy');

        CALL m_builtin_role_privilege(sid, @rid, 'EcommerceAdmin', 'setScoreCredit');
        CALL m_builtin_role_privilege(sid, @rid, 'EcommerceAdmin', 'manageCreditLevel');
        CALL m_builtin_role_privilege(sid, @rid, 'EcommerceAdmin', 'auditCreditRecord');
        CALL m_builtin_role_privilege(sid, @rid, 'EcommerceAdmin', 'editPolicy');
        CALL m_builtin_role_privilege(sid, @rid, 'EcommerceAdmin', 'publishPolicy');

        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'activateModule');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'tunePerformance');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'tuneSeo');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'twistSearch');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'registAppSecet');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'publishCredential');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'sysVersion');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'monitorApp');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'monitorService');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'monitorLoad');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'dbadmin');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'sysTask');
        CALL m_builtin_role_privilege(sid, @rid, 'SysMaintain', 'auditSyslog');

        CALL m_builtin_role_privilege(sid, @rid, 'AppManage', 'downloadSmsCode');
        CALL m_builtin_role_privilege(sid, @rid, 'AppManage', 'thirdJoin');

        CALL m_builtin_role_privilege(sid, @rid, 'DevManage', 'api');

        
        CALL m_builtin_role(sid, 'gplaceowner', 'global place owner estate','normal');

        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');


        
        CALL m_builtin_role(sid, 'gplaceadmin', 'global place administrator estate','normal');

        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');


        
        CALL m_builtin_role(sid, 'user', 'normal user','normal');

        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');
        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'join');

        CALL m_builtin_role_privilege(sid, @rid, 'ResourceAdmin', 'developResource');


        
        CALL m_builtin_role(sid, 'guest', 'guest','normal');

        CALL m_builtin_role_privilege(sid, @rid, 'Places', 'create');

        
        CALL m_builtin_role(sid, 'noaccess', 'no access','normal');
        
        
        CALL m_builtin_role(-2, 'informDistribute', '', 'admin');
        CALL m_builtin_role_privilege(-2, @rid, 'ProcessAdmin', 'reportDistribute');
        
        CALL m_builtin_role(-2, 'informProcess', '', 'admin');
        CALL m_builtin_role_privilege(-2, @rid, 'ProcessAdmin', 'reportDispose');
        
        CALL m_builtin_role(-2, 'informFeedback', '', 'admin');
        CALL m_builtin_role_privilege(-2, @rid, 'ProcessAdmin', 'reportFeedback');
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_delete_privilege_type` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_delete_privilege_type`()
BEGIN
	CALL m_del_privilege_type("SitePages");
	CALL m_del_privilege_type("ServiceTypeAdmin");
	CALL m_del_privilege_type("ServiceProviderGovern");
	CALL m_del_privilege_type("ServiceProviders");
	CALL m_del_privilege_type("ServiceGovern");
	CALL m_del_privilege_type("ServiceAdmin");
	CALL m_del_privilege_type("ServiceOrderAdmin");
	CALL m_del_privilege_type("Services");
	CALL m_del_privilege_type("ResourceCategoryAdmin");

	CALL m_del_privilege("SiteSettings", "serviceCard");
	CALL m_del_privilege("SiteSettings", "StaticticsCodeSet");	
	CALL m_del_privilege("SiteAdmin", "recommendMgr");	
	CALL m_del_privilege("UserAdmin", "view");	
	CALL m_del_privilege("Users", "register");	
	CALL m_del_privilege("ResourceAdmin", "submitResource");	
	CALL m_del_privilege("ResourceAdmin", "modifyCatalog");	
	CALL m_del_privilege("ResourceAdmin", "modifyCatalogItem");	
	CALL m_del_privilege("ResourceAdmin", "removeCatalogItem");	
	CALL m_del_privilege("ResourceAdmin", "removeResource");	
	CALL m_del_privilege("ResourceAdmin", "exportResource");	
	CALL m_del_privilege("ResourceAdmin", "importResource");	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_del_privilege` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_del_privilege`(n VARCHAR(128), a VARCHAR(1024))
BEGIN
        DECLARE _pid BIGINT(40) UNSIGNED;
	DECLARE _ptid BIGINT(40) UNSIGNED;
	
	SELECT ptype_id INTO _ptid FROM privilege_type WHERE name = n AND built_in = 1;
	IF _ptid IS NOT NULL THEN
        	SELECT privilege_id INTO _pid FROM privilege WHERE ptype_id = _ptid AND actions = a AND built_in = 1;
		IF _pid IS NOT NULL THEN
			DELETE FROM role_privilege_mapping WHERE privilege_id = _pid;
			DELETE FROM privilege WHERE privilege_id = _pid;
		END IF;
			
	END IF;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_del_privilege_type` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_del_privilege_type`(n VARCHAR(128))
BEGIN
        DECLARE _pid BIGINT(40) UNSIGNED;
	DECLARE _ptid BIGINT(40) UNSIGNED;
	DECLARE privi_cur CURSOR FOR SELECT privilege_id FROM privilege WHERE ptype_id = _ptid AND built_in = 1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @del_done = 1;
	SET @del_done = 0;

	SELECT ptype_id INTO _ptid FROM privilege_type WHERE name = n AND built_in = 1;
	IF _ptid IS NOT NULL THEN
		IF NOT EXISTS (SELECT 1 FROM privilege WHERE ptype_id = _ptid AND built_in = 0) THEN
			OPEN privi_cur;
			REPEAT
				FETCH privi_cur into _pid;
				IF NOT @del_done THEN
					IF _pid IS NOT NULL THEN
						DELETE FROM role_privilege_mapping WHERE privilege_id = _pid;
						DELETE FROM privilege WHERE privilege_id = _pid;
					END IF;
				END IF;
			UNTIL @del_done END REPEAT;
			CLOSE privi_cur;
			DELETE FROM privilege_type WHERE ptype_id = _ptid;
		END IF;
	END IF;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_module_feture_list` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_module_feture_list`()
BEGIN
        DECLARE _ptype varchar(100);
        DECLARE _paction varchar(100);
        DECLARE privilege_cur CURSOR for SELECT a.privilege_type,a.privilege_action FROM bocdb.feture_privilege AS a INNER JOIN spacedb.s_datalists AS b ON a.feture_key=b.name WHERE b.name LIKE 'feture_plugin%' AND b.value = 'off';
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET @up_done=1;
        SET @up_done = 0;

        OPEN privilege_cur;
        REPEAT
                FETCH privilege_cur INTO _ptype, _paction;
                IF NOT @up_done THEN
                        CALL m_del_privilege(_ptype,_paction);
                END IF;
        UNTIL @up_done END REPEAT;
        CLOSE privilege_cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_prepare_user_role` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_prepare_user_role`()
BEGIN
	
	PREPARE stmt_allur FROM "SELECT u.user_id, u.username, o.org_id AS org_id, o.name AS org_name, r.name AS role_name FROM role_user_mapping AS ru JOIN register_user AS u ON ru.user_id = u.user_id JOIN role AS r ON ru.role_id = r.role_id JOIN scope AS s ON r.scope_id = s.scope_id JOIN org AS o ON s.org_id = o.org_id";
	PREPARE stmt_ur FROM "SELECT u.user_id, u.username, o.org_id AS org_id, o.name AS org_name, r.name AS role_name FROM role_user_mapping AS ru JOIN register_user AS u ON ru.user_id = u.user_id JOIN role AS r ON ru.role_id = r.role_id JOIN scope AS s ON r.scope_id = s.scope_id JOIN org AS o ON s.org_id = o.org_id WHERE u.user_id = ?";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_privilege_built_in` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_privilege_built_in`()
BEGIN
	UPDATE privilege SET built_in = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_privilege_no_scope_id_foreign_key` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_privilege_no_scope_id_foreign_key`()
BEGIN
	ALTER TABLE privilege DROP FOREIGN KEY `fk_privilege_scope`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_privilege_scope_id` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_privilege_scope_id`()
BEGIN
	UPDATE privilege SET scope_id = NULL WHERE scope_id != NULL;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_privilege_type_for` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_privilege_type_for`()
BEGIN
	ALTER TABLE privilege_type DROP COLUMN `pt_scope`;
	ALTER TABLE privilege_type ADD COLUMN `for_platform` TINYINT(1) DEFAULT '0';
	ALTER TABLE privilege_type ADD COLUMN `for_site` TINYINT(1) DEFAULT '0';
	ALTER TABLE privilege_type ADD COLUMN `for_place` TINYINT(1) DEFAULT '0';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_scope_default_type` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_scope_default_type`()
BEGIN
	UPDATE scope SET `type`='place' WHERE `type`='site' AND is_system=0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_scope_no_classification` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_scope_no_classification`()
BEGIN
	UPDATE scope SET is_classification=0 WHERE is_classification=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_privilege_type` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_privilege_type`()
BEGIN
    CALL m_builtin_privilege_type('SitePermissions','site permissions',0,1,0);
    CALL m_builtin_privilege(@ptid, 'modifyRole', 'modify role', 'admin');
    CALL m_builtin_privilege(@ptid, 'modifyPermission', 'modify permission', 'admin');
    CALL m_builtin_privilege(@ptid, 'assignRole', 'assign role', 'admin');

    CALL m_builtin_privilege_type('SiteSettings','site settings',0,1,0);
    CALL m_builtin_privilege(@ptid, 'basicInfo', 'set basic info', 'admin');
    CALL m_builtin_privilege(@ptid, 'userRegistration', 'set user registration policy', 'admin');
    CALL m_builtin_privilege(@ptid, 'placeCreation', 'set place creation policy', 'admin');
    CALL m_builtin_privilege(@ptid, 'userSession', 'set user session policy', 'admin');
    CALL m_builtin_privilege(@ptid, 'domainName', 'set domain name policy', 'admin');
    CALL m_builtin_privilege(@ptid, 'modifyDistrict', 'modify district', 'admin');
    CALL m_builtin_privilege(@ptid, 'sendAnnMessage', 'admin send ann message', 'admin');
    CALL m_builtin_privilege(@ptid, 'messageChannel', 'message channel', 'admin');
    CALL m_builtin_privilege(@ptid, 'messageFormat', 'message format', 'admin');
    CALL m_builtin_privilege(@ptid, 'webpageAccessSet', 'webpage access setting', 'admin');
    CALL m_builtin_privilege(@ptid, 'StatisticsCodeSet', 'statistics code', 'admin');
    CALL m_builtin_privilege(@ptid, 'closeSite', 'close site', 'admin');
    CALL m_builtin_privilege(@ptid, 'fileAttachment', 'file attachment', 'admin');
    CALL m_builtin_privilege(@ptid, 'imgWaterprint', 'image water print', 'admin');
    CALL m_builtin_privilege(@ptid, 'attachType', 'attach type', 'admin');
    CALL m_builtin_privilege(@ptid, 'userVerification', 'user verification', 'admin');
    CALL m_builtin_privilege(@ptid, 'ugcReportReceipt', 'ugc report receipt', 'admin');
    CALL m_builtin_privilege(@ptid, 'ugcReportPhrase', 'ugc report phrase', 'admin');
    CALL m_builtin_privilege(@ptid, 'smsRateLimiting', 'send sms rate limit', 'admin');
	CALL m_builtin_privilege(@ptid, 'reportPhrase', '举报理由设置', 'admin');

	CALL m_builtin_privilege_type('NavAdmin','nav admin',0,1,0);
	CALL m_builtin_privilege(@ptid,'managePage','manage page','admin');
	CALL m_builtin_privilege(@ptid,'setHeaderNav','set header nav','admin');
	CALL m_builtin_privilege(@ptid,'setTopNav','set top nav','admin');
	CALL m_builtin_privilege(@ptid,'setFooterNav','set footer nav','admin');
	CALL m_builtin_privilege(@ptid,'setMyNav','set my nav','admin');
	CALL m_builtin_privilege(@ptid,'manageStyle','manage style','admin');

	CALL m_builtin_privilege_type('MobileNavAdmin','mobile nav admin',0,1,0);
	CALL m_builtin_privilege(@ptid,'setBranding','set branding','admin');
	CALL m_builtin_privilege(@ptid,'setMainNav','set main nav','admin');
	CALL m_builtin_privilege(@ptid,'setAppMenu','set app menu','admin');

    CALL m_builtin_privilege_type('SiteAdmin','site admin',0,1,0);
    CALL m_builtin_privilege(@ptid, 'inviteTokenMgr', 'admin invite token','admin');
    CALL m_builtin_privilege(@ptid, 'editNews', 'edit news','admin');
    CALL m_builtin_privilege(@ptid, 'editHelp', 'edit help','admin');
    CALL m_builtin_privilege(@ptid, 'editAbout', 'edit about','admin');
    CALL m_builtin_privilege(@ptid, 'editLink', 'edit link','admin');
    CALL m_builtin_privilege(@ptid, 'editAdmin', 'edit admin','admin');
    CALL m_builtin_privilege(@ptid, 'addAdmin', 'add admin','admin');
    CALL m_builtin_privilege(@ptid, 'editAdminRole', 'edit admin role','admin');
    CALL m_builtin_privilege(@ptid, 'setAdminNotfication', 'set admin not fication','admin');
    CALL m_builtin_privilege(@ptid, 'trafficStatistics', 'traffic statistics','admin');
    CALL m_builtin_privilege(@ptid, 'userBehaviorStatistics', 'user behavior statistics','admin');
    CALL m_builtin_privilege(@ptid, 'auditAdminLog', 'audit admin log','admin');
    CALL m_builtin_privilege(@ptid, 'setAdmc', 'set admc','admin');
    CALL m_builtin_privilege(@ptid, 'setBe', 'set be','admin');
    CALL m_builtin_privilege(@ptid, 'publishHelp', 'publish help','admin');
    CALL m_builtin_privilege(@ptid, 'message', 'message','admin');
    CALL m_builtin_privilege(@ptid, 'reportReply', 'report reply','admin');
    CALL m_builtin_privilege(@ptid, 'adviceReply', 'advice reply','admin');
    CALL m_builtin_privilege(@ptid, 'complaintReply', 'complaint reply','admin');
    CALL m_builtin_privilege(@ptid, 'disputeReply', 'dispute reply','admin');
	CALL m_builtin_privilege(@ptid, 'shareSettings', 'share settings','admin');

	CALL m_builtin_privilege_type('SiteTasks','site tasks',0,1,0);
	CALL m_builtin_privilege(@ptid,'updateWidget','update widget','admin');

    CALL m_builtin_privilege_type('SiteAd','ad admin',0,1,0);
    CALL m_builtin_privilege(@ptid, 'slotAdmin','slot and channel add','admin');
    CALL m_builtin_privilege(@ptid, 'adAdmin','site show or not','admin');
    CALL m_builtin_privilege(@ptid, 'adGovern','ad govern or not','admin');

    CALL m_builtin_privilege_type('UserAdmin','user administration',0,1,0);
    CALL m_builtin_privilege(@ptid, 'edit', 'edit user','admin');
    CALL m_builtin_privilege(@ptid, 'view', 'user view','admin');
    CALL m_builtin_privilege(@ptid, 'add', 'add user','admin');
    CALL m_builtin_privilege(@ptid, 'delete', 'delete user','admin');
    CALL m_builtin_privilege(@ptid, 'ban', 'ban/unban user','admin');
    CALL m_builtin_privilege(@ptid, 'newsletter', 'newsletter to user','admin');
    CALL m_builtin_privilege(@ptid, 'verifyRealname', 'verify realname','admin');
    CALL m_builtin_privilege(@ptid, 'verifyOrg', 'verify org','admin');
    CALL m_builtin_privilege(@ptid, 'statistics', 'statistics user','admin');
    CALL m_builtin_privilege(@ptid, 'profile', 'profile','admin');
    CALL m_builtin_privilege(@ptid, 'handleReport', 'handle report','admin');
    CALL m_builtin_privilege(@ptid, 'handleComplaint', 'handle complaint','admin');
    CALL m_builtin_privilege(@ptid, 'handleAdvice', 'handle advice','admin');
    CALL m_builtin_privilege(@ptid, 'handleDispute', 'handle dispute','admin');
    CALL m_builtin_privilege(@ptid, 'rewardSocialCredit', 'reward social credit','admin');
    CALL m_builtin_privilege(@ptid, 'rewardBusinessCredit', 'reward business credit','admin');
    CALL m_builtin_privilege(@ptid, 'reportRole', '举报角色的设定','admin');

    CALL m_builtin_privilege_type('Users','user',0,1,0);
    CALL m_builtin_privilege(@ptid, 'inviteViaEmail', 'invite person by email','normal');
    CALL m_builtin_privilege(@ptid, 'inviteViaSms', 'invite person by sms','normal');

    CALL m_builtin_privilege_type('PlaceGovern','place governance',0,1,0);
    CALL m_builtin_privilege(@ptid, 'view', 'view places','admin');
    CALL m_builtin_privilege(@ptid, 'verifyIdentity', 'verify place identity','admin');
    CALL m_builtin_privilege(@ptid, 'ban', 'ban/unban place','admin');

    CALL m_builtin_privilege_type('PlaceAdmin','place admin',0,0,1);
    CALL m_builtin_privilege(@ptid, 'modifyInfo', 'modify place info','normal');
    CALL m_builtin_privilege(@ptid, 'modifyIdentity', 'modify place identity','normal');
    CALL m_builtin_privilege(@ptid, 'memberPolicy', 'set place member policy','normal');
    CALL m_builtin_privilege(@ptid, 'shut', 'shut place','normal');
    CALL m_builtin_privilege(@ptid, 'modifyPage', 'modify place presentation','normal');
    CALL m_builtin_privilege(@ptid, 'collectServiceCard', 'collect service card','normal');
    CALL m_builtin_privilege(@ptid, 'orderService', 'order service','normal');
    CALL m_builtin_privilege(@ptid, 'enterAdminPage', 'enter place admin page','normal');
    CALL m_builtin_privilege(@ptid, 'sendAnnMessage', 'palce send ann message','normal');
    CALL m_builtin_privilege(@ptid, 'sendMessage', 'place send message','normal');

    CALL m_builtin_privilege_type('Places','place',0,1,1);
    CALL m_builtin_privilege(@ptid, 'create', 'create (sub) place','normal');
    CALL m_builtin_privilege(@ptid, 'join', 'join (sub) place','normal');

    CALL m_builtin_privilege_type('Permissions','permissions',0,0,1);
    CALL m_builtin_privilege(@ptid, 'assignOwner', 'assign owner','normal');
    CALL m_builtin_privilege(@ptid, 'assignAdmin', 'assign admin','normal');
    CALL m_builtin_privilege(@ptid, 'assignRole', 'assign role','normal');
    CALL m_builtin_privilege(@ptid, 'modifyRole', 'modify role','normal');
    CALL m_builtin_privilege(@ptid, 'modifyPermission', 'modify permission','normal');

    CALL m_builtin_privilege_type('Members','place members',0,0,1);
    CALL m_builtin_privilege(@ptid, 'view', 'view members','normal');
    CALL m_builtin_privilege(@ptid, 'create', 'create employee','normal');
    CALL m_builtin_privilege(@ptid, 'modifyInfo', 'modify employee info','normal');
    CALL m_builtin_privilege(@ptid, 'remove', 'remove member','normal');
    CALL m_builtin_privilege(@ptid, 'changePassword', 'change employee password','normal');
    CALL m_builtin_privilege(@ptid, 'kickOut', 'kick out incomer','normal');
    CALL m_builtin_privilege(@ptid, 'invite', 'invite','normal');

    CALL m_builtin_privilege_type('PlaceAd','ad place admin',0,0,1);
    CALL m_builtin_privilege(@ptid, 'slotAdmin','slot place admin','normal');
    CALL m_builtin_privilege(@ptid, 'adAdmin','place show or not','normal');

    CALL m_builtin_privilege_type('WidgetAdmin','widget admin',0,1,0);
    CALL m_builtin_privilege(@ptid,'manageCategory','manage category','admin');
    CALL m_builtin_privilege(@ptid,'manageBuiltin','manage builtin','admin');

    CALL m_builtin_privilege_type('ResourceGovern','resource governance',0,1,0);
    CALL m_builtin_privilege(@ptid, 'publishCatalog', 'publish resource catalog','admin');
    CALL m_builtin_privilege(@ptid, 'publishResource', 'publish resource','admin');

    CALL m_builtin_privilege_type('ResourceAdmin','resource admin',0,1,1);
    CALL m_builtin_privilege(@ptid, 'developResource', 'develop resource','both');
    CALL m_builtin_privilege(@ptid, 'manageResource', 'manage resource','both');

	CALL m_builtin_privilege_type('UgcAdmin','ugc admin',0,1,0);
	CALL m_builtin_privilege(@ptid,'moderate','moderate','admin');
	CALL m_builtin_privilege(@ptid,'censor','censor','admin');
	CALL m_builtin_privilege(@ptid,'handleReport','handle report','admin');
	CALL m_builtin_privilege(@ptid,'manageTag','manage tag','admin');

	CALL m_builtin_privilege_type('CommunityAdmin','community admin',0,1,0);
	CALL m_builtin_privilege(@ptid,'manageCreditRule','manage credit rule','admin');
	CALL m_builtin_privilege(@ptid,'manageCreditLevel','manage credit level','admin');
	CALL m_builtin_privilege(@ptid,'editPolicy','edit policy','admin');
	CALL m_builtin_privilege(@ptid,'editPlay','edit play','admin');
	CALL m_builtin_privilege(@ptid,'recommendPlay','recommend play','admin');
	CALL m_builtin_privilege(@ptid,'rankPlay','rank play','admin');
	CALL m_builtin_privilege(@ptid,'banPlay','ban play','admin');
	CALL m_builtin_privilege(@ptid,'editNetwork','edit network','admin');
	CALL m_builtin_privilege(@ptid,'recommendNetwork','recommend network','admin');
	CALL m_builtin_privilege(@ptid,'rankNetwork','rank network','admin');
	CALL m_builtin_privilege(@ptid,'banNetwork','ban network','admin');
	CALL m_builtin_privilege(@ptid,'markTalent','mark talent','admin');
	CALL m_builtin_privilege(@ptid,'recommendTalent','recommend talent','admin');
	CALL m_builtin_privilege(@ptid,'rankTalent','rank talent','admin');
	CALL m_builtin_privilege(@ptid,'manageTag','manage tag','admin');
	CALL m_builtin_privilege(@ptid,'statistics','statistics','admin');
	CALL m_builtin_privilege(@ptid,'publishPolicy','publish policy','admin');
    
    CALL m_builtin_privilege_type('EcommerceAdmin','ecommerce admin',0,1,0);
    CALL m_builtin_privilege(@ptid, 'setScoreCredit', 'set score credit','admin');
    CALL m_builtin_privilege(@ptid, 'manageCreditLevel', 'manage credit level','admin');
    CALL m_builtin_privilege(@ptid, 'auditCreditRecord', 'audit credit record','admin');
    CALL m_builtin_privilege(@ptid, 'editPolicy', 'ecommerce edit policy','admin');
    CALL m_builtin_privilege(@ptid, 'publishPolicy', 'publish policy','admin');

    CALL m_builtin_privilege_type('SysMaintain','system maintain',0,1,0);
	CALL m_builtin_privilege(@ptid,'activateModule','activate module','admin');
	CALL m_builtin_privilege(@ptid,'tunePerformance','tunePerformance','admin');
	CALL m_builtin_privilege(@ptid,'tuneSeo','tune seo','admin');
	CALL m_builtin_privilege(@ptid,'twistSearch','twist search','admin');
	CALL m_builtin_privilege(@ptid,'registAppSecet','regist app secet','admin');
	CALL m_builtin_privilege(@ptid,'publishCredential','publish credential','admin');
	CALL m_builtin_privilege(@ptid,'sysVersion','system version','admin');
	CALL m_builtin_privilege(@ptid,'monitorApp','monitor app','admin');
	CALL m_builtin_privilege(@ptid,'monitorService','monitor service','admin');
	CALL m_builtin_privilege(@ptid,'monitorLoad','monitor load','admin');
	CALL m_builtin_privilege(@ptid,'dbadmin','db admin','admin');
	CALL m_builtin_privilege(@ptid,'sysTask','system task','admin');
	CALL m_builtin_privilege(@ptid,'auditSyslog','audit system log','admin');

    CALL m_builtin_privilege_type('AppManage','app manage',0,1,0);
	CALL m_builtin_privilege(@ptid,'downloadSmsCode','download sms code','admin');
	CALL m_builtin_privilege(@ptid,'thirdJoin','app third join manage','admin');

    CALL m_builtin_privilege_type('DevManage','dev manage',0,1,0);
	CALL m_builtin_privilege(@ptid,'api','api','admin');
	
	CALL m_builtin_privilege_type('ProcessAdmin','流程配置',0,1,0);
	CALL m_builtin_privilege(@ptid,'reportDistribute','举报单派发','admin');
	CALL m_builtin_privilege(@ptid,'reportDispose','举报单处理','admin');
	CALL m_builtin_privilege(@ptid,'reportFeedback','举报单回馈','admin');

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_role_privilege` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_role_privilege`(n VARCHAR(128), tn VARCHAR(128), pa VARCHAR(256))
BEGIN
	DECLARE _pid BIGINT(40) UNSIGNED;
	DECLARE _rid BIGINT(40) UNSIGNED;
	DECLARE role_cur CURSOR FOR SELECT role_id FROM role WHERE name = n AND built_in = 1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @up_done = 1;
	SET @up_done = 0;

	SELECT p.privilege_id INTO _pid FROM privilege p JOIN privilege_type pt ON p.ptype_id = pt.ptype_id WHERE pt.name = tn AND p.actions = pa;
	IF _pid IS NULL THEN
		SET @done = 1;
	ELSE
		OPEN role_cur;
		REPEAT
			FETCH role_cur into _rid;
			IF NOT @up_done THEN
				DELETE FROM role_privilege_mapping WHERE role_id = _rid AND privilege_id = _pid;
			END IF;
		UNTIL @up_done END REPEAT;
		CLOSE role_cur;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_role_privilege_list` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_role_privilege_list`()
BEGIN
	CALL m_update_role_privilege("webadmin", "Users", "inviteViaEmail");	
	CALL m_update_role_privilege("webadmin", "Users", "inviteViaSms");
	CALL m_update_role_privilege("webadmin", "Members", "view");	
	CALL m_update_role_privilege("webadmin", "Members", "create");	
	CALL m_update_role_privilege("webadmin", "Members", "modifyInfo");	
	CALL m_update_role_privilege("webadmin", "Members", "remove");	
	CALL m_update_role_privilege("webadmin", "Members", "changePassword");	
	CALL m_update_role_privilege("webadmin", "Members", "kickOut");	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_scope` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_scope`()
BEGIN
        DECLARE sid, oid, osid BIGINT(40) UNSIGNED;
        DECLARE issys TINYINT(1);
        DECLARE org_name VARCHAR(80);
        DECLARE org_scope_cur CURSOR FOR SELECT s.scope_id, o.org_id, s.is_system, o.name, o.scope_id FROM scope AS s RIGHT JOIN org AS o ON o.org_id = s.org_id WHERE s.is_classification IS NULL OR s.is_classification=0;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET @done = 1;

        

        SET @done = 0;

        OPEN org_scope_cur;

        REPEAT
                FETCH org_scope_cur INTO sid, oid, issys, org_name, osid;
                IF NOT @done THEN
                        
                        IF sid IS NULL THEN
                                INSERT INTO scope (`org_id`,`name`,`is_classification`,`is_system`,`type`)
                                        VALUES (oid, org_name, 0, 0, 'place');
                                SET sid = LAST_INSERT_ID();
                                SET issys = 0;
                        END IF;

                        
                        IF osid IS NULL THEN
                                UPDATE org SET scope_id = sid WHERE org_id = oid;
                        END IF;

                        IF issys = 1 THEN
                                
                                CALL m_builtin_scope_site(sid);
                        ELSE
                                
                                CALL m_builtin_scope_org(sid);
                        END IF;
                END IF;
        UNTIL @done END REPEAT;

        CLOSE org_scope_cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_update_user_role` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_update_user_role`()
BEGIN
	DECLARE u BIGINT(40) UNSIGNED;
	DECLARE ia TINYINT(1);
	DECLARE user_cur CURSOR FOR SELECT user_id, is_admin FROM register_user;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @done = 1;

	SET @done = 0;

	SELECT org_id, scope_id INTO @wooid, @wosid FROM scope WHERE is_classification = 0 AND is_system = 1 AND `type` = 'site';
	IF @wooid IS NULL THEN
		SELECT warning_scope_classification_or_type_not_fixed FROM scope;
	END IF;

	OPEN user_cur;

	REPEAT
		FETCH user_cur INTO u, ia;
		IF NOT @done THEN
			CALL m_user_role(u, ia);
		END IF;
	UNTIL @done END REPEAT;

	CLOSE user_cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_user_default_role` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_user_default_role`(o BIGINT(40) UNSIGNED, s BIGINT(40) UNSIGNED, u BIGINT(40) UNSIGNED, rn VARCHAR(256))
BEGIN
	DECLARE rid BIGINT(40) UNSIGNED;
	DECLARE c INT;

	SELECT role_id INTO rid FROM role WHERE scope_id = s AND name = rn AND built_in = 1;
	IF rid IS NULL THEN
		SELECT warning_scope_not_fixed FROM role;
	END IF;

	SELECT COUNT(*) INTO c FROM role_user_mapping WHERE role_id = rid AND user_id = u;
	IF c = 0 THEN
		INSERT INTO role_user_mapping (`role_id`, `user_id`) VALUES (rid, u);
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `m_user_role` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `m_user_role`(u BIGINT(40) UNSIGNED, ia TINYINT(1))
BEGIN
	DECLARE s_wa, s_po, s_pa, s_pm TINYINT(1) DEFAULT 0;
	DECLARE p, s BIGINT(40) UNSIGNED;
	DECLARE t ENUM('official','employee','customer','admin','relate','incomer');
	DECLARE pu_cur CURSOR FOR SELECT pu.party_id, pu.`type`, o.scope_id FROM party_user_mapping AS pu JOIN org AS o ON pu.party_id = o.org_id WHERE pu.user_id = u AND pu.`type` != 'relate';
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET @ur_done = 1;

	IF @wooid IS NULL THEN
		SELECT org_id, scope_id INTO @wooid, @wosid FROM scope WHERE is_classification = 0 AND is_system = 1 AND type = site;
		IF @wooid IS NULL THEN
			SELECT warning_scope_classification_or_type_not_fixed FROM scope;
		END IF;
	END IF;

	SET @ur_done = 0;

	OPEN pu_cur;

	REPEAT
		FETCH pu_cur INTO p, t, s;
		IF NOT @ur_done THEN
			IF p = @wooid THEN
				IF t = 'admin' THEN
					CALL m_user_default_role(@wooid, @wosid, u, 'webadmin');
					SET s_wa = 1;
				ELSEIF t = 'employee' AND ia THEN
					CALL m_user_default_role(@wooid, @wosid, u, 'webadmin');
					SET s_wa = 1;
				END IF;
			ELSE
				IF t = 'admin' THEN
					CALL m_user_default_role(p, s, u, 'placeowner');
					SET s_po = 1;
				ELSEIF t = 'employee' AND ia THEN
					CALL m_user_default_role(p, s, u, 'placeadmin');
					SET s_pa = 1;
				ELSE
					CALL m_user_default_role(p, s, u, 'placemember');
					SET s_pm = 1;
				END IF;
			END IF;
		END IF;
	UNTIL @ur_done END REPEAT;

	CLOSE pu_cur;

	IF NOT s_wa THEN
		IF s_po THEN
			CALL m_user_default_role(@wooid, @wosid, u, 'gplaceowner');
		ELSEIF s_pa THEN
			CALL m_user_default_role(@wooid, @wosid, u, 'gplaceadmin');
		ELSE
			CALL m_user_default_role(@wooid, @wosid, u, 'user');
		END IF;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `off_feture_network` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `off_feture_network`()
BEGIN
  call delete_entry('network');
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `off_feture_play` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `off_feture_play`()
BEGIN
  call delete_entry('play');
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `on_feture_network` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `on_feture_network`()
BEGIN
  call insert_entry('network');
 

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `on_feture_play` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `on_feture_play`()
BEGIN
  call insert_entry('play');
 
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `pr_clean_uumaping` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `pr_clean_uumaping`()
begin
	declare done int default false;
	declare v_uu_id bigint(40);
	declare v_from_user bigint(40);
	declare v_to_user bigint(40);
	declare v_type enum('friend','follow');
	declare v_cur cursor for select uu_id, from_user, to_user, type from user_user_mapping;
	declare continue handler for not found set done = true;

	drop temporary table if exists uutemp;
        create temporary table uutemp (
	    uu_id bigint(40),
	    from_user bigint(40),
	    to_user bigint(40),
            type enum('friend','follow')
	);	
	open v_cur;	
	
	main_loop: loop
		fetch v_cur into v_uu_id, v_from_user, v_to_user, v_type;
		if done then
      		leave main_loop;
    	end if;
    		if not exists (select * from uutemp where from_user = v_from_user and to_user = v_to_user and type = v_type) then
		   insert into uutemp (uu_id, from_user, to_user, type) values (v_uu_id, v_from_user, v_to_user, v_type);
		end if;
	end loop;	
	
	close v_cur;
	delete from user_user_mapping;
	insert into user_user_mapping (select * from uutemp);
        drop temporary table uutemp;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `pr_ru_alter_mobile` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `pr_ru_alter_mobile`()
begin
	declare done int default false;
	declare v_user_id int(10);
	declare v_cur cursor for select user_id from register_user;
	declare continue handler for not found set done = true;
	open v_cur;	
	
	main_loop: loop
		fetch v_cur into v_user_id;
		if done then
      		leave main_loop;
    	end if;
    		update register_user set mobile = v_user_id where user_id = v_user_id;
	end loop;	
	
	close v_cur;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `remove_feture_network` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_feture_network`()
BEGIN
 
 start transaction;
    delete from bocdb.feture_entry where feture_key = 'feture_plugin_network';
    delete from  bocdb.feture_privilege where feture_key ='feture_plugin_network';
    delete from bocdb.feture where feture_name = 'network';
   
    delete from spacedb.s_datalists where name ='feture_plugin_network';

   
commit;
    
     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `remove_feture_play` */;
ALTER DATABASE `bocdb` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_feture_play`()
BEGIN
 
 start transaction;
    delete from bocdb.feture_entry where feture_key = 'feture_plugin_play';
    delete from  bocdb.feture_privilege where feture_key ='feture_plugin_play';
    delete from bocdb.feture where feture_name = 'play';
   
    delete from spacedb.s_datalists where name ='feture_plugin_play';

   
commit;
    
     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `bocdb` CHARACTER SET utf8 COLLATE utf8_general_ci ;

--
-- Current Database: `bocdb`
--

USE `bocdb`;

--
-- Final view structure for view `v_unique_mobile`
--

/*!50001 DROP TABLE IF EXISTS `v_unique_mobile`*/;
/*!50001 DROP VIEW IF EXISTS `v_unique_mobile`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_unique_mobile` AS select `register_user`.`user_id` AS `user_id`,`register_user`.`username` AS `username`,`register_user`.`password` AS `password`,`register_user`.`mobile` AS `mobile`,`register_user`.`deleted` AS `deleted` from `register_user` where ((`register_user`.`mobile` is not null) and (`register_user`.`mobile` <> '') and (`register_user`.`deleted` = 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-10 11:39:09
