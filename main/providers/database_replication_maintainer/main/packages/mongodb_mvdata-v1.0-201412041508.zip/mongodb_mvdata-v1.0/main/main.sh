#!/bin/bash -x
shpath=$(cd $(dirname $0); pwd)    
source $shpath'/properties.ini'
  echo "停止mongod："${mongocmd}mongod
ps -aux |grep "${mongocmd}mongod"
      ps -aux|grep ${mongocmd}mongod > $shpath/tmp.txt
  congfile=`cat $shpath/tmp.txt |grep "${mongocmd}mongod -f " |awk  '{print $13}'`
  pid=`cat $shpath/tmp.txt |grep "${mongocmd}mongod -f " |awk  '{print $2}'`
  echo "pid="$pid
  echo "congfile="$congfile

  tmpcongfile="$mongobasedir/mongod.conf"
  if [ "$congfile" = "$tmpcongfile" ]; then
      echo "******停止  mongod："
      stop mongod      
  else
      if [ ! "$congfile" = "" ]; then
          echo "******kill  mongod："  
          kill -9 $pid
      fi 
  fi 
if [ -f $mongobasedir/conf/mongodrep.conf ]; then    
    echo "修改mongodrep.conf内容："
    sed -i 's/opt\/magima\/mongodb\/data/var\/magima\/data\/paas\/mongodb\/data/g' $mongobasedir/conf/mongodrep.conf
    sed -i 's/opt\/magima\/mongodb\/logs/var\/magima\/log\/paas\/mongodb\/logs/g' $mongobasedir/conf/mongodrep.conf
fi
if [ -f $mongobasedir/conf/mongod.conf ]; then    
    echo "修改mongod.conf内容："
    sed -i 's/opt\/magima\/mongodb\/data/var\/magima\/data\/paas\/mongodb\/data/g' $mongobasedir/conf/mongod.conf
    sed -i 's/opt\/magima\/mongodb\/logs/var\/magima\/log\/paas\/mongodb\/logs/g' $mongobasedir/conf/mongod.conf
fi

echo "迁移mongodb数据目录："

if [ -d /var/magima/data/paas/mongodb ]; then    
    timestamp=`date +%Y%d%H%M%S`
    rm -rf /var/magima/data/paas/mongodb/data 
    rm -rf  /var/magima/log/paas/mongodb/logs 
fi
if [ ! -d /var/magima/data/paas/mongodb ]; then  
    echo "mkdir -p /var/magima/data/paas/mongodb"
    mkdir -p /var/magima/data/paas/mongodb
fi  
if [ ! -d /var/magima/log/paas/mongodb ]; then  
    echo "mkdir -p /var/magima/log/paas/mongodb"
    mkdir -p /var/magima/log/paas/mongodb
fi 
if [ -d $mongobasedir/data/ ]; then    
    cp -R $mongobasedir/data/ /var/magima/data/paas/mongodb/
fi
if [ -d $mongobasedir/logs/ ]; then
    cp -R $mongobasedir/logs/ /var/magima/log/paas/mongodb/
fi


echo "修改mongodb数据目录权限："
      /usr/sbin/groupadd mongod
      /usr/sbin/useradd -g mongod mongod
chown -R mongod:mongod  /var/magima/data/paas/mongodb/
chown -R mongod:mongod  /var/magima/log/paas/mongodb/
ls /var/magima/data/paas/mongodb/
ls /var/magima/log/paas/mongodb/

echo "重新启动mongod："
start mongod
echo "－－－－－－－mongodb 数据目录变更结束－－－－－－－"
