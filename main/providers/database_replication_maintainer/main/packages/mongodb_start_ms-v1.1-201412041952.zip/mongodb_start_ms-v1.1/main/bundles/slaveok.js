db.getMongo().setSlaveOk();
