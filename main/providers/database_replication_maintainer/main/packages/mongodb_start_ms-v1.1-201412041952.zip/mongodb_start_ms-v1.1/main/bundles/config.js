config = { _id:"",members:[{_id:0,host:"10.0.5.112:27017"},{_id:1,host:"10.0.5.83:27017"}]}
rs.initiate(config)
rs.conf();
