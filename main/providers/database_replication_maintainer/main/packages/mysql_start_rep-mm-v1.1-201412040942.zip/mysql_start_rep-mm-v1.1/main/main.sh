#!/bin/bash -x
#用于主主配置，都是两台机器都是初装的情况；
#sudo sh /opt/mtprovision/daas/replicationmysql/mysql_rep_mm/mysql_start_rep-mm-v1.0/main/main.sh 10.0.5.112,10.0.5.83  magima.1,magima.1 

  today=`date +%Y%m%d%H%M%S`
  #echo $today
  shpath=$(cd $(dirname $0); pwd)
  echo $shpath'/properties.ini'
  source $shpath'/properties.ini'
if [ ! -z $1 ]; then  
  ip=$1
fi 
if [ ! -z $2 ]; then  
  password=$2
fi 
if [ ! -z $3 ]; then  
  sudouser=$3
fi 
if [ ! -z $4 ]; then  
  sudopassword=$4
fi 
  echo $ip
  nodeip=(${ip//,/ })
  param_index=1
  for param in ${nodeip[@]}
  do

    if [ -z "$masterip" ]; then
      masterip=$param
    else
      if [ -z "$slaveip" ]; then
        slaveip=$param
      else
        break
      fi
    fi
  done 

  echo $password
  nodepassword=(${password//,/ })
  for param in ${nodepassword[@]}
  do
    echo $param
    if [ -z "$masterpassword" ]; then
      masterpassword=$param
    else
      if [ -z "$slavepassword" ]; then
        slavepassword=$param 
      else
        break
      fi
    fi
  done 

if [ -z $masterip ];then
    echo "#################:masterip为空，不具备配置replication，退出本次配置！#################"
    exit 801
fi
if [ -z $slaveip ];then
    echo "#################:slaveip为空，不具备配置replication，退出本次配置！#################"
    exit 802
fi

rm -rf $shpath/master.log
rm -rf $shpath/slave.log
echo "1"> $shpath/master.log
echo "1"> $shpath/slave.log

${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "show slave status\G;"  > $shpath/master.log
if [ ! 0 -eq $? ]; then
    echo "#################:$masterip mysql执行出错，请检查mysql初始环境！忽略继续#################"    
else
    IORunning=$(cat $shpath/slave.log | grep " Slave_IO_Running:" | awk '{print $2}')
    SQLRunning=$(cat $shpath/slave.log | grep " Slave_SQL_Running:" | awk '{print $2}')
    if [ ! -z $IORunning  ]; then
      if [ $IORunning == "Yes" ]; then
        if [ $SQLRunning == "Yes" ]; then
          echo "#################:$masterip 已作为正常运行的slave，不必再做配置，退出本次配置！#################"
          exit 0
        fi 
      fi 
    fi
fi 
echo "#################:init my.cnf！#################"
source $shpath/init.sh

${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "show master status\G;"  > $shpath/master.log
masterFile=$(cat $shpath/master.log | grep " File" | awk '{print $2}')
if [ -z $masterFile  ]; then
    echo "#################:请检查master的my.cnf,开启二进制log！#################"
    exit 804
fi
if [ $masterFile = "" ]; then
    echo "#################:请检查master的my.cnf,开启二进制log！#################"
    exit 805
fi
  ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "show master status\G;"  > $shpath/master.log

  masterFile=$(cat $shpath/master.log | grep " File" | awk '{print $2}')

  if [ -z $masterFile  ]; then
    echo "#################:请检查slave的my.cnf,开启二进制log！#################"
    exit 806
  fi
  if [ $masterFile = "" ]; then
    echo "#################:请检查slave的my.cnf,开启二进制log！#################"
    exit 807
  fi
  
  echo ` ${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "select tooldb.func_startrep_checkdata() ;"`>$shpath/master.txt
  echo ` ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "select tooldb.func_startrep_checkdata() ;"`>$shpath/slave.txt

  mastercount=`cat $shpath/master.txt |tail -n+1 | awk  '{print $2}'`
  slavecount=`cat $shpath/slave.txt |tail -n+1 | awk  '{print $2}'`
  echo "mastercount=:"$mastercount
  echo "slavecount=:"$slavecount
  echo "!!!!!!!!!!!!!!"
  if [  -z $mastercount ]; then
      mastercount=0
  fi 
  if [  -z $slavecount ]; then
      slavecount=0
  fi 
      if [ "$slavecount" -ne "$mastercount" ]; then
        echo "#################:master与slave的初始数据不一致，请先同步初始数据！#################"
        exit 808
      fi 
  echo "!!!!!!!!!!!!!!"
  #启动主主,设定masternode主节点，slavenode为被动主节点：

  echo "启动主主"
  #主节点授权
  echo "${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e call tooldb.sp_rep_slave_grant('"$slaveip"','"$slavepassword"');"
  ${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "call tooldb.sp_rep_slave_grant('"$slaveip"','"$slavepassword"');" 
 
  #被动主节点授权
  echo "${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e call tooldb.sp_rep_slave_grant('"$masterip"','"$masterpassword"');"
  ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "call tooldb.sp_rep_slave_grant('"$masterip"','"$masterpassword"');"

  echo "${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e flush tables with  read lock;"
  ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "flush tables with  read lock;"

  
  #取主动主节上binlog文件
  echo "${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e show master status\G;"
  logfliemaster=$(${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "show master status\G;" | grep " File" | awk '{print $2}')
  echo "logfliemaster = "$logfliemaster
  #取主动主节点上pos
  echo "${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e show master status\G;"
  posmaster=$(${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "show master status\G;" | grep " Position" | awk '{print $2}')
  

  #取被动主机上binlog文件
  echo "${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e show master status\G;"
  logflieslave=$(${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "show master status\G;" | grep " File" | awk '{print $2}')
  echo "logflieslave = "$logflieslave
  #取被动主节点上pos
  echo "${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e show master status\G;"
  posslave=$(${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "show master status\G;" | grep " Position" | awk '{print $2}')
  
  echo "posslave = "$posslave
  echo "${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e unlock tables;"
  ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "unlock tables;"   
  
  #将主节点作为被动主节点的slave，取被动主节点的当前binlog和pos作为同步起点
  echo "将主节点作为被动主节点的slave，取被动主节点的当前binlog和pos作为同步起点"
  echo "${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e call tooldb.sp_resetrep_slave('"$slaveip"','"$slavepassword"','"$masterip"','"$masterpassword"','"$logflieslave"','"$posslave"');"
  ${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "call tooldb.sp_resetrep_slave('"$slaveip"','"$slavepassword"','"$masterip"','"$masterpassword"','"$logflieslave"','"$posslave"');"
  
  #将被动主节点作为主节点的slave，取主节点备份数据中的binlog和pos作为同步起点
  echo "将被动主节点作为主节点的slave，取主节点备份数据中的binlog和pos作为同步起点"
  echo "${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e call tooldb.sp_resetrep_slave('"$masterip"','"$masterpassword"','"$slaveip"','"$slavepassword"','"$logfliemaster"','"$posmaster"');"
  ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "call tooldb.sp_resetrep_slave('"$masterip"','"$masterpassword"','"$slaveip"','"$slavepassword"','"$logfliemaster"','"$posmaster"');"

  echo "${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e  GLOBAL read_only ='OFF';" 
  ${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "set GLOBAL read_only ='OFF';"
  echo "${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e GLOBAL read_only ='ON';" 
  ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "set GLOBAL read_only ='ON';"

  ${mysqlcmd}mysql -uroot -p$masterpassword -h$masterip -e "show slave status\G;"  > $shpath/slave.log
  IORunning=$(cat $shpath/slave.log | grep " Slave_IO_Running:" | awk '{print $2}')
  SQLRunning=$(cat $shpath/slave.log | grep " Slave_SQL_Running:" | awk '{print $2}')

  if [ $IORunning == "Yes" ]; then
    if [ $SQLRunning == "Yes" ]; then
        echo "#################:master机主从配置完成！#################"        
    fi 
  fi 

  ${mysqlcmd}mysql -uroot -p$slavepassword -h$slaveip -e "show slave status\G;"  > $shpath/slave.log
  IORunning=$(cat $shpath/slave.log | grep " Slave_IO_Running:" | awk '{print $2}')
  SQLRunning=$(cat $shpath/slave.log | grep " Slave_SQL_Running:" | awk '{print $2}')

  if [ $IORunning == "Yes" ]; then
    if [ $SQLRunning == "Yes" ]; then
        echo "#################:slave机主从配置完成！#################"        
    fi 
  fi 

