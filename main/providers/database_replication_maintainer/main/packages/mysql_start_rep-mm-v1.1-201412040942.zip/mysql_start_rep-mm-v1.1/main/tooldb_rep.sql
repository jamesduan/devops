
CREATE DATABASE  IF NOT EXISTS `tooldb`  DEFAULT CHARACTER SET utf8 ;

USE `tooldb`;

DROP PROCEDURE IF EXISTS `sp_rep_initroot` ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_rep_initroot`(p_rootpassword varchar(40))
lable_pro:begin
  
  set @cnt = (select count(*) from mysql.user where user='root' and host='%');
  if @cnt=0 then
      set @grantsql = concat('create user ''root''@''%'' identified by ''', p_rootpassword,''';');
      select @grantsql;
      prepare sqltext from  @grantsql;     
      execute sqltext;
  end if;

  grant all privileges on *.* to 'root'@'%';

  set @grantsql = concat('update mysql.user set password=PASSWORD(''', p_rootpassword,''') where user=''root'' ;');
  select @grantsql;
  prepare sqltext from  @grantsql;     
  execute sqltext;
  update mysql.user set Grant_priv='Y' where user='root' and host='%';
  flush privileges;
end ;;
DELIMITER ;


DROP PROCEDURE IF EXISTS `sp_rep_slave_grant` ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_rep_slave_grant`(p_slaveip varchar(40),p_slaveps varchar(40))
lable_pro:begin
  
  set @slaveip = concat('''',p_slaveip,'''');
  set @slaveps = concat('''',p_slaveps,'''');

  set @cnt = (select count(*) from mysql.user where user='rep_slave' and host=@slaveip);
  if @cnt=0 then
    set @grantsql = concat('grant replication slave on *.* to ''rep_slave''@',@slaveip,' identified by ', @slaveps,';');
    select @grantsql;
    prepare sqltext from  @grantsql;     
    execute sqltext;
    flush privileges;
  end if;
  
end ;;
DELIMITER ;

DROP PROCEDURE IF EXISTS `sp_resetrep_slave`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_resetrep_slave`(p_masterip varchar(40),p_masterps varchar(40),p_slaveip varchar(40),p_slaveps varchar(40),p_log varchar(40),p_pos varchar(40))
lable_pro:begin
  
  set @masterip = concat('''',p_masterip,'''');
  set @masterps = concat('''',p_masterps,'''');
  set @slaveip = concat('''',p_slaveip,'''');
  set @slaveps = concat('''',p_slaveps,'''');
  set @logfile = concat('''',p_log,'''');
  set @pos = p_pos; 

  stop SLAVE;
  reset SLAVE;

  set @changesql = concat('change master to master_host=',@masterip,' ,master_user=''rep_slave'',master_password= ', @slaveps,',master_log_file=',@logfile,',master_log_pos=',@pos,';');
  select @changesql;
  prepare sqltext from  @changesql;     
  execute sqltext;
  start slave;  
end ;;
DELIMITER ;

DROP PROCEDURE IF EXISTS `sp_startrep_master`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_startrep_master`(p_masterip varchar(40),p_masterps varchar(40),p_slaveip varchar(40),p_slaveps varchar(40))
lable_pro:begin
  
  set @masterip = concat('''',p_masterip,'''');
  set @masterps = concat('''',p_masterps,'''');
  set @slaveip = concat('''',p_slaveip,'''');
  set @slaveps = concat('''',p_slaveps,'''');

  stop SLAVE;

  set @cnt = (select count(*) from mysql.user where user='rep_slave' and host=@slaveip);
  if @cnt=0 then
    set @grantsql = concat('grant replication slave on *.* to ''rep_slave''@',@slaveip,' identified by ', @slaveps,';');
    select @grantsql;
    prepare sqltext from  @grantsql;     
    execute sqltext;
    flush privileges;
  end if;
  
  set @changesql = concat('change master to master_host=',@masterip,' ,master_user=''root'',master_password= ', @masterps,';');
  select @changesql;
  prepare sqltext from  @changesql;     
  execute sqltext;
end ;;
DELIMITER ;

DROP PROCEDURE IF EXISTS `sp_startrep_slave`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_startrep_slave`(p_masterip varchar(40),p_masterps varchar(40),p_slaveip varchar(40),p_slaveps varchar(40))
lable_pro:begin
  
  set @masterip = concat('''',p_masterip,'''');
  set @masterps = concat('''',p_masterps,'''');
  set @slaveip = concat('''',p_slaveip,'''');
  set @slaveps = concat('''',p_slaveps,'''');

  stop SLAVE;

  set @changesql = concat('change master to master_host=',@masterip,' ,master_user=''rep_slave'',master_password= ', @slaveps,';');
  select @changesql;
  prepare sqltext from  @changesql;     
  execute sqltext;
  
  start slave;  
end ;;

DELIMITER ;

DROP function IF EXISTS func_startrep_checkdata;
DELIMITER ;;
CREATE function func_startrep_checkdata() 
returns int
begin
  set @cnt = (select count(*) from information_schema.tables where TABLE_NAME ='topic_entity' and TABLE_SCHEMA='topicdb');
  if @cnt=0 then
      return 0;
  else 
      return (select count(*) from topicdb.topic_entity) ;
  end if;
end ;;
DELIMITER ;
