#!/bin/bash -x

function funcdoinit(){

  hostip=$1
  rootpassword=$2
  echo "$hostip:"$hostip
  slaveserver_id=$[ $slaveserver_id + 1 ];   
  server_id=$[ $server_id + 1 ];  
          
  cp $shpath/bundles/my.cnf   $shpath/my$slaveserver_id.cnf
  sed -i 's/server_id=1/server_id='$slaveserver_id'/g' $shpath/my$slaveserver_id.cnf 
  
      sourcesql="source /tmp/tooldb_rep.sql;"
      initrootsql="call tooldb.sp_rep_initroot('"$rootpassword"');"
echo "sourcesql:"$sourcesql
echo "initrootsql:"$initrootsql
  myhostip=` /sbin/ifconfig |grep "inet addr:$hostip"|head -n+1 |awk  '{print $2}'|sed "s/addr://g"`
  echo "myhostip:"$myhostip
  
  if [ "$hostip" = "$myhostip" ]; then
      echo "修改$hostip 的my.cnf内容："
      cp $shpath/my$slaveserver_id.cnf $mysqlbasedir/my.cnf
      cnfbak="/etc/my.cnfbak"
      if [ ! -f "$cnfbak" ]; then   
           mv /etc/my.cnf /etc/my.cnfbak
      fi
      cp $shpath/bundles/clientmy.cnf /etc/my.cnf
      echo "重新启动$hostip 的mysql："
      /etc/init.d/mysql.server restart
      cp $shpath/tooldb_rep.sql /tmp

      ${mysqlcmd}mysql -uroot  -e "${sourcesql}"
      if [ ! 0 -eq $? ]; then
          echo "#################:$hostip 用root空密码source sql 出错，继续用传入密码处理！#################"
          ${mysqlcmd}mysql -uroot -p$rootpassword -e "${sourcesql}"
          if [ ! 0 -eq $? ]; then
              echo  ${mysqlcmd}mysql -uroot -p$rootpassword -e "${sourcesql}"
              echo "#################:$hostip的mysql执行出错，请检查$hostip的mysql！#################"
              exit 811
          fi 
      fi 
      ${mysqlcmd}mysql -uroot   -e "${initrootsql}"
      if [ ! 0 -eq $? ]; then
          echo "#################:$hostip 用root空密码初始化root@%出错，继续用传入密码处理！#################"
          ${mysqlcmd}mysql -uroot -p$rootpassword -e "${initrootsql}"
          if [ ! 0 -eq $? ]; then
              echo  ${mysqlcmd}mysql -uroot -p$rootpassword -e "${initrootsql}"
              echo "#################:初始化$hostip的root@%出错，请检查$hostip的mysql！#################"
              exit 812
          fi 
      fi 
  else      
      echo "修改远程$hostip 的my.cnf内容："
      su $sudouser -c "sshpass -p $sudopassword scp $shpath/my$slaveserver_id.cnf $hostip:/tmp"
      su $sudouser -c "sshpass -p $sudopassword ssh -t $hostip sudo cp /tmp/my$slaveserver_id.cnf $mysqlbasedir/my.cnf"
      su $sudouser -c "sshpass -p $sudopassword scp $shpath/bundles/clientmy.cnf $hostip:/tmp"
      su $sudouser -c "sshpass -p $sudopassword ssh -t $hostip sudo cp /tmp/clientmy.cnf /etc/my.cnf"
      
      cp $shpath/bundles/clientmy.cnf /etc/my.cnf
      echo "重新启动远程$hostip 的mysql："
      su $sudouser -c "sshpass -p $sudopassword ssh -t $hostip sudo /etc/init.d/mysql.server restart"
      
      echo "scp tooldb_rep.sql："
      su $sudouser -c "sshpass -p $sudopassword scp $shpath/tooldb_rep.sql $hostip:/tmp"


      sshpass -p $sudopassword ssh -t $hostip "${mysqlcmd}mysql -uroot  -e \"${sourcesql}\"   "
      if [ ! 0 -eq $? ]; then
        
          echo "#################:$hostip 用root空密码source sql 出错，继续用传入密码处理！#################"
        sshpass -p $sudopassword ssh -t $hostip "${mysqlcmd}mysql -uroot -p$rootpassword -e \"${sourcesql}\"   "
        if [ ! 0 -eq $? ]; then
            echo "#################:$hostip的mysql执行出错，请检查$hostip的mysql！#################"
            exit 813
        fi
      fi 


      sshpass -p $sudopassword ssh -t $hostip "${mysqlcmd}mysql -uroot  -e \"${initrootsql}\"   "
      if [ ! 0 -eq $? ]; then
          echo "#################:$hostip 用root空密码初始化root@%出错，继续用传入密码处理！#################"
        sshpass -p $sudopassword ssh -t $hostip "${mysqlcmd}mysql -uroot -p$rootpassword -e \"${initrootsql}\"   "
        if [ ! 0 -eq $? ]; then
            echo "#################:初始化$hostip的root@%出错，请检查$hostip的mysql！#################"
            exit 814
        fi
      fi 
  fi

}

slaveserver_id=1;
server_id=1; 
param_index=0
for param in ${nodeip[@]}
do
  password=${nodepassword[$param_index]}
  param_index=$[ $param_index + 1 ]; 
  echo "param:"$param
  echo "password:"$password
  echo "index:"$param_index
  funcdoinit $param $password
done 
