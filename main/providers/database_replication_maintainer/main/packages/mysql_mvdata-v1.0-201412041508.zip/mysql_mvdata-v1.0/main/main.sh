#!/bin/bash -x
shpath=$(cd $(dirname $0); pwd)    
source $shpath'/properties.ini'
echo "停止mysql："

if [ -f /etc/init.d/mysql.server ]; then  
/etc/init.d/mysql.server stop
else
$mysqlbasedir/support-files/mysql.server stop
fi 
echo "修改my.cnf内容："
sed -i 's/=\/opt\/magima\/mysql\/data/=\/var\/magima\/data\/paas\/mysql\/data/g' $mysqlbasedir/my.cnf 

echo "修改/etc/init.d/mysql.server内容："

if [ -f /etc/init.d/mysql.server ]; then  
sed -i 's/=\/opt\/magima\/mysql\/data/=\/var\/magima\/data\/paas\/mysql\/data/g' /etc/init.d/mysql.server
else
sed -i 's/=\/opt\/magima\/mysql\/data/=\/var\/magima\/data\/paas\/mysql\/data/g' $mysqlbasedir/support-files/mysql.server
fi 


echo "迁移数据目录："
if [ -d /var/magima/data/paas/mysql ]; then    
    timestamp=`date +%Y%d%H%M%S`
    rm -rf /var/magima/data/paas/mysql/data 
fi
if [ ! -d /var/magima/data/paas/mysql ]; then  
    echo "mkdir -p /var/magima/data/paas/mysql"
    mkdir -p /var/magima/data/paas/mysql
fi  
if [ -d //var/magima/log/paas/mysql ]; then    
    timestamp=`date +%Y%d%H%M%S`
    rm -rf /var/magima/log/paas/mysql
fi
if [ ! -d /var/magima/log/paas/mysql ]; then  
    echo "mkdir -p /var/magima/log/paas/mysql"
    mkdir -p /var/magima/log/paas/mysql
fi  

cp -R /opt/magima/mysql/data/ /var/magima/data/paas/mysql/
cp  /opt/magima/mysql/data/*.log /var/magima/log/paas/mysql/
cp  /opt/magima/mysql/data/*.index /var/magima/log/paas/mysql/
cp  /opt/magima/mysql/data/*.info /var/magima/log/paas/mysql/

echo "修改数据目录权限："
chown -R mysql:mysql  /var/magima/data/paas/mysql/
chown -R mysql:mysql  /var/magima/log/paas/mysql/
ls /var/magima/data/paas/mysql/data/
ls /var/magima/log/paas/mysql/
#echo "重新启动mysql："
#if [ -f /etc/init.d/mysql.server ]; then  
#   /etc/init.d/mysql.server start
#else
#    $mysqlbasedir/support-files/mysql.server start
#fi 

echo "－－－－－－－mysql 数据目录变更结束－－－－－－－"
