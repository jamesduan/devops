#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .log import logger

__version__ = "0.1.0"
_current_prompt = None
